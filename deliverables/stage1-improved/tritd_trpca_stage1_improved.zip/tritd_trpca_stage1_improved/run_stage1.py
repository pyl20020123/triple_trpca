"""Reproducible synthetic low-triple-rank tensor sparse-corruption recovery tests.

Usage: python run_stage1.py --out outputs/demo
"""
import argparse
import csv
import json
import time
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tri_core import fit_trpca, generate_case, scores


def parse_csv_ints(s):
    return [int(t.strip()) for t in s.split(',') if t.strip()]


def parse_csv_floats(s):
    return [float(t.strip()) for t in s.split(',') if t.strip()]


def save_csv(path, rows):
    # STAGE1_UNIQUE_CSV_NAMES_V2
    if not rows:
        return
    path = Path(path)
    tag = path.parent.name
    if not path.name.startswith(tag + '_'):
        path = path.with_name(tag + '_' + path.name)
    with open(path, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def save_panel(path, clean, sparse, observation, result):
    L=result['L']; S=result['S']
    z=clean.shape[2]//2
    vmin,vmax=np.percentile(clean[:,:,z],[1,99])
    smax=max(float(np.percentile(np.abs(sparse[:,:,z]),99.9)),1e-8)
    items=[('True low-triple-rank L*',clean[:,:,z],vmin,vmax,'viridis'),
           ('Corrupted Y',observation[:,:,z],vmin,vmax,'viridis'),
           ('Recovered L',L[:,:,z],vmin,vmax,'viridis'),
           ('True sparse corruption S*',sparse[:,:,z],-smax,smax,'coolwarm'),
           ('Estimated sparse S',S[:,:,z],-smax,smax,'coolwarm'),
           ('Absolute recovery error',np.abs(L[:,:,z]-clean[:,:,z]),0,None,'magma')]
    fig,axes=plt.subplots(2,3,figsize=(11,7))
    for ax,(title,mat,low,hi,cmap) in zip(axes.ravel(),items):
        ax.imshow(mat,cmap=cmap,vmin=low,vmax=hi)
        ax.set_title(title, fontsize=10)
        ax.axis('off')
    fig.suptitle('Synthetic sparse-corruption recovery (central tensor slice)')
    fig.tight_layout()
    fig.savefig(path,dpi=160)
    plt.close(fig)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--dims',default='20,20,16',help='n1,n2,n3')
    ap.add_argument('--ranks',default='2,3',help='true and fitted triple-rank UPPER BOUNDS')
    ap.add_argument('--rates',default='0.01,0.05,0.10')
    ap.add_argument('--seeds',default='2026,2027,2028',help='synthetic data seeds')
    ap.add_argument('--restarts',type=int,default=3,help='initializations per sample')
    ap.add_argument('--max-iter',type=int,default=300)
    ap.add_argument('--lam',type=float,default=0.1)
    ap.add_argument('--alpha',type=float,default=1e-4)
    ap.add_argument('--eta',type=float,default=1e-3)
    ap.add_argument('--amplitude',type=float,default=3.0)
    ap.add_argument('--support-threshold',type=float,default=0.05)
    ap.add_argument('--tol',type=float,default=1e-7)
    ap.add_argument('--patience',type=int,default=10)
    ap.add_argument('--out',default='outputs/stage1')
    ap.add_argument('--no-sparse-baseline',action='store_true',help='also run an internal clean ALS fit directly on polluted Y')
    args=ap.parse_args()
    dims=tuple(parse_csv_ints(args.dims)); ranks=parse_csv_ints(args.ranks)
    rates=parse_csv_floats(args.rates); seeds=parse_csv_ints(args.seeds)
    if len(dims)!=3 or min(dims)<1 or min(ranks)<1 or max(ranks)>sorted(dims)[1]:
        ap.error('Need three dimensions and 1 <= rank <= middle(dims)')
    if not ranks or not rates or not seeds or args.restarts<1 or args.max_iter<1:
        ap.error('Empty condition or invalid restarts/max-iter')
    out = Path(args.out)
    table_names = ('all_runs.csv', 'best_per_case.csv', 'summary_by_condition.csv', 'no_sparse_baseline.csv')
    if any((out / name).exists() or (out / (out.name + '_' + name)).exists() for name in table_names):
        raise SystemExit(f'Existing result tables in {out}; choose a NEW --out directory to avoid overwrite.')
    out.mkdir(parents=True, exist_ok=True)
    (out/'figures').mkdir(exist_ok=True)
    (out/'histories').mkdir(exist_ok=True)
    (out/'reconstructions').mkdir(exist_ok=True)
    with open(out/'config.json','w',encoding='utf-8') as f:
        json.dump(vars(args),f,ensure_ascii=False,indent=2)
    all_rows=[]; best_rows=[]; baseline_rows=[]
    for rank in ranks:
        for rate in rates:
            for data_seed in seeds:
                clean,sp,obs=generate_case(dims,rank,rate,args.amplitude,data_seed)
                caseid=f'r{rank}_rho{rate:g}_seed{data_seed}'
                best=None
                for restart in range(args.restarts):
                    init_seed=data_seed*100+restart+17
                    t0=time.perf_counter()
                    result=fit_trpca(obs,rank,lam=args.lam,alpha=args.alpha,
                        eta=args.eta,max_iter=args.max_iter,seed=init_seed,
                        tol=args.tol,patience=args.patience)
                    elapsed=time.perf_counter()-t0
                    metric=scores(clean,sp,result['L'],result['S'],args.support_threshold)
                    row=dict(case=caseid,rank=rank,rate=rate,data_seed=data_seed,
                        restart=restart,init_seed=init_seed,
                        objective=result['final_objective'],iterations=result['iterations'],
                        converged=int(result['converged']),seconds=elapsed,**metric)
                    all_rows.append(row)
                    np.savetxt(out/'histories'/f'{caseid}_init{restart}.csv', result['history'],
                               delimiter=',',header='iteration,objective',comments='')
                    print(f'{caseid} init={restart} RRE_L={metric["rre_l"]:.4g} '
                          f'F1={metric["f1"]:.4f} objective={row["objective"]:.4g}', flush=True)
                    if best is None or row['objective']<best[0]['objective']:
                        best=(row,result)
                winner, fit=best
                winner=dict(winner)
                winner['corrupted_input_rre']=float(np.linalg.norm(obs-clean)/max(np.linalg.norm(clean),1e-12))
                winner['success']=int(winner['rre_l']<1e-2 and winner['f1']>=0.95)
                best_rows.append(winner)
                np.savez_compressed(out/'reconstructions'/f'{caseid}.npz',
                    L_true=clean,S_true=sp,Y=obs,L_hat=fit['L'],S_hat=fit['S'])
                save_panel(out/'figures'/f'{caseid}.png',clean,sp,obs,fit)
                if args.no_sparse_baseline:
                    baseline=fit_trpca(obs,rank,lam=0,alpha=args.alpha,eta=args.eta,
                        max_iter=args.max_iter,seed=winner['init_seed'],freeze_sparse=True)
                    base_met=scores(clean,sp,baseline['L'],baseline['S'],args.support_threshold)
                    baseline_rows.append(dict(case=caseid,rank=rank,rate=rate,data_seed=data_seed,
                                              init_seed=winner['init_seed'],rre_l=base_met['rre_l'],
                                              iterations=baseline['iterations'],objective=baseline['final_objective']))
                    save_csv(out/'no_sparse_baseline.csv',baseline_rows)
                    print(f'    no-sparse fit RRE_L: {base_met["rre_l"]:.4g}')
                save_csv(out/'all_runs.csv',all_rows)
                save_csv(out/'best_per_case.csv',best_rows)
    summary=[]
    for rank in ranks:
        for rho in rates:
            rs=[x for x in best_rows if x['rank']==rank and x['rate']==rho]
            summary.append(dict(rank=rank,rate=rho,n_cases=len(rs),
                rre_l_mean=float(np.mean([x['rre_l'] for x in rs])),
                rre_l_std=float(np.std([x['rre_l'] for x in rs],ddof=1)) if len(rs)>1 else 0.,
                success_rate=float(np.mean([x['success'] for x in rs])),
                f1_mean=float(np.mean([x['f1'] for x in rs])),
                f1_std=float(np.std([x['f1'] for x in rs],ddof=1)) if len(rs)>1 else 0.,
                precision_mean=float(np.mean([x['precision'] for x in rs])),
                recall_mean=float(np.mean([x['recall'] for x in rs])),
                residual_rre_mean=float(np.mean([x['residual_rre'] for x in rs]))))
    save_csv(out/'summary_by_condition.csv',summary)
    for metric,label in [('rre_l_mean','Low-rank recovery RRE (lower better)'),('f1_mean','Sparse-support F1 (higher better)')]:
        fig,ax=plt.subplots(figsize=(7,4))
        for r in ranks:
            rows=[x for x in summary if x['rank']==r]
            ax.plot([x['rate']*100 for x in rows],[x[metric] for x in rows],marker='o',label=f'r={r}')
        ax.set(xlabel='Sparse corruption rate (%)',ylabel=label)
        ax.grid(alpha=0.3);ax.legend()
        fig.tight_layout();fig.savefig(out/'figures'/f'{metric}.png',dpi=180);plt.close(fig)
    print('\nSaved:',out.resolve())
    print(f'Read {out.name}_summary_by_condition.csv and {out.name}_best_per_case.csv first.')


if __name__=='__main__':main()
