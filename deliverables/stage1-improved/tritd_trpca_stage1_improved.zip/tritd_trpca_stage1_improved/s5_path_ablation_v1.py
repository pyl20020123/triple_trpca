#!/usr/bin/env python3
"""S5: paired continuation-path ablation for TriTD-Half TRPCA.

Dependencies: run beside original tri_core.py and s4_cont_v1.py.
Runs five/six fixed-budget methods from SAME data and SAME initial factors.
Chooses a restart by the method's final-lambda objective only (NOT ground truth).
Does not overwrite an existing nonempty output directory.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import time
import numpy as np
from tri_core import generate_case, scores
from s4_cont_v1 import run_solver


def split_int(v):
    return [int(x.strip()) for x in v.split(',') if x.strip()]


def split_float(v):
    return [float(x.strip()) for x in v.split(',') if x.strip()]


def output_csv(path, rows):
    if not rows:
        return
    with open(path, 'w', encoding='utf-8-sig', newline='') as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0]))
        wr.writeheader()
        wr.writerows(rows)


def plan_options():
    # All plans have exactly 300 MALS-Half sweeps.
    return {
        'fixed003': [(0.03, 300)],
        'fixed007': [(0.07, 300)],
        'fixed010': [(0.10, 300)],
        'cont_full': [(0.10, 100), (0.07, 60), (0.05, 60), (0.03, 80)],
        'cont_jump': [(0.10, 220), (0.03, 80)],
        'cont_mid':  [(0.07, 160), (0.05, 60), (0.03, 80)],
    }


def summarize(best, all_runs, methods, rates, group):
    out=[]
    for method in methods:
        for rate in rates:
            b=[x for x in best if x['method']==method and x['rate']==rate]
            a=[x for x in all_runs if x['method']==method and x['rate']==rate]
            if not b:
                continue
            vals=lambda rec,key:np.array([float(x[key]) for x in rec],dtype=float)
            out.append(dict(group=group,method=method,rate=rate,n_cases=len(b),n_runs=len(a),
               rre_l_best_mean=float(np.mean(vals(b,'rre_l'))),
               rre_l_best_median=float(np.median(vals(b,'rre_l'))),
               rre_l_best_max=float(np.max(vals(b,'rre_l'))),
               rre_s_best_mean=float(np.mean(vals(b,'rre_s'))),
               f1_best_mean=float(np.mean(vals(b,'f1'))),
               residual_best_mean=float(np.mean(vals(b,'residual_rre'))),
               best_selected_success_rate=float(np.mean(vals(b,'success'))),
               any_restart_success_rate=float(np.mean(vals(b,'any_success'))),
               single_success_rate=float(np.mean(vals(a,'success'))),
               single_severe_rre_ge_01_rate=float(np.mean(vals(a,'severe'))),
               all_runs_rre_mean=float(np.mean(vals(a,'rre_l'))),
               all_runs_rre_median=float(np.median(vals(a,'rre_l'))),
               time_per_restart_mean=float(np.mean(vals(a,'seconds')))))
    return out


def pairs_report(all_runs, methods, group):
    origin='fixed003'
    rows=[]
    index={(x['method'],x['case'],x['restart']):x for x in all_runs}
    for target in methods:
        if target==origin:
            continue
        lhs=[];rhs=[]
        for x in all_runs:
            if x['method']!=origin:
                continue
            k=(target,x['case'],x['restart'])
            if k not in index:
                raise RuntimeError(f'Missing paired result for {k}')
            lhs.append(x);rhs.append(index[k])
        n=len(lhs)
        rows.append(dict(group=group,reference=origin,comparison=target,n_pairs=n,
          rescued_fail_to_success=sum(x['success']==0 and y['success']==1 for x,y in zip(lhs,rhs)),
          regressed_success_to_fail=sum(x['success']==1 and y['success']==0 for x,y in zip(lhs,rhs)),
          both_success=sum(x['success']==1 and y['success']==1 for x,y in zip(lhs,rhs)),
          both_fail=sum(x['success']==0 and y['success']==0 for x,y in zip(lhs,rhs)),
          comparison_lower_rre=sum(y['rre_l']<x['rre_l'] for x,y in zip(lhs,rhs)),
          comparison_higher_rre=sum(y['rre_l']>x['rre_l'] for x,y in zip(lhs,rhs)),
          delta_rre_comparison_minus_reference_mean=float(np.mean([y['rre_l']-x['rre_l'] for x,y in zip(lhs,rhs)]))))
    return rows


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dims', default='20,20,16')
    p.add_argument('--rank', type=int, default=3)
    p.add_argument('--rates',default='0.10,0.20')
    p.add_argument('--seeds',default='6101,6102,6103,6104,6105')
    p.add_argument('--restarts',type=int,default=5)
    p.add_argument('--amplitude',type=float,default=0.5)
    p.add_argument('--alpha',type=float,default=1e-4)
    p.add_argument('--eta',type=float,default=1e-3)
    p.add_argument('--support-threshold',type=float,default=0.05)
    p.add_argument('--methods',default='fixed003,fixed007,fixed010,cont_full,cont_jump,cont_mid')
    p.add_argument('--group',default='development',choices=['development','holdout'])
    p.add_argument('--out',default='outputs/s5_dev_paths_v1')
    args=p.parse_args()
    dims=tuple(split_int(args.dims));rates=split_float(args.rates);seeds=split_int(args.seeds)
    plans=plan_options()
    methods=[x.strip() for x in args.methods.split(',') if x.strip()]
    if len(dims)!=3 or min(dims)<1 or args.rank<1 or args.rank>sorted(dims)[1]:
        p.error('Need third-order dimensions and rank in 1..middle(dims)')
    if not seeds or len(set(seeds))!=len(seeds) or not rates or len(set(rates))!=len(rates):
        p.error('Need nonempty unique seeds and sparse fractions')
    if any(r<=0 or r>=1 for r in rates) or args.restarts<=0 or args.amplitude<=0 or args.alpha+args.eta<=0 or args.support_threshold<0:
        p.error('Invalid rates / restarts / amplitude / alpha / eta / threshold')
    if len(set(methods))!=len(methods) or not methods or any(x not in plans for x in methods):
        p.error(f'Methods must be nonempty unique selections from {list(plans)}')
    budget={sum(n for _,n in plans[m]) for m in methods}
    if budget!={300}:
        p.error('All methods must have 300 sweeps')
    out=Path(args.out);tag=out.name
    if not tag or tag in ('.','..'):
        p.error('--out must name an experiment directory')
    if out.exists() and any(out.iterdir()):
        raise SystemExit(f'Refusing to overwrite existing results in: {out}; choose new --out')
    out.mkdir(parents=True,exist_ok=True)
    (out/'traces').mkdir(exist_ok=True)
    (out/f'{tag}_config.json').write_text(json.dumps({**vars(args),'plans':{m:plans[m] for m in methods},'budget':300},indent=2),encoding='utf-8')
    all_runs=[];winners=[]
    print(f'S5 group={args.group}, paired methods={methods}, 300 sweeps each, total runs={len(rates)*len(seeds)*args.restarts*len(methods)}',flush=True)
    for rate in rates:
        for seed in seeds:
            Ltrue,Strue,Y=generate_case(dims,args.rank,rate,args.amplitude,seed)
            case=f'r{args.rank}_rho{rate:g}_seed{seed}'
            for method in methods:
                result_pairs=[]
                for j in range(args.restarts):
                    init_seed=seed*100+j+17
                    fit=run_solver(Y,args.rank,init_seed,args.alpha,args.eta,plans[method])
                    met=scores(Ltrue,Strue,fit['L'],fit['S'],args.support_threshold)
                    success=int(met['rre_l']<0.01 and met['f1']>=0.95)
                    row=dict(group=args.group, method=method,case=case,rank=args.rank,rate=rate,
                        data_seed=seed,restart=j,init_seed=init_seed,
                        final_lambda=plans[method][-1][0],sweeps=300,
                        objective_final_lambda=fit['final_objective'],seconds=fit['seconds'],
                        success=success,severe=int(met['rre_l']>=0.1),**met)
                    all_runs.append(row);result_pairs.append((row,fit))
                    print(f'{method:12s} {case} init={j} RRE_L={met["rre_l"]:.5f} F1={met["f1"]:.4f} success={success}',flush=True)
                bestrow,bestfit=min(result_pairs,key=lambda t:t[0]['objective_final_lambda'])
                winners.append(dict(bestrow,any_success=int(any(q[0]['success'] for q in result_pairs)),
                                    n_successful_restarts=sum(q[0]['success'] for q in result_pairs)))
                output_csv(out/f'{tag}_all_runs.csv',all_runs)
                output_csv(out/f'{tag}_best_per_case.csv',winners)
                output_csv(out/'traces'/f'{tag}_{method}_{case}_selected_trace.csv',bestfit['history'])
    summary=summarize(winners,all_runs,methods,rates,args.group)
    output_csv(out/f'{tag}_summary.csv',summary)
    pairs=pairs_report(all_runs,methods,args.group) if 'fixed003' in methods else []
    output_csv(out/f'{tag}_paired.csv',pairs)
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig,axes=plt.subplots(1,2,figsize=(13,4.5),constrained_layout=True)
        tick=np.arange(len(methods))
        for ri,rate in enumerate(rates):
            data=[x for x in summary if x['rate']==rate]
            q={x['method']:x for x in data}
            off=(ri-(len(rates)-1)/2)*0.32
            axes[0].bar(tick+off,[q[m]['rre_l_best_mean'] for m in methods],width=.28,label=f'rho={rate:g}')
            axes[1].bar(tick+off,[q[m]['single_success_rate'] for m in methods],width=.28,label=f'rho={rate:g}')
        for ax in axes:
            ax.set_xticks(tick,methods,rotation=35,ha='right');ax.grid(axis='y',alpha=.22);ax.legend()
        axes[0].set_ylabel('Selected-best mean RRE_L (lower better)')
        axes[1].set_ylabel('Single-restart success rate (higher better)');axes[1].set_ylim(0,1)
        fig.suptitle('TriTD-Half continuation-path ablation (equal 300-sweep budget)')
        fig.savefig(out/f'{tag}_comparison.png',dpi=170)
        plt.close(fig)
    except ImportError:
        print('matplotlib not installed: comparison image skipped',flush=True)
    print('\nSummary table',flush=True)
    for x in summary:
        print(f'{x["method"]:12s} rho={x["rate"]:.2f} mean_RRE={x["rre_l_best_mean"]:.5f} '
              f'best_success={x["best_selected_success_rate"]:.0%} single_success={x["single_success_rate"]:.0%} '
              f'severe_single={x["single_severe_rre_ge_01_rate"]:.0%}',flush=True)
    print('Saved',out.resolve(),flush=True)
    print('Do not compare objective values across methods with different final lambda.',flush=True)

if __name__=='__main__':main()
