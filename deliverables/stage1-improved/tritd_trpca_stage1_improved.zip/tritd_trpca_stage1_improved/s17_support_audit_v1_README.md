# S17 RGB sparse-mask audit

## Purpose

Before changing the low-triple-rank solver again, separate failures of anomaly **detection** from failures of the **replacement value**. Reproduce **exactly the same** S16 noisy DIV2K center crops, with the same seed, pixel-level random RGB corruption, and the same 3×3-median detection mask. No optimization or Triple decomposition is rerun.

All methods are **blind** and use only the observed RGB photo. True synthetic corruption support is used strictly for evaluation statistics and diagnostic mask plots.

## Setup

Upload `s17_support_audit_v1.py` to `~/tritd_trpca_stage1/`. Requires numpy, scipy, Pillow, matplotlib, scikit-image. It is standalone and does not import `tri_core.py`.

Run from the project root:

```bash
cd ~/tritd_trpca_stage1
python -m py_compile s17_support_audit_v1.py
python -u s17_support_audit_v1.py \
  --s16-config outputs/s16_nonlocal_dev_random_v1/s16_nonlocal_dev_random_v1_config.json \
  --s16-per-patch outputs/s16_nonlocal_dev_random_v1/s16_nonlocal_dev_random_v1_per_patch.csv \
  --out outputs/s17_support_audit_random_v1
```

If `--s16-per-patch` is provided, the program checks that the S16 `blind_local` anchor PSNR is reproduced within `1e-6 dB` at every anchor and exits with an error otherwise. Do not change original S16 configs or seeds.

## Mask methods

- **base**: `||Y - med3(Y)||_2 > 0.20`, identical to S16.
- **consensus**: base AND `||Y - med5(Y)||_2 > 0.20` (conservative alternative).
- **adaptive**: `||Y - med3(Y)||_2 > 0.20 + 0.75||med3(Y)-med5(Y)||_2` (edge-sensitive alternative).

The last two are **exploratory and unvalidated**, not claimed to improve performance. Their constants are set before seeing the S17 outcomes. No clean-pixel truth or actual corruption locations enter their inference. All three replace masked RGB pixels with the **same 3×3 median estimate**, so this isolates differences in detection from changes in the replacement algorithm.

## Outputs

```text
outputs/s17_support_audit_random_v1/
  s17_support_audit_random_v1_summary.csv
  s17_support_audit_random_v1_per_anchor.csv
  s17_support_audit_random_v1_config.json
  s17_support_audit_random_v1_0722_mask_diagnostic.png
  s17_support_audit_random_v1_0724_mask_diagnostic.png
```

The summary reports **full 128×128** image PSNR/SSIM and pixel support TP/FP/FN, precision, recall, F1. `err_tp`, `err_fp`, `err_fn`, and `err_tn` are contributions to **whole-image MSE** and sum to `mse_full`. The anchor CSV provides matched 8×8 region statistics to compare with the original S16. The diagnostic visualizations label explicitly the oracle-only true support, false positives, and missed pixels.

## Interpretation

If 0722 contains many false positives and the conservative/texture-adaptive masks improve full-image PSNR while retaining recall, improving the blind sparse support estimation is the immediate task. But if even the **oracle** mask with local median is far from satisfactory, the replacement value/model is also a bottleneck. Do **not** select a preferred method by per-image oracle results and report those as unbiased independent test performance. Use development results to pick one fixed option and evaluate later on held-out DIV2K photos.

S16's `selected_iteration == 0` means **after its 15 warmup MALS sweeps**, not an untrained zero model. S16's validation patches can overlap, so its iteration selection is proxy validation, not leakage-free independent generalization.
