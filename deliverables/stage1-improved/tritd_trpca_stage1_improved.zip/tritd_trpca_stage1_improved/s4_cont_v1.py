#!/usr/bin/env python3
"""S4: test fixed Half penalties vs. a warm-start lambda continuation in TriTD-TRPCA.

Run from the tritd_trpca_stage1 project root, beside tri_core.py.
Comparison is paired on synthetic tensors, initial factors and total ALS sweeps.
No ground truth is used to select an optimization restart.
"""
from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path

import numpy as np

from tri_core import (
    generate_case, init_factors, mals_sweep, half_prox,
    tritd, objective, scores,
)


def int_list(txt):
    return [int(x) for x in txt.split(',') if x.strip()]


def float_list(txt):
    return [float(x) for x in txt.split(',') if x.strip()]


def write_csv(path, rows):
    if not rows:
        return
    with open(path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def run_solver(Y, rank, init_seed, alpha, eta, plan):
    """plan is [(lambda, sweeps), ...], reusing A/B/C and S at boundaries."""
    scale = max(float(np.std(Y)), 1e-3)
    factors = init_factors(Y.shape, rank, seed=init_seed, scale=scale)
    S = np.zeros_like(Y, dtype=np.float64)
    stage_rows = []
    overall_iter = 0
    tic = time.perf_counter()
    for idx, (lam, n_sweeps) in enumerate(plan):
        start_obj = objective(Y, factors, S, lam, alpha)
        prev_obj = start_obj
        for local_iter in range(1, n_sweeps + 1):
            factors = mals_sweep(Y - S, factors, alpha=alpha, eta=eta)
            L = tritd(*factors)
            S = half_prox(Y - L, lam)
            current_obj = objective(Y, factors, S, lam, alpha)
            if not np.isfinite(current_obj):
                raise FloatingPointError(f'Invalid objective: stage={idx}, iter={local_iter}')
            if current_obj > prev_obj + 1e-7 * max(1.0, abs(prev_obj)):
                raise ArithmeticError(
                    f'Objective increased within fixed-lambda stage: '
                    f'stage={idx}, lam={lam}, iter={local_iter}, '
                    f'old={prev_obj}, new={current_obj}'
                )
            overall_iter += 1
            # Preserve stage comparisons. Across lambda changes, objectives differ.
            stage_rows.append({
                'global_iter': overall_iter,
                'stage': idx + 1,
                'stage_iter': local_iter,
                'lambda': lam,
                'objective': current_obj,
            })
            prev_obj = current_obj
        if n_sweeps < 1:
            raise ValueError('Every stage must have at least one iteration')
    L = tritd(*factors)
    return {'L': L, 'S': S, 'final_objective': objective(Y, factors, S, plan[-1][0], alpha),
            'seconds': time.perf_counter() - tic,
            'history': stage_rows, 'iterations': overall_iter}


def summarize(rows, all_runs, rank, rates, methods):
    out = []
    for method in methods:
        for rate in rates:
            q = [r for r in rows if r['method'] == method and abs(r['rate'] - rate) < 1e-12]
            if not q:
                continue
            arr = lambda key: np.array([v[key] for v in q], dtype=float)
            every = [r for r in all_runs if r['method'] == method and abs(r['rate'] - rate) < 1e-12]
            out.append({
                'method': method,
                'rank': rank,
                'rate': rate,
                'n_cases': len(q),
                'rre_l_mean': float(np.mean(arr('rre_l'))),
                'rre_l_median': float(np.median(arr('rre_l'))),
                'rre_l_max': float(np.max(arr('rre_l'))),
                'rre_s_mean': float(np.mean(arr('rre_s'))),
                'f1_mean': float(np.mean(arr('f1'))),
                'precision_mean': float(np.mean(arr('precision'))),
                'recall_mean': float(np.mean(arr('recall'))),
                'residual_rre_mean': float(np.mean(arr('residual_rre'))),
                'best_of_restarts_success_rate': float(np.mean([r['success'] for r in q])),
                'single_restart_success_rate': float(np.mean([r['success'] for r in every])),
                'seconds_mean': float(np.mean(arr('seconds'))),
            })
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--dims', default='20,20,16')
    ap.add_argument('--rank', type=int, default=3)
    ap.add_argument('--rates', default='0.10,0.20')
    ap.add_argument('--seeds', default='4101,4102,4103')
    ap.add_argument('--restarts', type=int, default=5)
    ap.add_argument('--amplitude', type=float, default=0.5)
    ap.add_argument('--alpha', type=float, default=0.0001)
    ap.add_argument('--eta', type=float, default=0.001)
    ap.add_argument('--support-threshold', type=float, default=0.05)
    ap.add_argument('--lambdas', default='0.1,0.07,0.05,0.03')
    ap.add_argument('--stage-iters', default='100,60,60,80')
    ap.add_argument('--out', default='outputs/s4_cont_v1')
    args = ap.parse_args()
    dims, seeds, rates = tuple(int_list(args.dims)), int_list(args.seeds), float_list(args.rates)
    lam_schedule, iters = float_list(args.lambdas), int_list(args.stage_iters)
    if len(dims) != 3 or min(dims) < 1 or not 1 <= args.rank <= sorted(dims)[1]:
        ap.error('Require 3 dimensions, and 1 <= rank <= middle(dims)')
    if not seeds or not rates or any(not 0 < x <= 1 for x in rates):
        ap.error('Provide nonempty seeds and sparse rates in (0,1]')
    if args.restarts < 1 or len(lam_schedule) < 2 or len(lam_schedule) != len(iters):
        ap.error('Need restarts>=1 and at least 2 lambda stages with matching iteration counts')
    if min(lam_schedule) <= 0 or min(iters) < 1 or min(args.alpha, args.eta, args.amplitude, args.support_threshold) < 0 or args.alpha + args.eta <= 0:
        ap.error('Invalid nonpositive/negative parameters')
    if any(lam_schedule[i] < lam_schedule[i+1] for i in range(len(lam_schedule)-1)):
        ap.error('Lambda schedule must be non-increasing')

    budget = sum(iters)
    methods = ['fixed003', 'fixed010', 'continuation']
    plans = {
        'fixed003': [(lam_schedule[-1], budget)],
        'fixed010': [(lam_schedule[0], budget)],
        'continuation': list(zip(lam_schedule, iters)),
    }
    out = Path(args.out)
    tag = out.name
    if not tag or tag in ('.', '..'):
        ap.error('--out must be an explicitly named experiment folder')
    if out.exists() and any(out.iterdir()):
        raise SystemExit(f'Refusing to overwrite existing experiment directory: {out}; choose a new --out')
    out.mkdir(parents=True, exist_ok=True)
    (out/'traces').mkdir(exist_ok=True)
    (out/(tag+'_config.json')).write_text(json.dumps({**vars(args), 'budget': budget, 'methods': plans}, indent=2), encoding='utf-8')
    all_runs, per_case, trace_overview = [], [], []
    print(f'Paired comparison: methods={methods}, budget={budget} sweeps, total runs={len(seeds)*len(rates)*args.restarts*len(methods)}', flush=True)
    for rate in rates:
        for data_seed in seeds:
            trueL, trueS, Y = generate_case(dims, args.rank, rate, args.amplitude, data_seed)
            case = f'r{args.rank}_rho{rate:g}_seed{data_seed}'
            for method in methods:
                candidates = []
                for restart in range(args.restarts):
                    init_seed = data_seed*100 + restart + 17
                    fit = run_solver(Y, args.rank, init_seed, args.alpha, args.eta, plans[method])
                    met = scores(trueL, trueS, fit['L'], fit['S'], args.support_threshold)
                    success = int(met['rre_l'] < 0.01 and met['f1'] >= 0.95)
                    row = {
                        'method': method, 'case': case, 'rank': args.rank, 'rate': rate,
                        'data_seed': data_seed, 'restart': restart, 'init_seed': init_seed,
                        'final_lambda': plans[method][-1][0], 'sweeps': budget,
                        'objective_final_lambda': fit['final_objective'],
                        'seconds': fit['seconds'], 'success': success, **met,
                    }
                    all_runs.append(row)
                    candidates.append((row, fit))
                    print(f'{method:13s} {case} init={restart:2d} RRE={met["rre_l"]:.5f} '
                          f'F1={met["f1"]:.4f} success={success}', flush=True)
                    fname = f'{tag}_{method}_{case}_i{restart:02d}_trace.csv'
                    write_csv(out/'traces'/fname, fit['history'])
                # Choose by objective at method's own final lambda, never using trueL/trueS.
                winner, winning_fit = min(candidates, key=lambda pair: pair[0]['objective_final_lambda'])
                per_case.append(dict(winner, success_rate_all_inits=float(np.mean([r[0]['success'] for r in candidates]))))
                for h in winning_fit['history']:
                    trace_overview.append(dict(method=method, case=case, best_init=winner['restart'], **h))
                write_csv(out/f'{tag}_all_runs.csv', all_runs)
                write_csv(out/f'{tag}_best_per_case.csv', per_case)
    stats = summarize(per_case, all_runs, args.rank, rates, methods)
    write_csv(out/f'{tag}_summary.csv', stats)
    write_csv(out/f'{tag}_best_trace.csv', trace_overview)
    print('\nResults:', out, flush=True)
    for r in stats:
        print(f"{r['method']:13s} rho={r['rate']:g} RRE={r['rre_l_mean']:.5f} "
              f"best-of-{args.restarts} success={int(round(r['best_of_restarts_success_rate']*r['n_cases']))}/{r['n_cases']} "
              f"single-start={r['single_restart_success_rate']:.1%}", flush=True)
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(1, 2, figsize=(11,4), constrained_layout=True)
        tick = np.arange(len(rates))
        for i, method in enumerate(methods):
            vals = [next(x for x in stats if x['method']==method and x['rate']==rate) for rate in rates]
            offset = (i - (len(methods)-1)/2) * 0.25
            ax[0].bar(tick+offset, [v['rre_l_mean'] for v in vals],width=0.23,label=method)
            ax[1].bar(tick+offset, [v['single_restart_success_rate'] for v in vals],width=0.23,label=method)
        for a in ax:
            a.set_xticks(tick, [f'{r:g}' for r in rates]);a.set_xlabel('Sparse corruption fraction');a.grid(axis='y',alpha=.25)
        ax[0].set_ylabel('Mean RRE_L (lower better)')
        ax[1].set_ylabel('Single-initialization success rate (higher better)')
        ax[1].set_ylim(0,1)
        ax[1].legend(fontsize=8)
        fig.savefig(out/f'{tag}_comparison.png',dpi=170)
        plt.close(fig)
    except ImportError:
        print('matplotlib missing: CSV saved, optional comparison figure skipped')
    print('Compare RRE/F1/success rates across methods; objective values of fixed010 are not directly comparable to lambda=.03 methods.')
    print('Within continuation, stage boundaries change lambda: objective jumps there are not numerical instability.')


if __name__ == '__main__':
    main()
