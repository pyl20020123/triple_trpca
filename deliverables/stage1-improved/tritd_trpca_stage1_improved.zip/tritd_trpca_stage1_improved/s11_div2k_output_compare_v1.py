#!/usr/bin/env python3
"""S11: DIV2K visual diagnostic on SAVED TriTD-Half outputs (no optimization).

Compares clean RGB reconstruction L against Y-S, estimated support replacement,
and a salt/pepper-specific observed-value mask + local median baseline. The
clean image and true injected sparse corruption are used ONLY for evaluation.

Use DEV split for development. Test split stays untouched during model choices.
"""
from __future__ import annotations
import argparse
import csv
import json
import re
from collections import defaultdict
from pathlib import Path
from statistics import mean

import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def metrics(x, y):
    p = np.clip(y,0,1)
    mse=float(np.mean((x-p)**2))
    psnr = -10*np.log10(max(mse,1e-15))
    try:
        from skimage.metrics import structural_similarity
        ssim=float(structural_similarity(x,p,data_range=1,channel_axis=2))
    except ImportError:
        ssim=float('nan')
    return {'psnr':float(psnr), 'ssim':ssim,
            'mae':float(np.mean(np.abs(x-p))),
            'raw_out_of_range_fraction':float(np.mean((y<0)|(y>1)))}


def mask_scores(gt, pred):
    tp=int(np.count_nonzero(gt&pred))
    fp=int(np.count_nonzero(~gt&pred))
    fn=int(np.count_nonzero(gt&~pred))
    precision=tp/(tp+fp) if tp+fp else 0.
    recall=tp/(tp+fn) if tp+fn else 0.
    f1=2*precision*recall/(precision+recall) if precision+recall else 0.
    return {'mask_precision':precision,'mask_recall':recall,'mask_f1':f1,
            'mask_est_n':int(np.count_nonzero(pred)),
            'mask_true_n':int(np.count_nonzero(gt))}


def extreme_pixel_mask(observed, eps=1e-10):
    """Detect observed exact black/white RGB pixels. Task-specific heuristic!"""
    return np.all(observed<=eps,axis=2)|np.all(observed>=1-eps,axis=2)


def local_median_from_unflagged(observed, bad, max_radius=5):
    """For each flagged pixel, fill RGB using median of unflagged observed neighbors.

    Never reads clean image, true mask or existing recovered predictions.
    """
    h,w,_=observed.shape
    result=observed.copy()
    valid_global=observed[~bad]
    default=np.median(valid_global,axis=0) if valid_global.size else np.full((3,),.5)
    for i,j in np.argwhere(bad):
        repaired=None
        for rad in range(1,max_radius+1):
            y0,y1=max(0,i-rad),min(h,i+rad+1)
            x0,x1=max(0,j-rad),min(w,j+rad+1)
            valid=~bad[y0:y1,x0:x1]
            neighbors=observed[y0:y1,x0:x1][valid]
            if neighbors.size:
                repaired=np.median(neighbors,axis=0)
                break
        result[i,j]=default if repaired is None else repaired
    return result


def save_csv(path, rows):
    if not rows:return
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)


def plot_panel(path, xs, title):
    columns=4
    fig,axs=plt.subplots(2,columns,figsize=(16,8.4),constrained_layout=True)
    for a,(lab,arr) in zip(axs.flat,xs):
        a.imshow(np.clip(arr,0,1),vmin=0,vmax=1)
        a.set_title(lab,fontsize=10)
        a.axis('off')
    for a in axs.flat[len(xs):]:a.axis('off')
    fig.suptitle(title+' | RGB display scale [0,1]')
    fig.savefig(path,dpi=160)
    plt.close(fig)


def case_rate(path):
    m=re.search(r'_r(?P<r>\d+)_rho(?P<rho>\d+p\d+)_(?P<mode>pixel|entry)_arrays\.npz$',path.name)
    if not m: return None
    return int(m.group('r')),float(m.group('rho').replace('p','.')),m.group('mode')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',required=True,help='S10 output folder e.g. outputs/s10_div2k_dev_r3_v1')
    parser.add_argument('--out',default='outputs/s11_div2k_dev_post_v1')
    parser.add_argument('--support-threshold',type=float,default=.05,help='pixel detected if ANY channel of estimated S exceeds threshold')
    parser.add_argument('--max-cases',type=int,default=0,help='0 = all saved array cases')
    args=parser.parse_args()
    source=Path(args.source)
    if not source.is_dir(): parser.error(f'Missing source directory: {source}')
    files=sorted(source.rglob('*_arrays.npz'))
    if args.max_cases>0:files=files[:args.max_cases]
    if not files: parser.error(f'No *_arrays.npz files inside {source}')
    dest=Path(args.out)
    if dest.exists() and any(dest.iterdir()):
        parser.error(f'Refusing to overwrite existing directory {dest}. Change --out.')
    dest.mkdir(parents=True,exist_ok=True)
    tag=dest.name
    (dest/f'{tag}_config.json').write_text(json.dumps(vars(args),indent=2),encoding='utf-8')
    all_rows=[]
    for i,fp in enumerate(files):
        parsed=case_rate(fp)
        if parsed is None:
            print('Skipping unrecognized filename:',fp)
            continue
        rank,rho,mode=parsed
        if mode!='pixel':
            print('Skipping entry mode; exact RGB black/white detection requires pixel corruption:',fp)
            continue
        with np.load(fp,allow_pickle=False) as z:
            required=('clean','observed','sparse_true','sparse_est','recovered')
            for key in required:
                if key not in z:raise KeyError(f'{fp}: missing {key}')
            clean=np.asarray(z['clean'],dtype=np.float64)
            y=np.asarray(z['observed'],dtype=np.float64)
            s_true=np.asarray(z['sparse_true'],dtype=np.float64)
            s_hat=np.asarray(z['sparse_est'],dtype=np.float64)
            lowrank=np.asarray(z['recovered'],dtype=np.float64)
        if clean.ndim!=3 or clean.shape[2]!=3 or any(a.shape!=clean.shape for a in [y,s_true,s_hat,lowrank]):
            raise ValueError(f'Shape mismatch: {fp}')
        name=fp.parent.name+'__'+fp.stem.replace('_arrays','')
        gt=np.any(np.abs(s_true)>1e-10,axis=2)
        est=np.any(np.abs(s_hat)>args.support_threshold,axis=2)
        detected=extreme_pixel_mask(y)
        corrected=y-s_hat
        replace_est=np.where(est[:,:,None],lowrank,y)
        replace_det=np.where(detected[:,:,None],lowrank,y)
        median_det=local_median_from_unflagged(y,detected)
        # This reference is deliberately NOT part of operational methods.
        ref_true=np.where(gt[:,:,None],lowrank,y)
        variants=[('noisy',y),('tritd_L',lowrank),('Y_minus_Shat',corrected),
                  ('estimated_mask_fill_L',replace_est),
                  ('extreme_mask_fill_L',replace_det),
                  ('extreme_mask_local_median',median_det),
                  ('oracle_mask_fill_L__diagnostic_only',ref_true)]
        img_id=re.search(r'(?:train|dev|test)_(\d{4})_p\d+',fp.parent.name)
        image_id=img_id.group(1) if img_id else fp.parent.name
        split=fp.parent.name.split('_')[0]
        for method,pred in variants:
            row={'case':name,'image_id':image_id,'split':split,'rank':rank,
                 'rate':rho,'mode':mode,'method':method,
                 **metrics(clean,pred),
                 **mask_scores(gt,est if 'estimated_' in method else detected if 'extreme_' in method else np.zeros_like(gt))}
            all_rows.append(row)
        panel=[('Original clean (evaluation only)',clean),('Corrupted Y',y),
               ('TriTD-Half L',lowrank),('Y - estimated S',corrected),
               ('Keep Y, replace estimated support with L',replace_est),
               ('Replace exact 0/1 pixels with L',replace_det),
               ('Replace exact 0/1 pixels with local median',median_det),
               ('True-support replacement (oracle diagnostic)',ref_true)]
        plot_panel(dest/f'{tag}_{name}_panel.png',panel,f'{name} | rho={rho:g}')
        print(f'[{i+1}/{len(files)}] {name} | noisy={metrics(clean,y)["psnr"]:.2f} dB '
              f'L={metrics(clean,lowrank)["psnr"]:.2f} dB '
              f'Y-S={metrics(clean,corrected)["psnr"]:.2f} dB '
              f'est-fill={metrics(clean,replace_est)["psnr"]:.2f} dB '
              f'extreme-median={metrics(clean,median_det)["psnr"]:.2f} dB',flush=True)
    if not all_rows:parser.error('No supported pixel-mode results found.')
    save_csv(dest/f'{tag}_per_case.csv',all_rows)
    group=defaultdict(list)
    for row in all_rows:
        group[(row['method'],row['rate'],row['rank'])].append(row)
    summary=[]
    for (method,rho,rank),rows in sorted(group.items()):
        # Same patch count per original image is currently one; for future multi-crops
        # aggregate per image then average across source images.
        by_img=defaultdict(list)
        for r in rows:by_img[r['image_id']].append(r)
        image_score=[dict(psnr=mean(rr['psnr'] for rr in v),
                          ssim=mean(rr['ssim'] for rr in v),
                          mask_f1=mean(rr['mask_f1'] for rr in v)) for v in by_img.values()]
        summary.append({'method':method,'rank':rank,'rate':rho,
                        'n_images':len(by_img),'n_patches':len(rows),
                        'mean_psnr':float(mean(x['psnr'] for x in image_score)),
                        'mean_ssim':float(mean(x['ssim'] for x in image_score)),
                        'mean_mask_f1':float(mean(x['mask_f1'] for x in image_score))})
    save_csv(dest/f'{tag}_summary.csv',summary)
    print('Saved results to:',dest.resolve())
    print('WARNING: extreme_mask* methods exploit exact 0/1 RGB salt-pepper values; not general sparse corruption solvers.')
    print('WARNING: oracle_mask_fill_L uses true support for diagnosis and is not a usable algorithm.')

if __name__=='__main__':main()
