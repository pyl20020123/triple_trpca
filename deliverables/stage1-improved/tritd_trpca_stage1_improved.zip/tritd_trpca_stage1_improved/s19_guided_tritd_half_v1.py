#!/usr/bin/env python3
"""S19: controlled guide-fidelity ablation for nonlocal TriTD-RGB GroupHalf.

Changes S18 only by adding beta/2*||L-guide||_F^2 to the objective.
Uses exact factor-target rescaling for homogeneous Frobenius least squares:
  T = (Y-S+beta*guide)/(1+beta)
  alpha_eff=alpha/(1+beta); eta_eff=eta/(1+beta).

beta=0 calls S18.fit_group exactly and can reproduce the S18 result files.
Blind guide is computed exclusively from corrupted observation. Ground truth
is used ONLY to report PSNR and mask diagnostic quality.

Requires S18, S16 and S17 scripts and tri_core.py in the same directory.
"""
from __future__ import annotations
import argparse, csv, json, math, time
from collections import defaultdict
from pathlib import Path
import numpy as np
from tri_core import init_factors, mals_sweep, tritd
from s16_nonlocal_patch_probe_v1 import (crop_image, anchor_positions, sample_positions,
    select_neighbors, group_stack, patch, stable_seed, inject, psnr, image_mse)
from s17_support_audit_v1 import create_masks, scores, decompose_error
from s18_nonlocal_group_half_v1 import (fit_group, group_half_prox,
    joint_objective, plot_panel, save_table)


def fit_group_guided(y, guide, rank, seed, lam, alpha, eta,
                     warmup, steps, check_every, beta):
    if beta == 0:
        return fit_group(y,guide,rank,seed,lam,alpha,eta,warmup,steps,check_every)
    if beta < 0: raise ValueError('beta must be >=0')
    scale=max(float(np.std(guide)),0.03)
    factors=init_factors(y.shape, rank, seed=seed, scale=scale)
    for _ in range(warmup):
        factors=mals_sweep(guide,factors,alpha=alpha,eta=eta)
    l=tritd(*factors)
    s=group_half_prox(y-l,lam)
    best_obj=float('inf');best=None;history=[]
    for step in range(steps+1):
        if step>0:
            t=(y-s+beta*guide)/(1+beta)
            factors=mals_sweep(t,factors,alpha=alpha/(1+beta),eta=eta/(1+beta))
            l=tritd(*factors)
            s=group_half_prox(y-l,lam)
        if step%check_every==0 or step==steps:
            data_obj=joint_objective(y,l,s,factors,lam,alpha)
            guide_pen=.5*beta*float(np.sum((l-guide)**2))
            obj=data_obj+guide_pen
            if not np.isfinite(obj):raise FloatingPointError('Nonfinite objective')
            support=np.linalg.norm(s,axis=1)>1e-10
            history.append(dict(iter=step,objective=obj,data_objective=data_obj,
                guide_penalty=guide_pen,support_count=int(support.sum()),
                residual=float(np.mean((y-l-s)**2)),
                guide_mse=float(np.mean((l-guide)**2))))
            if obj<best_obj:
                best_obj=obj;best=(l.copy(),s.copy(),step)
    return best[0],best[1],best[2],best_obj,history


def get_reference(csvpath, method):
    ref={}
    if csvpath:
        with open(csvpath,newline='',encoding='utf-8-sig') as f:
            for r in csv.DictReader(f):
                if r['method']==method:
                    if method=='blind_local':
                        ref[(r['image'],r['anchor'])]=float(r['psnr'])
                    else:
                        ref[(r['image'],r['anchor'],r['mask_method'],int(r['rank']))]=float(r['psnr'])
    return ref


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--s16-config',required=True)
    ap.add_argument('--s16-per-patch',default='')
    ap.add_argument('--s18-per-patch',default='')
    ap.add_argument('--ranks',default='2,3')
    ap.add_argument('--guide-betas',default='0,1,4')
    ap.add_argument('--mask-modes',default='consensus,adaptive')
    ap.add_argument('--max-anchors',type=int,default=9)
    ap.add_argument('--steps',type=int,default=60)
    ap.add_argument('--warmup',type=int,default=12)
    ap.add_argument('--check-every',type=int,default=10)
    ap.add_argument('--lam',type=float,default=0.05)
    ap.add_argument('--alpha',type=float,default=0.0001)
    ap.add_argument('--eta',type=float,default=0.001)
    ap.add_argument('--plot-anchors',type=int,default=2)
    ap.add_argument('--out',required=True)
    a=ap.parse_args()
    cfg=json.loads(Path(a.s16_config).read_text(encoding='utf-8-sig'))
    ranks=[int(x.strip()) for x in a.ranks.split(',')]
    betas=[float(x.strip()) for x in a.guide_betas.split(',')]
    masks=[x.strip() for x in a.mask_modes.split(',')]
    if (not ranks or min(ranks)<1 or max(ranks)>sorted([int(cfg['patch'])**2,3,int(cfg['group_size'])])[1]
        or not betas or min(betas)<0 or len(betas)!=len(set(betas))
        or not masks or any(m not in ('base','consensus','adaptive') for m in masks)
        or a.steps<1 or a.warmup<0 or a.check_every<1 or a.max_anchors<1):
        ap.error('Invalid rank, beta, mask mode, or run settings')
    root=Path(a.out)
    if root.exists() and any(root.iterdir()):ap.error(f'Refuse to overwrite: {root}')
    root.mkdir(parents=True,exist_ok=True)
    tag=root.name
    (root/f'{tag}_config.json').write_text(json.dumps(dict(s16=cfg,s19=vars(a),
        note='Ground truth evaluation only; all beta values predeclared; NOT test-PSNR selected'),
        indent=2),encoding='utf-8')
    s16ref=get_reference(a.s16_per_patch,'blind_local')
    s18ref=get_reference(a.s18_per_patch,'tritd_half_support_fill')
    n16=0;n18=0;rows=[];hrows=[]
    ps=int(cfg['patch']);group_k=int(cfg['group_size'])
    for file in [Path(x.strip()) for x in cfg['images'].split(',') if x.strip()]:
        if not file.exists():raise FileNotFoundError(file)
        clean,origin=crop_image(file,int(cfg['crop']),cfg['crop_policy'])
        yy,truth=inject(clean,float(cfg['rate']),cfg['mode'],stable_seed(
            file.name+str(origin)+cfg['mode']+str(float(cfg['rate'])),int(cfg['seed'])))
        med,all_masks=create_masks(yy,float(cfg['mask_threshold']))
        H,W=clean.shape[:2]
        candidates=sample_positions(H,W,ps,int(cfg['stride']))
        anchors=anchor_positions(H,W,ps,int(cfg['anchors']))[:a.max_anchors]
        for ai, anchor in enumerate(anchors):
            ii,jj=anchor
            target=patch(clean,ii,jj,ps)
            yanchor=patch(yy,ii,jj,ps)
            true_anchor=patch(truth,ii,jj,ps)
            if (file.stem,str(anchor)) in s16ref:
                base_mask=patch(all_masks['base'],ii,jj,ps)
                p16=np.where(base_mask[:,:,None],patch(med,ii,jj,ps),yanchor)
                deviation=abs(psnr(target,p16)-s16ref[(file.stem,str(anchor))])
                if deviation>1e-6:raise RuntimeError(f'S16 mismatch at {file.stem} {anchor}, delta={deviation}')
                n16+=1
            panel=[('Clean (evaluation)',target),('Corrupted Y',yanchor)]
            for maskmode in masks:
                mask=all_masks[maskmode]
                guide=np.where(mask[:,:,None],med,yy)
                neighbors=select_neighbors(guide,anchor,candidates,ps,group_k)
                Y=group_stack(yy,neighbors,ps)
                G=group_stack(guide,neighbors,ps)
                local_mask=patch(mask,ii,jj,ps)
                local=np.where(local_mask[:,:,None],patch(med,ii,jj,ps),yanchor)

                def report(method,rank,beta,pred,detected,sec=0.,sel='',obj=''):
                    diagnostic=scores(true_anchor,detected)
                    errors=decompose_error(target,pred,true_anchor,detected)
                    record=dict(image=file.stem,anchor=str(anchor),mask_method=maskmode,
                       method=method,rank=rank,guide_beta=beta,psnr=psnr(target,pred),
                       mse=image_mse(target,pred),seconds=sec,selected_iteration=sel,
                       objective=obj,**{key:diagnostic[key] for key in
                       ['precision','recall','f1','tp','fp','fn']},**errors)
                    rows.append(record)
                    return record
                local_record=report('local_median',0,'',local,local_mask)
                t0=time.perf_counter()
                Sref=group_half_prox(Y-G,a.lam)
                rs=Sref[:,:,0].reshape(ps,ps,3)
                support_ref=np.linalg.norm(rs,axis=2)>1e-10
                nofactor=np.where(support_ref[:,:,None],G[:,:,0].reshape(ps,ps,3),yanchor)
                report('no_tritd_group_half',0,'',nofactor,support_ref,time.perf_counter()-t0)
                if ai<a.plot_anchors:
                    panel.append((f'{maskmode} local {local_record["psnr"]:.2f}',local))
                for rank in ranks:
                    seed=stable_seed(f'S18:{file.stem}:{origin}:{anchor}:{maskmode}:{rank}',int(cfg['seed']))
                    for beta in betas:
                        start=time.perf_counter()
                        L,S,it,obj,history=fit_group_guided(Y,G,rank,seed,a.lam,
                                a.alpha,a.eta,a.warmup,a.steps,a.check_every,beta)
                        sec=time.perf_counter()-start
                        l_anchor=L[:,:,0].reshape(ps,ps,3)
                        s_anchor=S[:,:,0].reshape(ps,ps,3)
                        detected=np.linalg.norm(s_anchor,axis=2)>1e-10
                        fill=np.where(detected[:,:,None],l_anchor,yanchor)
                        ymS=np.clip(yanchor-s_anchor,0,1)
                        r=report('tritd_half_support_fill',rank,beta,fill,detected,sec,it,obj)
                        report('tritd_half_y_minus_s',rank,beta,ymS,detected,sec,it,obj)
                        report('tritd_half_lowrank_L',rank,beta,l_anchor,detected,sec,it,obj)
                        if beta==0 and (file.stem,str(anchor),maskmode,rank) in s18ref:
                            expected=s18ref[(file.stem,str(anchor),maskmode,rank)]
                            if abs(r['psnr']-expected)>1e-6:
                                raise RuntimeError(f'S18 beta0 mismatch: {file.stem} {anchor} '
                                                    f'{maskmode} r{rank}, now {r["psnr"]} vs {expected}')
                            n18+=1
                        if ai<a.plot_anchors and beta in (0,4):
                            panel.append((f'{maskmode} r{rank} beta={beta:g} {r["psnr"]:.2f}',fill))
                        for z in history:
                            hrows.append(dict(image=file.stem,anchor=str(anchor),
                                mask_method=maskmode,rank=rank,guide_beta=beta,
                                iter=z['iter'],objective=z['objective'],
                                data_objective=z.get('data_objective',z['objective']),
                                guide_penalty=z.get('guide_penalty',0.0),
                                support_count=z['support_count'],residual=z['residual'],
                                guide_mse=z.get('guide_mse',float('nan'))))
                print(f'{file.stem} {anchor} {maskmode} local={local_record["psnr"]:.2f}',flush=True)
            if ai<a.plot_anchors:
                plot_panel(root/f'{tag}_{file.stem}_a{ai:02d}_panel.png',panel,
                          f'S19 {file.stem} {anchor} mode={cfg["mode"]} rho={cfg["rate"]}')
            save_table(root/f'{tag}_per_patch.csv',rows)
        print('Image completed:',file.stem,flush=True)
    sm=[]
    for key in sorted(set((r['image'],r['mask_method'],r['method'],r['rank'],str(r['guide_beta'])) for r in rows)):
        subset=[r for r in rows if (r['image'],r['mask_method'],r['method'],r['rank'],str(r['guide_beta']))==key]
        m=np.mean([r['mse'] for r in subset]);base=float(np.mean([r['psnr'] for r in subset]))
        sm.append(dict(image=key[0],mask_method=key[1],method=key[2],rank=key[3],
           guide_beta=key[4],n=len(subset),mean_psnr=base,
           pooled_psnr=float(-10*np.log10(max(m,1e-15))),mean_mse=m,
           mean_f1=float(np.mean([r['f1'] for r in subset])),
           mean_seconds=float(np.mean([r['seconds'] for r in subset]))))
    save_table(root/f'{tag}_summary.csv',sm)
    save_table(root/f'{tag}_history.csv',hrows)
    print(f'PASS S16 baselines {n16}; PASS S18 beta=0 {n18}; outputs={root}',flush=True)

if __name__=='__main__':main()
