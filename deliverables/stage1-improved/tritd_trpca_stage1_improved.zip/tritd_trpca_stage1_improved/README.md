# 第一阶段：基于三重分解的张量鲁棒主成分分析（TriTD–Half TRPCA）

本工程只研究一个明确的数学问题：从**随机稀疏异常污染**的三阶张量 `Y=L*+S*` 中恢复低 triple-rank 张量 `L*`。不做高斯、条带、真实高光谱、深度展开。先建立基线、验证算法正确性，再考虑改进。

## 1. 模型和假设

`L* in R^(n1×n2×n3)` 满足 `rank_tri(L*) <= r`，`S*` 只有少量非零元素。三重分解约定：

```
L[i,j,k] = sum_{p=1}^r sum_{q=1}^r sum_{s=1}^r
           A[i,p,q] * B[s,j,q] * C[s,p,k]
A: n1×r×r; B: r×n2×r; C: r×r×n3.
```

**理想约束模型**：

```
min_{A,B,C,S}  sum_{i,j,k} sqrt(abs(S[i,j,k]))
s.t. Y = TriTD(A,B,C) + S.
```

**第一阶段实现的有限二次罚模型**（不是上面约束模型的严格等价重写）：

```
min_{A,B,C,S} F = 0.5*||Y-TriTD(A,B,C)-S||_F^2
                 + lam * sum sqrt(abs(S_ijk))
                 + alpha/2 * (||A||_F²+||B||_F²+||C||_F²).
```

* `lam` 决定稀疏惩罚；`alpha` 为因子正则。有限二次罚允许非零的拟合残差，所以一般不承诺 `Y=Lhat+Shat` 严格成立。
* `eta` **不属于目标函数**，只加入各因子更新的近端稳定子问题，不改变原目标函数的固定表达式。
* 这里 `S` 定义为**人为加入的外部稀疏污染**，不是干净图像的真实细节。
* 固定分解规模 `r` 是 triple rank 的**上界**，不等于证明实际 triple rank 恰好为 `r`。
* 若低triple秩张量本身稀疏，分离未必可辨识；本工程只测试随机生成的受控实例。

## 2. 数值算法（先MALS后Half）

给定 `S^k`，取 `Z=Y-S^k`。依次固定其他两个因子，更新A、B、C，且每个子问题加入 `eta/2*||Q-Q^k||_F²`。

对于mode-1的 `Z_(1)=A_(1)F`，`A_(1)` 为 `n1×r²`，`F` 为 `r²×(n2*n3)`，更新公式：

```
A_(1)^(k+1) = (Z_(1)F^T + eta*A_(1)^k)
              * (FF^T + (alpha+eta)I)^(-1).
```

B、C同理，在一次MALS sweep内使用更新后的前序因子。代码使用线性方程求解，不显式求矩阵逆。

给定新 `L=TriTD(A,B,C)`，令 `v=Y-L`，逐元素求解：

```
s_new = argmin_s 0.5*(s-v)^2 + lam*sqrt(abs(s)).
```

令阈值 `t=3/2 * lam^(2/3)`。当 `abs(v)<=t` 时更新为0；大于阈值时取三次方程对应的非零全局最小解。代码 `half_prox()` 实现了精确近端，临界阈值平局时选择零。

由于问题非凸，**目标函数单调下降不等于全局最优或必然正确恢复**。多次初始化仅按实际目标 `F` 选择最小的一次，绝不使用真实 `L*` 来选最优初始化。

## 3. 运行前准备

需要 Python 3.9+，CPU即可。此阶段数据规模小，不需要CUDA。

```bash
cd tritd_trpca_stage1
python -m pip install -r requirements.txt
python test_core.py
```

自动测试覆盖：显式三重求和、MALS的目标函数下降、Half近端的数值验证、合成数据的精确加性构造，以及完整算法目标函数下降。

## 4. 先做极小规模检查

```bash
python run_stage1.py \
  --dims 12,12,10 \
  --ranks 2 \
  --rates 0.05 \
  --seeds 2026 \
  --restarts 2 \
  --max-iter 100 \
  --lam 0.1 \
  --out outputs/smoke
```

检查 `outputs/smoke/best_per_case.csv` 是否生成，图像能否正常打开，所有误差是否为有限数，目标函数是否不增。

## 5. 第一轮正式受控实验

```bash
python run_stage1.py \
  --dims 20,20,16 \
  --ranks 2,3 \
  --rates 0.01,0.05,0.10 \
  --seeds 2026,2027,2028 \
  --restarts 3 \
  --max-iter 300 \
  --lam 0.1 \
  --alpha 0.0001 \
  --eta 0.001 \
  --amplitude 3 \
  --support-threshold 0.05 \
  --no-sparse-baseline \
  --out outputs/stage1_main
```

详细含义：

| 参数 | 作用 |
|---|---|
| `dims=20,20,16` | 三阶张量尺寸 |
| `ranks=2,3` | 同时用于生成与拟合的 triple rank 上界（表示能力已知） |
| `rates` | 稀疏污染支撑比例，均匀随机、不重复抽样 |
| `seeds` | 控制真实低秩张量和污染的生成 |
| `restarts=3` | 3次独立**求解初始化**（与真值数据的随机种子分离） |
| `amplitude=3` | 稀疏污染非零幅值在2.25到3.75之间，有随机正负符号；干净张量标准差归一化为1 |
| `lam=0.1` | Half正则权重，初始候选，并非理论最优 |
| `support-threshold=0.05` | **固定评价阈值**，不得使用真值选择阈值 |
| `alpha=1e-4`, `eta=1e-3` | 因子惩罚与数值稳定参数 |
| `no-sparse-baseline` | 增加一组不估计S、直接用MALS拟合含噪Y的内部对照 |

所有数值是便于起步的**实验初始值**，不是与实际传感器噪声匹配的物理单位。

## 6. 输出文件及如何读

```text
outputs/stage1_main/
├── config.json                 # 记录实际实验配置
├── all_runs.csv                # 每个初始化都保留，不能只报告成功者
├── best_per_case.csv           # 每个合成实例，按目标函数F选择最优初始化
├── summary_by_condition.csv    # 不同r和污染率的RRE、F1均值/标准差
├── no_sparse_baseline.csv      # 可选内部对照
├── histories/                 # 每次初始化的目标函数迭代曲线数据
├── reconstructions/           # L_true, S_true, Y, L_hat, S_hat
└── figures/                   # 单次实验的2×3重构图及汇总趋势图
```

最重要的指标：

```
RRE_L = ||L_hat-L_true||_F / ||L_true||_F  # 越小越好
Precision / Recall / F1                    # 稀疏污染位置识别
RRE_S = ||S_hat-S_true||_F / ||S_true||_F
Residual RRE = ||Y-L_hat-S_hat||_F / ||Y||_F  # 有限罚模型的可行性
Objective, time, iterations, converged
```

当真实污染率为0时，支撑F1约定需单独说明；当前默认实验只包括正污染率。

第一阶段可设一个**人为的实验成功判定**：`RRE_L < 1e-2` 且 `F1 >= 0.95`，报告满足的比例。它只是用于比较运行效果，**不是唯一恢复理论阈值或严格精确恢复证明**。

## 7. 第一轮之后才开始的难度实验

* 保持 `dims`、`r`、数据种子不变，分别将 `amplitude` 调整为 `1.0,2.0,3.0`，检查弱异常能否被Half识别。
* 扩大 `ranks` 到 `4`、增大尺寸到 `32,32,24`，增加 `restarts` 到 `5`，检查局部极小值与计算负担。
* 比较 `lam=0.03,0.1,0.3`；每组**重新运行**，只在独立验证用的随机种子上选参数，正式评价使用未参与调参的种子。
* 分别报告同一实例最优/最差初始化的指标、失败率，避免只看平均值。

第二步再考虑增加其他残余噪声、显式约束等式的增广拉格朗日法、带结构的污染、真实图像以及加速；当前阶段不做这些改动。

## 8. 故障排查

* **`import: command not found`**：把整段Python直接粘贴进了Bash；请运行 `python run_stage1.py ...`，不要把源码逐行作为Shell命令执行。
* **目标函数不下降**：先运行 `python test_core.py`，检查是否改动了因子维度和 einsum 指标顺序。
* **不同初始化表现差距大**：这是非凸模型的常见问题，增加初始化次数并完整报告所有运行，不能用真值选“最优”。
* **RRE很高但F1很高**：污染位置识别和低秩因子恢复是不同任务，必须同时报告。
* **F1很好但S不是精确真值**：有限二次罚下的Half会收缩污染幅值，`Y-L-S` 也可能非零。
* **性能差**：先检查异常幅值是否接近正常信号、`lambda`阈值是否合理、初始化是否失败；不要立即更改triple rank定义。

## 9. 论文表述的边界

实验生成的 `L_true` 在构造上满足 `rank_tri(L_true) <= r`，但这里**不证明它的最小triple rank恰好等于r**。这个阶段测试的是具有已知triple-rank上界的张量在稀疏污染下是否可恢复。

同样，这里使用随机独立稀疏污染，不代表已经解决真实高光谱混合噪声去除问题。
