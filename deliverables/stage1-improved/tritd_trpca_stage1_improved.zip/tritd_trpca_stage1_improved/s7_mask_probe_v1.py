#!/usr/bin/env python3
"""S7: Diagnose high-rank TriTD-Half RGB failures using masked TriTD fitting.

This is a DIAGNOSTIC, not a general TRPCA algorithm. It compares:
  previous S6 TriTD-Half restoration;
  observed-only saturation mask + masked TriTD ALS;
  oracle *true support* mask + masked TriTD ALS (upper-bound diagnostic only).

The original clean image and injected ground-truth S are used only for
EVALUATION and oracle-mask fitting; NEVER for auto-mask estimation/fit.
No existing S6 outputs are modified or overwritten.
"""
from __future__ import annotations
import argparse
import csv
import json
import time
from pathlib import Path
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tri_core import init_factors, mals_sweep, tritd


def parse_rates(rows):
    return sorted({round(float(r['rate']), 9) for r in rows if r['method'] == 'tritd_half'})


def csv_rows(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def psnr(x, z):
    z = np.clip(z, 0, 1)
    return -10 * np.log10(max(float(np.mean((z-x)**2)), 1e-15))


def ssim(x, z):
    try:
        from skimage.metrics import structural_similarity
        return float(structural_similarity(x, np.clip(z,0,1), data_range=1.0, channel_axis=2))
    except ImportError:
        return float('nan')


def counts(estimate, truth):
    tp = int(np.count_nonzero(estimate & truth))
    fp = int(np.count_nonzero(estimate & ~truth))
    fn = int(np.count_nonzero(~estimate & truth))
    p = tp/(tp+fp) if tp+fp else 0.
    r = tp/(tp+fn) if tp+fn else 0.
    f = 2*p*r/(p+r) if p+r else 0.
    return dict(mask_tp=tp, mask_fp=fp, mask_fn=fn,
                mask_precision=p, mask_recall=r, mask_f1=f)


def detect_saturated_rgb_pixels(y):
    """Observed ONLY: salt/pepper simulator writes whole pixels exactly 0 or 1.

    Works for THIS corruption protocol; may misclassify natural saturated pixels.
    For entry-wise noise and other corruptions this mask is inappropriate.
    """
    return np.all(y == 0.0,axis=2) | np.all(y == 1.0,axis=2)


def masked_als(y, mask2, rank, restarts, sweeps, alpha, eta, seed):
    """EM-imputation/ALS for partially observed TriTD; no image truth is accessed.

    Optimizes observed-only squared fidelity (with factor regularization) via
    sequential ALS on a surrogate that fills masked pixels with current L.
    Only compare objective values at the same mask/rank.
    """
    unmasked = ~mask2
    if not np.any(unmasked):
        raise ValueError('No observed pixels left after masking')
    usemask = mask2[:,:,None]
    values = y[unmasked]
    scale = max(float(np.std(values)), 1e-3)
    winner = None
    for j in range(restarts):
        factors = init_factors(y.shape, rank, seed=seed+j, scale=scale)
        for _ in range(sweeps):
            previous = tritd(*factors)
            surrogate_target = np.where(usemask, previous, y)
            factors = mals_sweep(surrogate_target, factors, alpha=alpha, eta=eta)
        pred = tritd(*factors)
        observed_fit = .5*float(np.sum((y[unmasked]-pred[unmasked])**2))
        regularizer = .5*alpha*sum(float(np.sum(f*f)) for f in factors)
        selection_score = observed_fit + regularizer
        if winner is None or selection_score < winner['masked_objective']:
            winner = dict(L=pred,masked_objective=selection_score,
                          restart=j,observed_fit=observed_fit)
    return winner


def write_csv(path, rows):
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(rows[0])); wr.writeheader(); wr.writerows(rows)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--runs',nargs='+',required=True,help='Existing S6 rank run directories (e.g. s6_rank3_v4, s6_rank6_v4, s6_rank8_v4)')
    ap.add_argument('--out',default='outputs/s7_mask_probe_v1')
    ap.add_argument('--sweeps',type=int,default=300)
    ap.add_argument('--restarts',type=int,default=2)
    ap.add_argument('--alpha',type=float,default=.0001)
    ap.add_argument('--eta',type=float,default=.001)
    args=ap.parse_args()
    if args.sweeps < 1 or args.restarts < 1 or min(args.alpha,args.eta) < 0 or args.alpha+args.eta <= 0:
        ap.error('Require positive sweeps and restarts, and nonnegative alpha/eta with positive sum.')
    dest=Path(args.out);tag=dest.name
    if dest.exists() and any(dest.iterdir()):
        raise SystemExit(f'Refusing to overwrite {dest}; choose new --out')
    runs=[]
    for folder in map(Path,args.runs):
        name=folder.name
        config_path=folder/f'{name}_config.json'
        metrics_path=folder/f'{name}_metrics.csv'
        if not config_path.exists() or not metrics_path.exists():
            raise SystemExit(f'Missing config/metrics in {folder}')
        cfg=json.loads(config_path.read_text(encoding='utf-8'))
        rows=csv_rows(metrics_path)
        runs.append(dict(folder=folder,name=name,cfg=cfg,rank=int(cfg['rank']),rates=parse_rates(rows),metric=rows))
    runs.sort(key=lambda d:d['rank'])
    if not runs or len({r['rank'] for r in runs})!=len(runs):
        raise SystemExit('Supply one or more unique ranks')
    anchor=runs[0]['cfg']
    must_equal=('source','original_size_hw','crop_top_left','crop_size','rates','noise_mode','seed')
    for r in runs[1:]:
        if [k for k in must_equal if r['cfg'].get(k)!=anchor.get(k)]:
            raise SystemExit(f'Mismatched S6 condition: {r["folder"]}. Need identical crop and corruption.')
    if anchor.get('noise_mode') != 'pixel':
        raise SystemExit('This diagnostic only supports S6 --noise-mode pixel (whole RGB salt/pepper)')
    dest.mkdir(parents=True)
    (dest/f'{tag}_config.json').write_text(json.dumps({**vars(args), 'source_s6_configs':[r['cfg'] for r in runs],
        'warning':'Oracle-mask fit uses known injected corruption locations; not a deployable method',
        'auto_mask':'Exact saturation RGB black/white from observed Y only (specific to salt/pepper)'},indent=2),encoding='utf-8')
    summaries=[]; panels={}
    for rate in runs[0]['rates']:
        rows_for_panel=[]
        for run in runs:
            r=run['rank'];root=run['folder'];run_name=run['name']
            case=f'r{r}_rho{str(rate).replace(".","p")}_pixel'
            array_path=root/f'{run_name}_{case}_arrays.npz'
            if not array_path.exists():
                raise SystemExit(f'Missing {array_path}')
            with np.load(array_path,allow_pickle=False) as z:
                clean=z['clean'].astype(np.float64)
                y=z['observed'].astype(np.float64)
                truth=z['sparse_true'].astype(np.float64)
                half=z['recovered'].astype(np.float64)
            mask_oracle=np.any(np.abs(truth)>1e-10,axis=2)
            mask_auto=detect_saturated_rgb_pixels(y)
            quality=counts(mask_auto,mask_oracle)
            print(f'r={r} rho={rate:.0%}: detected {mask_auto.sum()} pixels, true {mask_oracle.sum()}, '
                  f'mask F1={quality["mask_f1"]:.3f}, S6 Half PSNR={psnr(clean,half):.2f}',flush=True)
            images={'S6 TriTD-Half':half}
            for key,mask in [('Detected-mask TriTD',mask_auto),('Oracle-mask TriTD',mask_oracle)]:
                start=time.perf_counter()
                fit=masked_als(y,mask,r,args.restarts,args.sweeps,args.alpha,args.eta,
                               seed=int(anchor.get('seed',2026))*100+17)
                time_s=time.perf_counter()-start
                images[key]=fit['L']
                outrow=dict(rank=r,rate=rate,case=case,method='detected_mask' if key.startswith('Detected') else 'oracle_mask',
                    psnr=psnr(clean,fit['L']),ssim=ssim(clean,fit['L']),
                    s6_half_psnr=psnr(clean,half),s6_half_ssim=ssim(clean,half),
                    psnr_gain_vs_s6_half=psnr(clean,fit['L'])-psnr(clean,half),
                    fit_observed_mse=float(np.mean((y[~mask]-fit['L'][~mask])**2)),
                    n_masked_pixels=int(np.sum(mask)),pixel_total=int(mask.size),
                    selected_restart=fit['restart'],runtime_sec=time_s,
                    mask_f1_vs_injected=quality['mask_f1'] if key.startswith('Detected') else 1.0,
                    mask_precision_vs_injected=quality['mask_precision'] if key.startswith('Detected') else 1.0,
                    mask_recall_vs_injected=quality['mask_recall'] if key.startswith('Detected') else 1.0,
                    nominal_factor_params=r*r*sum(clean.shape),total_tensor_entries=int(clean.size))
                summaries.append(outrow)
                print('   ',key, 'PSNR',round(outrow['psnr'],3),'SSIM',round(outrow['ssim'],3),
                      'time',round(time_s,1),'s',flush=True)
            np.savez_compressed(dest/f'{tag}_{case}_results.npz',
                clean=clean,observed=y,baseline_half=half,
                detected_mask=mask_auto,oracle_mask=mask_oracle,
                detected_fit=images['Detected-mask TriTD'],oracle_fit=images['Oracle-mask TriTD'])
            for key,arr in [('s6_half',half),('detected_fit',images['Detected-mask TriTD']),('oracle_fit',images['Oracle-mask TriTD'])]:
                Image.fromarray(np.uint8(np.round(np.clip(arr,0,1)*255))).save(dest/f'{tag}_{case}_{key}.png')
            rows_for_panel.append((r,clean,y,images))
            write_csv(dest/f'{tag}_metrics.csv',summaries)
        panels[rate]=rows_for_panel
    for rate,rows in panels.items():
        fig,axs=plt.subplots(len(rows),5,figsize=(15,3.4*len(rows)),squeeze=False,constrained_layout=True)
        titles=['Original','Sparse-corrupted','S6 TriTD-Half','Detected-mask TriTD','Oracle-mask TriTD (diagnostic)']
        for i,(r,clean,y,images) in enumerate(rows):
            ims=[clean,y,images['S6 TriTD-Half'],images['Detected-mask TriTD'],images['Oracle-mask TriTD']]
            for j,z in enumerate(ims):
                ax=axs[i,j]
                ax.imshow(np.clip(z,0,1),interpolation='nearest')
                ax.axis('off')
                if i==0:ax.set_title(titles[j],fontsize=10)
                if j==0:ax.set_ylabel(f'r={r}',fontsize=12)
                if j>=2:
                    ax.text(.5,-.035,f'PSNR {psnr(clean,z):.2f} dB',transform=ax.transAxes,ha='center',fontsize=10)
        fig.suptitle(f'S7 support-mask diagnostic | salt/pepper {rate:.0%} | mask fitting only (not new TRPCA)',fontsize=12)
        fig.savefig(dest/f'{tag}_rho{str(rate).replace(".","p")}_comparison.png',dpi=170)
        plt.close(fig)
    print('Saved:',dest.resolve(),flush=True)
    print('NOTE: Saturation detection is specific to S6 salt-pepper; oracle mask uses known true support as an upper-bound diagnostic.',flush=True)

if __name__=='__main__':main()
