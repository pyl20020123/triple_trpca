#!/usr/bin/env python3
"""S16 exploratory NONLOCAL RGB-PATCH tensor masked-recovery probe.

This is NOT an end-to-end TRPCA solver. It evaluates whether third-order
TriTD on a stack of similar RGB patches predicts deliberately hidden pixels
better than simple local/nonlocal median repair. It reports both blind-mask
results (no true corruption positions used in fitting) and oracle-mask
DIAGNOSTIC results (known synthetic corruption locations).

Requirements: tri_core.py and s12_blind_impulse_v1.py in the project root;
numpy, scipy, pillow, matplotlib, scikit-image.
"""
from __future__ import annotations
import argparse, csv, json, hashlib
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.ndimage import median_filter
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tri_core import init_factors, tritd, mals_sweep
from s12_blind_impulse_v1 import inject, stable_seed, metrics


def patch(x, i, j, p):
    return x[i:i+p, j:j+p]


def sample_positions(h, w, p, stride):
    return [(i,j) for i in range(0,h-p+1,stride) for j in range(0,w-p+1,stride)]


def anchor_positions(h, w, p, n):
    span1=h-p;span2=w-p
    side=max(1,int(np.ceil(np.sqrt(n))))
    aa=np.linspace(max(0,span1//6),max(0,span1*5//6),side).round().astype(int)
    bb=np.linspace(max(0,span2//6),max(0,span2*5//6),side).round().astype(int)
    return list(dict.fromkeys((int(i),int(j)) for i in aa for j in bb))[:n]


def crop_image(path, width, policy):
    x=np.asarray(Image.open(path).convert('RGB'),dtype=np.float64)/255.
    h,w,_=x.shape
    if min(h,w)<width:
        raise ValueError(f'{path}: min image dimension {min(h,w)} < crop {width}')
    if policy=='center':
        i=(h-width)//2;j=(w-width)//2
    else:
        # Texture crop: select the most structured of nine deterministic areas,
        # ONLY from the noisy observation will groups be chosen afterward.
        # The clean image here determines a fixed development crop; NOT used in
        # any of the recovery/selection steps. Not suitable for blind benchmark.
        ih=np.linspace(0,h-width,3).astype(int)
        jw=np.linspace(0,w-width,3).astype(int)
        def energy(i,j):
            z=x[i:i+width,j:j+width]
            return float(np.mean(np.abs(np.diff(z,axis=0)))+
                         np.mean(np.abs(np.diff(z,axis=1))))
        i,j=max(((int(i),int(j)) for i in ih for j in jw),key=lambda a:energy(*a))
    return x[i:i+width,j:j+width].copy(),(int(i),int(j))


def group_stack(array, neighbors, p):
    return np.stack([patch(array,i,j,p).reshape(p*p,3) for i,j in neighbors],axis=2)


def select_neighbors(guide, anchor, positions, p, k):
    ref=patch(guide,*anchor,p).ravel()
    d=[]
    for pos in positions:
        if pos==anchor:continue
        z=patch(guide,*pos,p).ravel()
        d.append((float(np.mean((z-ref)**2)),pos))
    d.sort(key=lambda x:x[0])
    return [anchor]+[pos for _,pos in d[:k-1]]


def masked_group_fit(Y, init_guide, trusted, r, seed, steps=50, holdout=.10,
                     alpha=1e-4,eta=1e-3, warmup=15):
    """Fit TriTD with held-out trusted GROUP PIXELS for checkpoint selection.

    tensors: Y, init_guide shape (p*p,3,K); trusted shape(p*p,K).
    Validation pixels are withheld from ALS/warmup, but nonlocal grouping is
    selected using the observation-derived guide, so it is a PROXY holdout.
    Overlapping group patches may also share underlying image pixels.
    """
    rng=np.random.default_rng(seed)
    candidate=np.argwhere(trusted)
    if len(candidate)<40:raise ValueError('Too few trusted pixels in group')
    nval=max(4,int(len(candidate)*holdout))
    chosen=candidate[rng.permutation(len(candidate))[:nval]]
    train=trusted.copy();train[chosen[:,0],chosen[:,1]]=False
    scale=max(float(np.std(init_guide)),.03)
    fac=init_factors(Y.shape,r,seed=seed+991,scale=scale)
    # Validation pixel values must not enter the warmup factor fit directly.
    # Approximate those values using other matched patches in the group.
    init_train=init_guide.copy()
    for i,k in chosen:
        keep=np.arange(Y.shape[2])!=k
        init_train[i,:,k]=np.median(init_guide[i,:,keep],axis=0)
    for _ in range(warmup):
        fac=mals_sweep(init_train,fac,alpha=alpha,eta=eta)
    low=tritd(*fac)
    vi,vk=chosen[:,0],chosen[:,1]
    best_mse=float(np.mean((Y[vi,:,vk]-low[vi,:,vk])**2))
    best=low.copy();best_iter=0
    for it in range(1,steps+1):
        filled=np.where(train[:,None,:],Y,low)
        fac=mals_sweep(filled,fac,alpha=alpha,eta=eta)
        low=tritd(*fac)
        if it%5==0 or it==steps:
            mse=float(np.mean((Y[vi,:,vk]-low[vi,:,vk])**2))
            if np.isfinite(mse) and mse < best_mse:
                best_mse=mse;best=low.copy();best_iter=it
    return best,best_iter,best_mse


def image_mse(clean,recovered):
    return float(np.mean((clean-np.clip(recovered,0,1))**2))


def psnr(clean,recovered):
    return -10*np.log10(max(image_mse(clean,recovered),1e-15))


def chart(path, panels, title):
    fig,axs=plt.subplots(2,3,figsize=(12,8.2),constrained_layout=True)
    for ax,(label,z) in zip(axs.ravel(),panels):
        ax.imshow(np.clip(z,0,1),vmin=0,vmax=1,interpolation='nearest')
        ax.set_title(label,fontsize=10);ax.axis('off')
    for ax in axs.ravel()[len(panels):]:ax.axis('off')
    fig.suptitle(title,fontsize=11)
    fig.savefig(path,dpi=140);plt.close(fig)


def csv_write(path,rows):
    if not rows:return
    with open(path,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()));w.writeheader();w.writerows(rows)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--images',required=True,help='Comma-separated DIV2K PNG paths')
    ap.add_argument('--crop',type=int,default=128)
    ap.add_argument('--crop-policy',choices=['center','texture'],default='center')
    ap.add_argument('--patch',type=int,default=8)
    ap.add_argument('--stride',type=int,default=4)
    ap.add_argument('--group-size',type=int,default=12)
    ap.add_argument('--anchors',type=int,default=9)
    ap.add_argument('--ranks',default='2,3')
    ap.add_argument('--mode',choices=['random_rgb','additive_rgb'],default='random_rgb')
    ap.add_argument('--rate',type=float,default=.10)
    ap.add_argument('--mask-threshold',type=float,default=.20)
    ap.add_argument('--holdout',type=float,default=.10)
    ap.add_argument('--steps',type=int,default=50)
    ap.add_argument('--warmup',type=int,default=15)
    ap.add_argument('--alpha',type=float,default=.0001)
    ap.add_argument('--eta',type=float,default=.001)
    ap.add_argument('--seed',type=int,default=2026)
    ap.add_argument('--out',required=True)
    args=ap.parse_args()
    images=[Path(s.strip()) for s in args.images.split(',') if s.strip()]
    ranks=[int(s) for s in args.ranks.split(',')]
    if (not images or not ranks or not 0<args.rate<1 or not 0<args.holdout<.5 or
        args.crop<args.patch or args.patch<3 or args.group_size<2 or args.stride<1 or
        args.anchors<1 or args.steps<1 or args.warmup<0 or args.mask_threshold<=0 or
        min(ranks)<1 or max(ranks)>sorted((args.patch**2,3,args.group_size))[1]):
        ap.error('Invalid parameter set; note triple rank bound=median(p*p,3,K)')
    for p in images:
        if not p.exists():ap.error(f'Image does not exist: {p}')
    out=Path(args.out)
    if out.exists() and any(out.iterdir()):ap.error(f'Output exists: {out}')
    out.mkdir(parents=True,exist_ok=True)
    tag=out.name
    (out/f'{tag}_config.json').write_text(json.dumps(vars(args),indent=2),encoding='utf-8')
    rows=[];dev_summary=[]
    for imagefile in images:
        clean,origin=crop_image(imagefile,args.crop,args.crop_policy)
        H,W,_=clean.shape
        y,truth=inject(clean,args.rate,args.mode,stable_seed(str(imagefile.name)+str(origin)+args.mode+str(args.rate),args.seed))
        med=median_filter(y,size=(3,3,1),mode='reflect')
        blind_mask=np.linalg.norm(y-med,axis=2)>args.mask_threshold
        guide=np.where(blind_mask[:,:,None],med,y)
        spots=sample_positions(H,W,args.patch,args.stride)
        anchors=anchor_positions(H,W,args.patch,args.anchors)
        for num,anchor in enumerate(anchors):
            neighbors=select_neighbors(guide,anchor,spots,args.patch,args.group_size)
            if len(neighbors)<args.group_size:raise RuntimeError('Not enough patches')
            yy=group_stack(y,neighbors,args.patch)
            gg=group_stack(guide,neighbors,args.patch)
            true_group=np.stack([patch(truth,*v,args.patch).reshape(-1) for v in neighbors],axis=1)
            blind_group=np.stack([patch(blind_mask,*v,args.patch).reshape(-1) for v in neighbors],axis=1)
            clean_anchor=patch(clean,*anchor,args.patch)
            y_anchor=patch(y,*anchor,args.patch)
            med_anchor=patch(med,*anchor,args.patch)
            blind_anchor=patch(blind_mask,*anchor,args.patch)
            truth_anchor=patch(truth,*anchor,args.patch)
            local_blind=np.where(blind_anchor[:,:,None],med_anchor,y_anchor)
            group_med=np.median(gg,axis=2).reshape(args.patch,args.patch,3)
            nonlocal_blind=np.where(blind_anchor[:,:,None],group_med,y_anchor)
            local_oracle=np.where(truth_anchor[:,:,None],med_anchor,y_anchor)
            panels=[('Clean (evaluation)',clean_anchor),('Corrupted',y_anchor),
                    (f'Blind local median {psnr(clean_anchor,local_blind):.2f}dB',local_blind),
                    (f'Blind nonlocal median {psnr(clean_anchor,nonlocal_blind):.2f}dB',nonlocal_blind)]
            for meth,pred in [('noisy',y_anchor),('blind_local',local_blind),
                              ('blind_nonlocal',nonlocal_blind),('oracle_local',local_oracle)]:
                rows.append(dict(image=imagefile.stem,origin=str(origin),anchor=str(anchor),
                                 mode=args.mode,rate=args.rate,method=meth,rank=0,
                                 psnr=psnr(clean_anchor,pred),
                                 mse=image_mse(clean_anchor,pred),
                                 true_mask_count=int(truth_anchor.sum()),
                                 blind_mask_count=int(blind_anchor.sum()),
                                 selected_iteration='',val_mse=''))
            for r in ranks:
                for mask_mode,mask in [('blind',blind_group),('oracle',true_group)]:
                    seed=stable_seed(f'{imagefile.stem}:{origin}:{anchor}:{r}:{mask_mode}',args.seed)
                    fitted,iteration,vmse=masked_group_fit(
                        yy,gg,~mask,r,seed,args.steps,args.holdout,args.alpha,args.eta,args.warmup)
                    reconstruct=fitted[:,:,0].reshape(args.patch,args.patch,3)
                    patchmask=blind_anchor if mask_mode=='blind' else truth_anchor
                    restored=np.where(patchmask[:,:,None],np.clip(reconstruct,0,1),y_anchor)
                    rows.append(dict(image=imagefile.stem,origin=str(origin),anchor=str(anchor),
                                     mode=args.mode,rate=args.rate,method=f'group_tritd_{mask_mode}',rank=r,
                                     psnr=psnr(clean_anchor,restored),mse=image_mse(clean_anchor,restored),
                                     true_mask_count=int(truth_anchor.sum()),
                                     blind_mask_count=int(blind_anchor.sum()),
                                     selected_iteration=iteration,val_mse=vmse))
                    if mask_mode=='blind':
                        panels.append((f'Blind Group-TriTD r={r}: {psnr(clean_anchor,restored):.2f}dB',restored))
                    print(f'{imagefile.stem} anchor={anchor} r={r} {mask_mode} '
                          f'PSNR={psnr(clean_anchor,restored):.2f} selected={iteration}',flush=True)
            # Limit panel images to six: for easy side-by-side inspection.
            heading=f'{imagefile.stem} {args.mode} rho={args.rate} anchor={anchor} (all same RGB scale)'
            chart(out/f'{tag}_{imagefile.stem}_a{num:02d}_panel.png',panels[:6],heading)
            csv_write(out/f'{tag}_per_patch.csv',rows)
        print(f'finished image {imagefile.stem} crop={origin}',flush=True)
    for key in sorted(set((row['image'],row['method'],row['rank']) for row in rows)):
        im,method,r=key
        vals=[a for a in rows if (a['image'],a['method'],a['rank'])==key]
        dev_summary.append(dict(image=im,mode=args.mode,rate=args.rate,method=method,rank=r,
                                n=len(vals),mean_psnr=float(np.mean([v['psnr'] for v in vals])),
                                median_psnr=float(np.median([v['psnr'] for v in vals])),
                                mean_mse=float(np.mean([v['mse'] for v in vals]))))
    csv_write(out/f'{tag}_summary.csv',dev_summary)
    print(f'Saved {out}. Oracle mask used ONLY in group_tritd_oracle and oracle_local diagnostic;'
          ' do not interpret oracle results as blind denoising.',flush=True)

if __name__=='__main__':main()
