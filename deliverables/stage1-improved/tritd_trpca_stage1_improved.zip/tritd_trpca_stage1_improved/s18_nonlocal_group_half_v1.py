#!/usr/bin/env python3
"""S18: blind nonlocal RGB patch TriTD + group-l1/2 recovery prototype.

Uses exactly S16's DIV2K crop/injection and patches. For each anchor group it
alternates factor MALS and the exact vector group-half proximal update on RGB
pixel vectors. S17's blind masks are used ONLY for grouping/warm starts; clean
image and injected support are used ONLY for evaluation. This is an exploratory
anchor-patch experiment, not full-image denoising or a trained model.

Requires tri_core.py, s16_nonlocal_patch_probe_v1.py,
s17_support_audit_v1.py and s12_blind_impulse_v1.py alongside this script.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
import time
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from tri_core import init_factors, mals_sweep, tritd
from s16_nonlocal_patch_probe_v1 import (crop_image, anchor_positions,
    sample_positions, select_neighbors, group_stack, patch, stable_seed,
    inject, psnr, image_mse)
from s17_support_audit_v1 import create_masks, scores, decompose_error


def group_half_prox(v: np.ndarray, lam: float) -> np.ndarray:
    """Exact prox of lam*sum_{u,k} sqrt(||s_{u,:,k}||_2).

    v shape (P,3,K). For each RGB vector with norm q, solve
    min_{t>=0} (t-q)^2/2 + lam sqrt(t). The global nonzero minimum
    exists iff q > 1.5*lam**(2/3). The positive norm t is found by
    bisection of t + lam/(2 sqrt(t)) == q on [lam**(2/3),q].
    """
    v=np.asarray(v,dtype=np.float64)
    if v.ndim!=3 or v.shape[1]!=3:
        raise ValueError('Expected tensor shape (P,3,K)')
    if lam<0:raise ValueError('lam must be nonnegative')
    if lam==0:return v.copy()
    q=np.linalg.norm(v,axis=1)
    threshold=1.5*lam**(2.0/3.0)
    active=q>threshold
    out=np.zeros_like(v)
    if not np.any(active):return out
    qa=q[active]
    lower=np.full_like(qa,lam**(2.0/3.0))
    upper=qa.copy()
    for _ in range(55):
        t=(lower+upper)*0.5
        f=t+lam/(2.0*np.sqrt(t))
        lower=np.where(f<qa,t,lower)
        upper=np.where(f>=qa,t,upper)
    magnitude=0.5*(lower+upper)
    scales=np.zeros_like(q)
    scales[active]=magnitude/qa
    out=v*scales[:,None,:]
    return out


def joint_objective(y,l,s,factors,lam,alpha):
    fit=.5*float(np.sum((y-l-s)**2))
    sparse=lam*float(np.sqrt(np.linalg.norm(s,axis=1)).sum())
    reg=.5*alpha*sum(float(np.sum(a*a)) for a in factors)
    return fit+sparse+reg


def fit_group(y,guide,rank,seed,lam,alpha,eta,warmup,steps,check_every):
    """Alternating block solver. Checkpoints chosen by MODEL OBJECTIVE only."""
    scale=max(float(np.std(guide)),0.03)
    factors=init_factors(y.shape,rank,seed=seed,scale=scale)
    for _ in range(warmup):
        factors=mals_sweep(guide,factors,alpha=alpha,eta=eta)
    l=tritd(*factors)
    s=group_half_prox(y-l,lam)
    best_obj=float('inf'); best=None; history=[]
    # At iteration 0, factors have already received 'warmup' MALS sweeps.
    for step in range(steps+1):
        if step>0:
            factors=mals_sweep(y-s,factors,alpha=alpha,eta=eta)
            l=tritd(*factors)
            s=group_half_prox(y-l,lam)
        if step%check_every==0 or step==steps:
            obj=joint_objective(y,l,s,factors,lam,alpha)
            if not np.isfinite(obj):raise FloatingPointError('Nonfinite joint objective')
            support=(np.linalg.norm(s,axis=1)>1e-10)
            history.append(dict(iter=step,objective=obj,support_count=int(support.sum()),
                                residual=float(np.mean((y-l-s)**2))))
            if obj<best_obj:
                best_obj=obj;best=(l.copy(),s.copy(),step)
    return best[0],best[1],best[2],best_obj,history


def save_table(path,rows):
    if not rows:return
    with open(path,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
        w.writeheader();w.writerows(rows)


def plot_panel(path,items,title):
    ncols=3;nrows=int(math.ceil(len(items)/ncols))
    fig,axes=plt.subplots(nrows,ncols,figsize=(12,4*nrows),constrained_layout=True)
    axs=np.ravel(axes)
    for ax,(label,z) in zip(axs,items):
        ax.imshow(np.clip(z,0,1),vmin=0,vmax=1,interpolation='nearest')
        ax.set_title(label,fontsize=9.2);ax.axis('off')
    for ax in axs[len(items):]:ax.axis('off')
    fig.suptitle(title,fontsize=11)
    fig.savefig(path,dpi=140);plt.close(fig)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--s16-config',required=True)
    ap.add_argument('--s16-per-patch',default='',help='Optional: check S16 blind_local PSNR reproduction')
    ap.add_argument('--out',required=True)
    ap.add_argument('--ranks',default='2,3')
    ap.add_argument('--mask-modes',default='consensus,adaptive',
                    help='Two S17 fixed methods (not chosen using ground truth)')
    ap.add_argument('--lam',type=float,default=0.05)
    ap.add_argument('--steps',type=int,default=60)
    ap.add_argument('--warmup',type=int,default=12)
    ap.add_argument('--check-every',type=int,default=10)
    ap.add_argument('--max-anchors',type=int,default=9)
    ap.add_argument('--alpha',type=float,default=1e-4)
    ap.add_argument('--eta',type=float,default=0.001)
    ap.add_argument('--plot-anchors',type=int,default=3,help='Per image, avoid giant PNG catalogs')
    args=ap.parse_args()
    config=json.loads(Path(args.s16_config).read_text(encoding='utf-8-sig'))
    ranks=[int(x) for x in args.ranks.split(',')]
    mask_modes=[x.strip() for x in args.mask_modes.split(',')]
    if (not ranks or min(ranks)<1 or max(ranks)>sorted((int(config['patch'])**2,3,int(config['group_size'])))[1]
        or not mask_modes or any(x not in ('base','consensus','adaptive') for x in mask_modes)
        or args.lam<=0 or args.steps<1 or args.warmup<0 or args.max_anchors<1 or args.check_every<1):
        ap.error('Invalid parameters, masks, or triple-rank bound')
    out=Path(args.out)
    if out.exists() and any(out.iterdir()):ap.error(f'Refuse to overwrite: {out}')
    out.mkdir(parents=True,exist_ok=True)
    tag=out.name
    (out/f'{tag}_config.json').write_text(json.dumps(dict(s16_config=config,s18_args=vars(args),
        note='Truth and clean are evaluation-only. No model selection uses ground truth.'),indent=2),encoding='utf-8')
    reference={}
    if args.s16_per_patch:
        with open(args.s16_per_patch,encoding='utf-8-sig',newline='') as f:
            for row in csv.DictReader(f):
                if row['method']=='blind_local':
                    reference[(row['image'],row['anchor'])]=float(row['psnr'])
    rows=[];history_rows=[];check_count=0
    ps=int(config['patch']);k=int(config['group_size'])
    for fname in [Path(x.strip()) for x in config['images'].split(',') if x.strip()]:
        if not fname.exists():raise FileNotFoundError(fname)
        clean,origin=crop_image(fname,int(config['crop']),config['crop_policy'])
        yy,truth=inject(clean,float(config['rate']),config['mode'],
            stable_seed(fname.name+str(origin)+config['mode']+str(float(config['rate'])),int(config['seed'])))
        med,masks=create_masks(yy,float(config['mask_threshold']))
        h,w=clean.shape[:2]
        candidates=sample_positions(h,w,ps,int(config['stride']))
        anchors=anchor_positions(h,w,ps,int(config['anchors']))[:args.max_anchors]
        for idx,anchor in enumerate(anchors):
            a,b=anchor
            x_clean=patch(clean,a,b,ps)
            x_noisy=patch(yy,a,b,ps)
            localmask=masks['base'][a:a+ps,b:b+ps]
            median_reference=np.where(localmask[:,:,None],patch(med,a,b,ps),x_noisy)
            if (fname.stem,str(anchor)) in reference:
                expected=reference[(fname.stem,str(anchor))]
                actual=psnr(x_clean,median_reference)
                if abs(actual-expected)>1e-6:raise RuntimeError(
                    f'S16 reproduction FAILED {fname.stem} {anchor}: {actual} vs {expected}')
                check_count+=1
            items=[('Clean (evaluation)',x_clean),('Corrupted Y',x_noisy)]
            for maskmode in mask_modes:
                blindmask=masks[maskmode]
                guide=np.where(blindmask[:,:,None],med,yy)
                group=select_neighbors(guide,anchor,candidates,ps,k)
                yg=group_stack(yy,group,ps)
                gg=group_stack(guide,group,ps)
                mask_anchor=patch(blindmask,a,b,ps)
                local=np.where(mask_anchor[:,:,None],patch(med,a,b,ps),x_noisy)
                def addrow(method,r,pred,eff_mask,seconds=0.0,iter_selected='',objective=''):
                    diag=scores(patch(truth,a,b,ps),eff_mask)
                    er=decompose_error(x_clean,pred,patch(truth,a,b,ps),eff_mask)
                    rows.append(dict(image=fname.stem,anchor=str(anchor),mask_method=maskmode,
                        method=method,rank=r,psnr=psnr(x_clean,pred),mse=image_mse(x_clean,pred),
                        time_sec=seconds,selected_iteration=iter_selected,objective=objective,
                        **{key:diag[key] for key in ['precision','recall','f1','tp','fp','fn']},**er))
                addrow('local_median',0,local,mask_anchor)
                # True support is NEVER used for recovery; oracle value only for interpreting ceiling.
                oracle=np.where(patch(truth,a,b,ps)[:,:,None],patch(med,a,b,ps),x_noisy)
                addrow('oracle_local_eval',0,oracle,patch(truth,a,b,ps))
                # Spatial-guide-only GroupHalf comparator: no factorization.
                t0=time.perf_counter()
                s_ref=group_half_prox(yg-gg,args.lam)
                l_ref=gg[:,:,0].reshape(ps,ps,3)
                s_ref_anchor=s_ref[:,:,0].reshape(ps,ps,3)
                sparse_ref=np.linalg.norm(s_ref_anchor,axis=2)>1e-10
                fill_ref=np.where(sparse_ref[:,:,None],l_ref,x_noisy)
                addrow('no_tritd_group_half',0,fill_ref,sparse_ref,time.perf_counter()-t0)
                if idx<args.plot_anchors:
                    items.append((f'{maskmode} local {psnr(x_clean,local):.2f}dB',local))
                    items.append((f'{maskmode} noTriTD-Half {psnr(x_clean,fill_ref):.2f}dB',fill_ref))
                for rank in ranks:
                    seed=stable_seed(f'S18:{fname.stem}:{origin}:{anchor}:{maskmode}:{rank}',int(config['seed']))
                    start=time.perf_counter()
                    l,s,sel,obj,hist=fit_group(yg,gg,rank,seed,args.lam,args.alpha,args.eta,
                                                 args.warmup,args.steps,args.check_every)
                    elapsed=time.perf_counter()-start
                    l_anchor=l[:,:,0].reshape(ps,ps,3)
                    s_anchor=s[:,:,0].reshape(ps,ps,3)
                    detected=np.linalg.norm(s_anchor,axis=2)>1e-10
                    fill=np.where(detected[:,:,None],l_anchor,x_noisy)
                    ymins=np.clip(x_noisy-s_anchor,0,1)
                    addrow('tritd_half_support_fill',rank,fill,detected,elapsed,sel,obj)
                    addrow('tritd_half_y_minus_s',rank,ymins,detected,elapsed,sel,obj)
                    addrow('tritd_half_lowrank_L',rank,l_anchor,detected,elapsed,sel,obj)
                    if idx<args.plot_anchors:
                        items.append((f'{maskmode} TriTD-Half r={rank}: {psnr(x_clean,fill):.2f}dB',fill))
                    for histrow in hist:
                        history_rows.append(dict(image=fname.stem,anchor=str(anchor),
                            mask_method=maskmode,rank=rank,**histrow))
                print(f'{fname.stem} {anchor} {maskmode}: local {psnr(x_clean,local):.2f} dB; '
                      +', '.join(f'r{rank} {next(r["psnr"] for r in rows if r["image"]==fname.stem and r["anchor"]==str(anchor) and r["mask_method"]==maskmode and r["method"]=="tritd_half_support_fill" and r["rank"]==rank):.2f}' for rank in ranks),flush=True)
            if idx<args.plot_anchors:
                plot_panel(out/f'{tag}_{fname.stem}_a{idx:02d}_panel.png',items[:3*math.ceil(len(items)/3)],
                           f'S18 {fname.stem} {anchor} | {config["mode"]} rho={config["rate"]}')
            save_table(out/f'{tag}_per_patch.csv',rows)
        print('completed image',fname.stem,flush=True)
    summary=[]
    for key in sorted(set((r['image'],r['mask_method'],r['method'],r['rank']) for r in rows)):
        selected=[r for r in rows if (r['image'],r['mask_method'],r['method'],r['rank'])==key]
        summary.append(dict(image=key[0],mask_method=key[1],method=key[2],rank=key[3],
            n=len(selected),mean_psnr=float(np.mean([r['psnr'] for r in selected])),
            pooled_psnr=float(-10*np.log10(max(np.mean([r['mse'] for r in selected]),1e-15))),
            mean_mse=float(np.mean([r['mse'] for r in selected])),
            mean_f1=float(np.mean([r['f1'] for r in selected])),
            mean_sec=float(np.mean([r['time_sec'] for r in selected]))))
    save_table(out/f'{tag}_summary.csv',summary)
    save_table(out/f'{tag}_history.csv',history_rows)
    print(f'PASS S16 blind_local consistency: {check_count} anchors. Outputs: {out}',flush=True)

if __name__=='__main__':main()
