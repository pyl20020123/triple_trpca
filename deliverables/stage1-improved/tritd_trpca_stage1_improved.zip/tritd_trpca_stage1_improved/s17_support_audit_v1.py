#!/usr/bin/env python3
"""S17: reproduce S16's RGB corruption and audit blind support estimation.

No TriTD refit. Evaluates *fixed* masks on the SAME noisy observations,
and compares same masked local-median repair. True corruption mask is used
ONLY for evaluation/plots, never to create a blind mask or choose a method.
"""
from __future__ import annotations
import argparse, csv, json, hashlib
from pathlib import Path
import numpy as np
from scipy.ndimage import median_filter
from skimage.metrics import structural_similarity
def stable_seed(name, salt=0):
    value=int.from_bytes(hashlib.sha256(name.encode('utf-8')).digest()[:4],'little')
    return (value+salt)%(2**32)


def inject(clean, rho, mode, seed):
    rng=np.random.default_rng(seed)
    h,w,_=clean.shape
    count=int(round(rho*h*w))
    mask_flat=np.zeros(h*w,dtype=bool)
    mask_flat[rng.choice(h*w,size=count,replace=False)]=True
    locations=mask_flat.reshape(h,w)
    observed=clean.copy()
    if mode=='random_rgb':
        observed[locations,:]=rng.uniform(0.,1.,size=(count,3))
    elif mode=='additive_rgb':
        offset=rng.choice([-1.,1.],size=(count,3))*rng.uniform(.2,.5,size=(count,3))
        observed[locations,:]=np.clip(clean[locations,:]+offset,0.,1.)
    else: raise ValueError(mode)
    return observed,locations



def write_csv(path, rows):
    if not rows: return
    with open(path,'w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
        writer.writeheader();writer.writerows(rows)


def scores(true, det):
    tp=int(np.count_nonzero(true & det))
    fp=int(np.count_nonzero(~true & det))
    fn=int(np.count_nonzero(true & ~det))
    tn=int(np.count_nonzero(~true & ~det))
    pr=tp/(tp+fp) if tp+fp else 0.0
    re=tp/(tp+fn) if tp+fn else 0.0
    return {'true_count':tp+fn,'det_count':tp+fp,'tp':tp,'fp':fp,'fn':fn,'tn':tn,
            'precision':pr,'recall':re,'f1':2*pr*re/(pr+re) if pr+re else 0.0}


def psnr_mse(clean, pred):
    e=(np.clip(pred,0,1)-clean)**2
    mse=float(e.mean())
    return -10*np.log10(max(mse,1e-15)),mse


def decompose_error(clean,pred,true,det):
    err=np.sum((np.clip(pred,0,1)-clean)**2,axis=2)/3.0
    return dict(err_tp=float(np.sum(err[true&det])/true.size),
                err_fp=float(np.sum(err[~true&det])/true.size),
                err_fn=float(np.sum(err[true&~det])/true.size),
                err_tn=float(np.sum(err[~true&~det])/true.size))


def create_masks(y, base_threshold):
    med3=median_filter(y,size=(3,3,1),mode='reflect')
    med5=median_filter(y,size=(5,5,1),mode='reflect')
    d3=np.linalg.norm(y-med3,axis=2)
    d5=np.linalg.norm(y-med5,axis=2)
    # Two fixed, predeclared diagnostic alternatives. Neither uses clean or true mask.
    base=d3>base_threshold
    consensus=base & (d5>base_threshold)
    edge_disagreement=np.linalg.norm(med3-med5,axis=2)
    adaptive=d3>(base_threshold + 0.75*edge_disagreement)
    return med3,{'base':base, 'consensus':consensus,'adaptive':adaptive}


def diagnostic_fig(path, clean, y, med3, base, cons, true, image_id):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axs=plt.subplots(2,4,figsize=(14,7.4),constrained_layout=True)
    panels=[('Clean (evaluation only)',clean),('Corrupted Y',y),
            ('Original S16 blind median',np.where(base[:,:,None],med3,y)),
            ('Consensus-mask median',np.where(cons[:,:,None],med3,y))]
    for ax,(label,z) in zip(axs[0],panels):
        ax.imshow(np.clip(z,0,1),vmin=0,vmax=1,interpolation='nearest')
        ax.set_title(label,fontsize=10); ax.axis('off')
    for ax,title,pred in zip(axs[1],['True corruption (diagnostic)',
                                 'S16 detected (diagnostic)',
                                 'S16 false positives (orange)',
                                 'S16 missed corruption (magenta)'],
                             [true,base,base &~true,true &~base]):
        ax.imshow(pred.astype(float),cmap='gray',vmin=0,vmax=1,interpolation='nearest')
        ax.set_title(title,fontsize=10);ax.axis('off')
    fig.suptitle(f'{image_id} S17 blind-mask audit, truth only for diagnostic',fontsize=12)
    fig.savefig(path,dpi=145);plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--s16-config',required=True)
    parser.add_argument('--s16-per-patch',default='')
    parser.add_argument('--out',required=True)
    args=parser.parse_args()
    config=json.loads(Path(args.s16_config).read_text(encoding='utf-8-sig'))
    source=Path(args.s16_config).resolve()
    out=Path(args.out)
    if out.exists() and any(out.iterdir()):
        parser.error(f'Refusing to overwrite nonempty output: {out}')
    out.mkdir(parents=True,exist_ok=True)
    # S16's exact deterministic crop and patch positioning without importing a solver.
    from PIL import Image
    images=[Path(t.strip()) for t in config['images'].split(',') if t.strip()]
    patch_size=int(config['patch'])
    nanchors=int(config['anchors'])
    threshold=float(config['mask_threshold'])
    rows=[]; anchor_rows=[]
    original={}
    if args.s16_per_patch:
        with open(args.s16_per_patch,encoding='utf-8-sig',newline='') as f:
            for r in csv.DictReader(f):
                if r['method']=='blind_local':
                    original[(str(r['image']),r['anchor'])]=float(r['psnr'])
    max_diff=0.0; compared=0
    for fname in images:
        clean_all=np.asarray(Image.open(fname).convert('RGB'),dtype=np.float64)/255.
        sz=int(config['crop'])
        if min(clean_all.shape[:2])<sz: raise ValueError(f'Image too small: {fname}')
        if config['crop_policy']=='center':
            i=(clean_all.shape[0]-sz)//2;j=(clean_all.shape[1]-sz)//2
        else:
            xs=np.linspace(0,clean_all.shape[0]-sz,3).astype(int)
            ys=np.linspace(0,clean_all.shape[1]-sz,3).astype(int)
            def energy(a,b):
                z=clean_all[a:a+sz,b:b+sz]
                return float(np.mean(np.abs(np.diff(z,axis=0)))+np.mean(np.abs(np.diff(z,axis=1))))
            i,j=max(((int(a),int(b)) for a in xs for b in ys),key=lambda z:energy(*z))
        clean=clean_all[i:i+sz,j:j+sz].copy()
        rate=float(config['rate']);mode=config['mode']
        y,true=inject(clean,rate,mode,
                      stable_seed(str(fname.name)+str((int(i),int(j)))+mode+str(rate),int(config['seed'])))
        med3, dets=create_masks(y,threshold)
        side=max(1,int(np.ceil(np.sqrt(nanchors))))
        aa=np.linspace(max(0,(sz-patch_size)//6),max(0,(sz-patch_size)*5//6),side).round().astype(int)
        anchors=list(dict.fromkeys((int(a),int(b)) for a in aa for b in aa))[:nanchors]
        for label,mask in dets.items():
            pred=np.where(mask[:,:,None],med3,y)
            p,m=psnr_mse(clean,pred)
            r=dict(image=fname.stem,method=label,mode=mode,rate=rate,
                   psnr_full=p,mse_full=m,ssim_full=float(structural_similarity(clean,np.clip(pred,0,1),data_range=1.,channel_axis=2)))
            r.update(scores(true,mask));r.update(decompose_error(clean,pred,true,mask))
            rows.append(r)
            for anchor in anchors:
                ai,aj=anchor
                t=true[ai:ai+patch_size,aj:aj+patch_size]
                z=mask[ai:ai+patch_size,aj:aj+patch_size]
                c=clean[ai:ai+patch_size,aj:aj+patch_size]
                pr=pred[ai:ai+patch_size,aj:aj+patch_size]
                ap,am=psnr_mse(c,pr)
                rr=dict(image=fname.stem,anchor=str(anchor),method=label,
                        psnr=ap,mse=am)
                rr.update(scores(t,z));rr.update(decompose_error(c,pr,t,z))
                anchor_rows.append(rr)
                key=(fname.stem,str(anchor))
                if label=='base' and key in original:
                    diff=abs(ap-original[key]);max_diff=max(max_diff,diff);compared+=1
                    if diff>1e-6:
                        raise RuntimeError(f'S16 reproducibility mismatch {key}: {ap} vs {original[key]}')
        diagnostic_fig(out/f'{out.name}_{fname.stem}_mask_diagnostic.png',
                       clean,y,med3,dets['base'],dets['consensus'],true,fname.stem)
        print(f'{fname.stem}:',*[f'{k} {next(r["psnr_full"] for r in rows if r["image"]==fname.stem and r["method"]==k):.2f} dB' for k in dets],flush=True)
    write_csv(out/f'{out.name}_summary.csv',rows)
    write_csv(out/f'{out.name}_per_anchor.csv',anchor_rows)
    meta={'s16_config':str(source),'s16_per_patch':args.s16_per_patch,
          'blind_mask_methods':{
              'base':f'||Y-median3(Y)||_2 > {threshold:g}',
              'consensus':f'base AND ||Y-median5(Y)||_2 > {threshold:g}',
              'adaptive':f'||Y-median3(Y)||_2 > {threshold:g} + 0.75*||median3(Y)-median5(Y)||_2'},
          'check_S16_anchor_count':compared,'check_S16_max_abs_psnr_difference':max_diff,
          'note':'No method selected using clean image or true noise mask. Alternative masks are exploratory; do not tune to these evaluation results.'}
    (out/f'{out.name}_config.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(f'S16 PSNR reproduction passed for {compared} anchors (max abs diff={max_diff:.3g}). Saved: {out}')

if __name__=='__main__': main()
