#!/usr/bin/env python3
"""Blind RGB impulse repair. No clean image, true support or rank input."""
import argparse
from pathlib import Path
import numpy as np
from scipy.ndimage import median_filter, uniform_filter
from PIL import Image


def detect_impulses(y, threshold=0.16):
    m3 = median_filter(y, size=(3, 3, 1), mode='reflect')
    m5 = median_filter(y, size=(5, 5, 1), mode='reflect')
    distance = np.linalg.norm(y - m3, axis=2)
    edge = np.linalg.norm(m3 - m5, axis=2)
    # A real edge usually has at least two nearby pixels of similar RGB color.
    p = np.pad(y, ((1, 1), (1, 1), (0, 0)), mode='reflect')
    h, w = y.shape[:2]
    differences = np.stack([np.linalg.norm(y-p[1+dy:1+dy+h,1+dx:1+dx+w], axis=2)
        for dy in (-1,0,1) for dx in (-1,0,1) if dy or dx])
    road = np.partition(differences, 1, axis=0)[:2].mean(axis=0)
    mask = (distance > threshold + 0.5 * edge) & (road > threshold * 0.5)
    return mask, m3


def _repair(y, threshold=0.16, search_radius=8, neighbors=12):
    """Return repaired RGB and blind support; copy all unflagged pixels exactly.

    Matching uses observed, jointly reliable patch entries. The center is
    excluded from distances to avoid matching the impulse itself. Candidates
    with a flagged center never contribute a color. Median is fallback only.
    """
    y = np.asarray(y, dtype=np.float64)
    if y.ndim != 3 or y.shape[2] != 3 or min(y.shape[:2]) < 2:
        raise ValueError('Expected RGB HxWx3, H/W >= 2')
    if not np.isfinite(y).all() or y.min() < 0 or y.max() > 1:
        raise ValueError('Input must be finite and normalized to [0,1]')
    if not 0 < threshold < 1 or search_radius < 1 or neighbors < 1:
        raise ValueError('Invalid threshold, radius or neighbors')
    mask, median = detect_impulses(y, threshold)
    if not mask.any():
        return y.copy(), mask
    h,w = mask.shape
    radius = search_radius
    # Constant padding prevents reflected copies of a damaged pixel serving as donors.
    py = np.pad(y, ((radius,radius),(radius,radius),(0,0)), mode='reflect')
    valid = ~mask
    pv = np.pad(valid, radius, mode='constant', constant_values=False)
    coords = np.where(mask)
    distances, colors = [], []
    for dy in range(-radius,radius+1):
        for dx in range(-radius,radius+1):
            if not (dy or dx):
                continue
            z = py[radius+dy:radius+dy+h,radius+dx:radius+dx+w]
            vz = pv[radius+dy:radius+dy+h,radius+dx:radius+dx+w]
            common = valid & vz
            error = np.mean((y-z)**2, axis=2) * common
            count = uniform_filter(common.astype(float), size=5, mode='constant') * 25 - common
            total = uniform_filter(error, size=5, mode='constant') * 25 - error
            d = np.maximum(total, 0) / np.maximum(count, 1)
            d += 0.00002*(dy*dy+dx*dx)
            d[(count < 6) | ~vz] = np.inf
            distances.append(d[coords]); colors.append(z[coords])
    distances = np.stack(distances, axis=1)
    colors = np.stack(colors, axis=1)
    k = min(neighbors, distances.shape[1])
    ids = np.argpartition(distances, k-1, axis=1)[:,:k]
    ds = np.take_along_axis(distances, ids, axis=1)
    cs = np.take_along_axis(colors, ids[:,:,None], axis=1)
    best = np.min(ds,axis=1,keepdims=True)
    scale = np.maximum(np.where(np.isfinite(best),best,0), 0.0004)
    weights = np.exp(-np.minimum(ds / scale, 700)) * np.isfinite(ds)
    total = weights.sum(axis=1)
    estimate = (cs*weights[:,:,None]).sum(axis=1)/np.maximum(total[:,None],1e-30)
    estimate[total == 0] = median[coords][total == 0]
    result = y.copy(); result[coords] = np.clip(estimate,0,1)
    return result,mask


def repair(y, threshold=0.16, search_radius=8, neighbors=12, tile_size=128):
    """Bound memory for full images; halo covers detector plus matching windows."""
    y = np.asarray(y, dtype=np.float64)
    if tile_size < 1:
        raise ValueError('tile_size must be positive')
    if y.ndim != 3 or y.shape[2] != 3 or min(y.shape[:2]) < 2:
        raise ValueError('Expected RGB HxWx3, H/W >= 2')
    h,w = y.shape[:2]
    if max(h,w) <= tile_size:
        return _repair(y,threshold,search_radius,neighbors)
    result = np.empty_like(y); mask = np.zeros((h,w), dtype=bool)
    halo = search_radius + 4
    for i in range(0,h,tile_size):
        for j in range(0,w,tile_size):
            i1,j1 = min(i+tile_size,h),min(j+tile_size,w)
            a,b = max(i-halo,0),max(j-halo,0)
            z,m = _repair(y[a:min(i1+halo,h),b:min(j1+halo,w)],
                          threshold,search_radius,neighbors)
            result[i:i1,j:j1] = z[i-a:i1-a,j-b:j1-b]
            mask[i:i1,j:j1] = m[i-a:i1-a,j-b:j1-b]
    return result,mask


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',required=True); p.add_argument('--output',required=True)
    p.add_argument('--method',choices=['nonlocal','median'],default='nonlocal')
    p.add_argument('--threshold',type=float,default=None)
    p.add_argument('--search-radius',type=int,default=8)
    a=p.parse_args()
    y=np.asarray(Image.open(a.input).convert('RGB'),dtype=float)/255
    if a.method == 'median':
        med=median_filter(y,size=(3,3,1),mode='reflect')
        threshold=0.2 if a.threshold is None else a.threshold
        if not 0 < threshold < 1: p.error('threshold must be in (0,1)')
        mask=np.linalg.norm(y-med,axis=2)>threshold
        x=np.where(mask[:,:,None],med,y)
    else:
        x,mask=repair(y,0.16 if a.threshold is None else a.threshold,a.search_radius)
    out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True)
    Image.fromarray(np.rint(x*255).astype('uint8')).save(out)
    Image.fromarray(mask.astype('uint8')*255).save(out.with_name(out.stem+'_mask.png'))
    print(f'Saved {out}; repaired {mask.mean():.2%} of pixels')

if __name__=='__main__':main()
