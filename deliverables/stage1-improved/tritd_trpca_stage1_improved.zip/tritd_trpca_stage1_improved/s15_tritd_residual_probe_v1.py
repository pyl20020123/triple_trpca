#!/usr/bin/env python3
"""S15 diagnostic: does a *meaningful* TriTD residual correction beat blind median repair?

Uses DIV2K clean references ONLY for artificial corruption and final evaluation.
Method: construct M(Y) with channelwise local median; mark plausible corrupt
pixels from ||Y-M||_2 > 0.20. Train TriTD on residual Y-M only at *trusted*
pixels (||Y-M||_2 <= 0.07), keeping 10% of trusted pixels held out for
checkpoint selection. Predict residual at suspect pixels and replace with M+R.
This is a diagnostic inpainting pipeline, NOT a new TRPCA theorem/solver.
"""
from __future__ import annotations
import argparse, csv, json
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.ndimage import median_filter
from tri_core import init_factors, tritd, mals_sweep
from s12_blind_impulse_v1 import unique_clean_cases, inject, stable_seed
from s13_spatial_tritd_half_v1 import image_metrics


def write_csv(path, rows):
    if not rows: return
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def fit_residual(observed, median, confidence, rank, seed, iters, every, holdout, ridge, alpha, eta):
    H,W,C=observed.shape
    rng=np.random.default_rng(seed)
    trusted=np.argwhere(confidence)
    if len(trusted)<20:
        raise ValueError('Fewer than 20 trusted pixels: relax --low or inspect input')
    n_val=max(1,int(round(len(trusted)*holdout)))
    take=rng.permutation(len(trusted))
    val=trusted[take[:n_val]]
    train=confidence.copy()
    train[val[:,0],val[:,1]]=False
    D=observed-median
    # In masked-majorization ALS: replace missing entries with current L before a sweep.
    # Ridge on the *reconstructed residual* (not just factors) helps guard missing sites.
    factors=init_factors(observed.shape,rank,seed=seed+9001,
                         scale=max(float(np.std(D[train])),0.002))
    low=tritd(*factors)
    best={'iteration':0,'val_mse':float(np.mean(D[val[:,0],val[:,1]]**2)),
          'L':np.zeros_like(D),'train_mse':float(np.mean(D[train]**2))}
    trace=[dict(iteration=0,train_mse=best['train_mse'],val_mse=best['val_mse'])]
    for i in range(1,iters+1):
        surrogate=np.where(train[:,:,None],D,low)/(1.+ridge)
        factors=mals_sweep(surrogate,factors,alpha=alpha/(1.+ridge),eta=eta/(1.+ridge))
        low=tritd(*factors)
        if i%every==0 or i==iters:
            vmse=float(np.mean((D[val[:,0],val[:,1]]-low[val[:,0],val[:,1]])**2))
            tmse=float(np.mean((D[train]-low[train])**2))
            trace.append(dict(iteration=i,train_mse=tmse,val_mse=vmse))
            if np.isfinite(vmse) and vmse<best['val_mse']:
                best=dict(iteration=i,val_mse=vmse,train_mse=tmse,L=low.copy())
    return best,trace,int(train.sum()),int(len(val))


def picture(path, clean,Y,blind,methods,title):
    panels=[('Clean (evaluation only)',clean),('Corrupted Y',Y),('Blind median support fill',blind)]
    panels.extend(methods)
    ncols=3;nrows=(len(panels)+ncols-1)//ncols
    fig,axes=plt.subplots(nrows,ncols,figsize=(12,4*nrows),constrained_layout=True)
    for ax,(label,img) in zip(np.ravel(axes),panels):
        ax.imshow(np.clip(img,0,1),vmin=0,vmax=1)
        ax.set_title(label,fontsize=10);ax.axis('off')
    for ax in np.ravel(axes)[len(panels):]:ax.axis('off')
    fig.suptitle(title,fontsize=12)
    fig.savefig(path,dpi=140);plt.close(fig)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source',required=True,help='Existing S10 DEV folder with *_arrays.npz')
    ap.add_argument('--out',required=True)
    ap.add_argument('--modes',default='random_rgb,additive_rgb')
    ap.add_argument('--rates',default='0.05,0.10')
    ap.add_argument('--ranks',default='3,6')
    ap.add_argument('--max-patches',type=int,default=4)
    ap.add_argument('--seed',type=int,default=2026)
    ap.add_argument('--iters',type=int,default=120)
    ap.add_argument('--check-every',type=int,default=5)
    ap.add_argument('--holdout',type=float,default=0.10)
    ap.add_argument('--low',type=float,default=0.07)
    ap.add_argument('--high',type=float,default=0.20)
    ap.add_argument('--ridge',type=float,default=0.5)
    ap.add_argument('--alpha',type=float,default=0.0001)
    ap.add_argument('--eta',type=float,default=0.001)
    args=ap.parse_args()
    if not (0<args.holdout<.5 and 0<=args.low<args.high and args.iters>=1 and args.check_every>=1 and args.ridge>=0 and args.alpha>=0 and args.eta>0):
        ap.error('Invalid holdout, thresholds, iterations, ridge or stability parameters')
    ranks=[int(x) for x in args.ranks.split(',')]
    modes=[x.strip() for x in args.modes.split(',')]
    rates=[float(x) for x in args.rates.split(',')]
    if not ranks or min(ranks)<1 or any(m not in ('random_rgb','additive_rgb') for m in modes) or any(not 0<x<1 for x in rates):
        ap.error('Invalid ranks, modes or rates')
    out=Path(args.out)
    if out.exists() and any(out.iterdir()):ap.error(f'Output exists and is not empty: {out}')
    files=sorted(Path(args.source).rglob('*_arrays.npz'))
    if not files:ap.error('No existing S10 arrays found; check --source')
    cases=unique_clean_cases(files)
    if args.max_patches: cases=dict(sorted(cases.items())[:args.max_patches])
    out.mkdir(parents=True,exist_ok=True);tag=out.name
    (out/f'{tag}_config.json').write_text(json.dumps(vars(args),indent=2),encoding='utf-8')
    results=[]; curves=[]
    for image_id,clean in sorted(cases.items()):
      if max(ranks)>sorted(clean.shape)[1]:ap.error(f'Rank exceeds middle dimension of {clean.shape}')
      for mode in modes:
       for rate in rates:
        case=f'{image_id}__{mode}_rho{str(rate).replace(".","p")}'
        Y,truth=inject(clean,rate,mode,stable_seed(case,args.seed))
        med=median_filter(Y,size=(3,3,1),mode='reflect')
        dist=np.linalg.norm(Y-med,axis=2)
        suspect=dist>args.high
        trusted=dist<=args.low
        blind=np.where(suspect[:,:,None],med,Y)
        base=image_metrics(clean,blind)
        results.append(dict(case=case,mode=mode,rate=rate,method='blind_median',rank=0,
                            **base,holdout_mse='',selected_iteration='',trusted_pixels=int(trusted.sum()),suspect_pixels=int(suspect.sum())))
        images=[]
        for r in ranks:
            b,trace,ntrain,nval=fit_residual(Y,med,trusted,r,stable_seed(case,args.seed),
                                  args.iters,args.check_every,args.holdout,args.ridge,args.alpha,args.eta)
            recon=np.where(suspect[:,:,None],np.clip(med+b['L'],0,1),Y)
            met=image_metrics(clean,recon)
            results.append(dict(case=case,mode=mode,rate=rate,method='tritd_residual',rank=r,
                                **met,holdout_mse=b['val_mse'],selected_iteration=b['iteration'],
                                trusted_pixels=ntrain,suspect_pixels=int(suspect.sum())))
            images.append((f'TriTD residual r={r} | PSNR={met["psnr"]:.2f}',recon))
            for t in trace:curves.append(dict(case=case,rank=r,**t))
            print(f'{case}: r={r} base={base["psnr"]:.3f} corrected={met["psnr"]:.3f}, selected={b["iteration"]}, holdoutMSE={b["val_mse"]:.6g}',flush=True)
        picture(out/f'{tag}_{case}_panel.png',clean,Y,blind,images,case)
        write_csv(out/f'{tag}_per_case.csv',results)
        write_csv(out/f'{tag}_history.csv',curves)
    summary=[]
    groups=defaultdict(list)
    for x in results: groups[(x['mode'],x['rate'],x['method'],x['rank'])].append(x)
    for (mode,rate,method,r),items in sorted(groups.items()):
        summary.append(dict(mode=mode,rate=rate,method=method,rank=r,n=len(items),
                     mean_psnr=float(np.mean([x['psnr'] for x in items])),
                     mean_ssim=float(np.mean([x['ssim'] for x in items]))))
    write_csv(out/f'{tag}_summary.csv',summary)
    print('Saved',out,'\nDo not claim this is TRPCA: it is a residual-correction diagnostic. Clean truth used for evaluation only.')

if __name__=='__main__':main()
