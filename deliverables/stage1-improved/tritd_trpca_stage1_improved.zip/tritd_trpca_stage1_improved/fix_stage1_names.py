#!/usr/bin/env python3
"""Patch run_stage1.py to use run-tagged CSV filenames and protect existing runs.

Usage: python fix_stage1_names.py
Run in the tritd_trpca_stage1 project root.
Only current output-level summary CSV files are copied; history CSVs are unchanged.
"""
from __future__ import annotations
import argparse
import ast
import re
import shutil
from pathlib import Path

TABLES = ('all_runs.csv', 'best_per_case.csv', 'summary_by_condition.csv', 'no_sparse_baseline.csv')
MARKER = 'STAGE1_UNIQUE_CSV_NAMES_V2'


def patch_runner(root: Path) -> None:
    src = root / 'run_stage1.py'
    if not src.is_file():
        raise FileNotFoundError(f'Missing {src}: run inside the experiment project root.')
    original = src.read_text(encoding='utf-8')
    if MARKER in original:
        print(f'Already patched: {src}')
        return
    save_csv_pattern = re.compile(r'(?ms)^def save_csv\(path, rows\):\n.*?(?=^def |^if __name__|\Z)')
    replace = f'''def save_csv(path, rows):
    # {MARKER}
    if not rows:
        return
    path = Path(path)
    tag = path.parent.name
    if not path.name.startswith(tag + '_'):
        path = path.with_name(tag + '_' + path.name)
    with open(path, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


'''
    updated, n = save_csv_pattern.subn(lambda m: replace, original, count=1)
    if n != 1:
        raise RuntimeError('Could not locate save_csv() in run_stage1.py; nothing changed.')
    init_pattern = re.compile(r'(?m)^(\s*)out\s*=\s*Path\(args\.out\)\s*;\s*out\.mkdir\(parents=True,\s*exist_ok=True\)\s*$')
    guard = '''    out = Path(args.out)
    table_names = ('all_runs.csv', 'best_per_case.csv', 'summary_by_condition.csv', 'no_sparse_baseline.csv')
    if any((out / name).exists() or (out / (out.name + '_' + name)).exists() for name in table_names):
        raise SystemExit(f'Existing result tables in {out}; choose a NEW --out directory to avoid overwrite.')
    out.mkdir(parents=True, exist_ok=True)'''
    updated, n2 = init_pattern.subn(guard, updated, count=1)
    if n2 != 1:
        raise RuntimeError('Could not locate output initialization; nothing changed.')
    updated = updated.replace("print('Read summary_by_condition.csv and best_per_case.csv first.')",
                              "print(f'Read {out.name}_summary_by_condition.csv and {out.name}_best_per_case.csv first.')")
    ast.parse(updated, filename=str(src))
    backup = root / 'run_stage1_pre_namefix.py'
    if backup.exists():
        idx = 2
        while (root / f'run_stage1_pre_namefix_v{idx}.py').exists():
            idx += 1
        backup = root / f'run_stage1_pre_namefix_v{idx}.py'
    shutil.copy2(src, backup)
    src.write_text(updated, encoding='utf-8')
    print(f'Updated: {src}; backup: {backup}')


def copy_existing(root: Path) -> None:
    out = root / 'outputs'
    if not out.exists():
        print('No outputs/ folder found; nothing to copy.')
        return
    copied = 0
    for folder in sorted(out.iterdir()):
        if not folder.is_dir():
            continue
        for name in TABLES:
            old = folder / name
            if not old.is_file():
                continue
            new = folder / f'{folder.name}_{name}'
            if new.exists():
                print(f'Skip existing: {new}')
                continue
            shutil.copy2(old, new)
            copied += 1
            print(f'Copied: {new.name}')
    print(f'Copied {copied} existing table(s). Originals were preserved.')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--project', default='.', help='Path to tritd_trpca_stage1 project')
    args = ap.parse_args()
    root = Path(args.project).expanduser().resolve()
    patch_runner(root)
    copy_existing(root)
    print('Future tables will be named <output-folder>_<table-name>.csv.')
    print('Re-running into a directory with previous tables now fails instead of overwriting.')

if __name__ == '__main__':
    main()
