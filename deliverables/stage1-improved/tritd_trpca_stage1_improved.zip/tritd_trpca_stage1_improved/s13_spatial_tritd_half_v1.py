#!/usr/bin/env python3
"""S13: blind spatial-guided TriTD + RGB group-Half recovery on DIV2K patches.

Unlike original TriTD-Half L-only recovery, X is an independent clean-image variable.
The RGB median guide and adaptive weights are computed only from the corrupted Y;
true clean/true support are used exclusively for synthetic corruption and evaluation.

Target, with spatial median M(Y) and weights w(Y) fixed:
F = beta/2 ||Y-X-S||_F² + mu/2 ||X-TriTD(A,B,C)||_F²
  + tau/2 ||w*(X-M)||_F² + lam sum_pixels ||S_ij:||_2^(1/2)
  + alpha/2 sum ||factor||_F².
All variables are optimized by explicit block updates; spatial guide is a heuristic prior.
"""
from __future__ import annotations
import argparse
import csv
import json
import time
from collections import defaultdict
from pathlib import Path
import numpy as np
from scipy.ndimage import median_filter
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from skimage.metrics import structural_similarity
from tri_core import init_factors, tritd, mals_sweep, half_prox
from s12_blind_impulse_v1 import unique_clean_cases, inject, stable_seed, run_solver, mask_scores


def group_prox(v, gamma):
    mag=np.linalg.norm(v, axis=2, keepdims=True)
    rho=half_prox(mag, gamma)
    return v*(rho/np.maximum(mag,1e-12))


def image_metrics(clean,pred):
    arr=np.clip(pred,0.,1.)
    mse=float(np.mean((clean-arr)**2))
    return dict(psnr=-10*np.log10(max(mse,1e-15)),
                ssim=float(structural_similarity(clean,arr,data_range=1.,channel_axis=2)),
                mae=float(np.mean(abs(clean-arr))))


def csv_write(p,rows):
    if not rows:return
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def guide_from_noisy(y,delta_low,delta_high):
    median=median_filter(y,size=(3,3,1),mode='reflect')
    difference=np.linalg.norm(y-median,axis=2)
    weight=np.clip((difference-delta_low)/(delta_high-delta_low),0.,1.)
    return median,weight,difference


def guided_objective(y,x,s,factors,median,weight,beta,mu,tau,lam,alpha):
    L=tritd(*factors)
    return float(.5*beta*np.sum((y-x-s)**2) + .5*mu*np.sum((x-L)**2)
       +.5*tau*np.sum((weight[:,:,None]*(x-median))**2)
       +lam*np.sum(np.sqrt(np.linalg.norm(s,axis=2)))
       +.5*alpha*sum(np.sum(f*f) for f in factors))


def run_guided(y,rank,seed,alpha,eta,beta,mu,tau,lam,steps,warmup,delta_low,delta_high):
    med,w,dist=guide_from_noisy(y,delta_low,delta_high)
    # Local robust seed only uses corrupted observations and spatial statistics.
    x=y*(1-w[:,:,None])+med*w[:,:,None]
    s=y-x
    factors=init_factors(y.shape,rank,seed=seed,scale=max(float(np.std(x)),1e-3))
    for _ in range(warmup):
        factors=mals_sweep(x,factors,alpha=alpha/mu,eta=eta/mu)
    history=[]
    for itr in range(1,steps+1):
        # Factor block: mu/2 ||X-L||² + alpha/2 sum ||factor||².
        factors=mals_sweep(x,factors,alpha=alpha/mu,eta=eta/mu)
        L=tritd(*factors)
        w2=w[:,:,None]**2
        x=(beta*(y-s)+mu*L+tau*w2*med)/(beta+mu+tau*w2)
        s=group_prox(y-x,lam/beta)
        if itr == 1 or itr%10==0 or itr==steps:
            history.append(dict(iteration=itr,objective=guided_objective(y,x,s,factors,med,w,beta,mu,tau,lam,alpha)))
            if not np.isfinite(history[-1]['objective']):
                raise FloatingPointError('non-finite objective')
    L=tritd(*factors)
    return dict(X=x,L=L,S=s,median=med,weight=w,discrepancy=dist,history=history,
                final_objective=guided_objective(y,x,s,factors,med,w,beta,mu,tau,lam,alpha))


def save_panel(outfile,clean,y,methods):
    panels=[('Original clean (evaluation)',clean),('Corrupted observation',y)]+list(methods)
    ncol=3
    nrow=(len(panels)+ncol-1)//ncol
    fig,ax=plt.subplots(nrow,ncol,figsize=(13.5,4.2*nrow),constrained_layout=True)
    for a,(name,img) in zip(np.ravel(ax),panels):
        a.imshow(np.clip(img,0,1),vmin=0,vmax=1)
        a.set_title(name,fontsize=10)
        a.axis('off')
    for a in np.ravel(ax)[len(panels):]:a.axis('off')
    fig.savefig(outfile,dpi=150)
    plt.close(fig)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source',required=True,help='S10 DEV folder with *_arrays.npz')
    ap.add_argument('--out',default='outputs/s13_guided_dev_v1')
    ap.add_argument('--rank',type=int,default=3)
    ap.add_argument('--rates',default='0.05,0.10')
    ap.add_argument('--modes',default='random_rgb,additive_rgb')
    ap.add_argument('--max-patches',type=int,default=4)
    ap.add_argument('--seed',type=int,default=2026)
    ap.add_argument('--restarts',type=int,default=2)
    ap.add_argument('--steps',type=int,default=120)
    ap.add_argument('--warmup',type=int,default=25)
    ap.add_argument('--alpha',type=float,default=1e-4)
    ap.add_argument('--eta',type=float,default=1e-3)
    ap.add_argument('--beta',type=float,default=1.)
    ap.add_argument('--mu',type=float,default=0.08)
    ap.add_argument('--tau',type=float,default=16.)
    ap.add_argument('--lam',type=float,default=0.01)
    ap.add_argument('--delta-low',type=float,default=0.07)
    ap.add_argument('--delta-high',type=float,default=0.20)
    ap.add_argument('--support-threshold',type=float,default=0.05)
    ap.add_argument('--recompute-old',action='store_true',help='Recompute original S12 baseline on precisely the same synthetic cases')
    args=ap.parse_args()
    out=Path(args.out)
    if out.exists() and any(out.iterdir()):ap.error(f'Output already exists and nonempty: {out}')
    if args.mu<=0 or args.beta<=0 or args.tau<0 or args.lam<=0 or args.alpha<0 or args.eta<0:
        ap.error('Invalid objective parameters')
    if not 0<=args.delta_low<args.delta_high or args.rank<1 or args.restarts<1 or args.steps<1 or args.warmup<0:
        ap.error('Invalid dimensions or spatial guidance thresholds')
    modes=[x.strip() for x in args.modes.split(',')]
    rates=[float(x) for x in args.rates.split(',')]
    if not modes or any(x not in ('random_rgb','additive_rgb') for x in modes) or not rates or any(not 0<x<1 for x in rates):
        ap.error('Invalid corruption types/rates')
    source=Path(args.source)
    paths=sorted(source.rglob('*_arrays.npz'))
    if not paths:ap.error(f'No S10 arrays found at {source}')
    cases=unique_clean_cases(paths)
    if args.max_patches:cases=dict(sorted(cases.items())[:args.max_patches])
    out.mkdir(parents=True,exist_ok=True)
    tag=out.name
    (out/(tag+'_config.json')).write_text(json.dumps(vars(args),indent=2),encoding='utf-8')
    rows=[]
    for cid,clean in sorted(cases.items()):
      if args.rank>sorted(clean.shape)[1]:ap.error(f'Rank too large for {clean.shape}')
      for mode in modes:
       for rho in rates:
        case=f'{cid}__{mode}_rho{str(rho).replace(".","p")}'
        y,truth=inject(clean,rho,mode,stable_seed(case,args.seed))
        median,w,diff=guide_from_noisy(y,args.delta_low,args.delta_high)
        blind_mask=diff>.20  # S12 baseline uses .20; no ground truth used
        blind_fill=np.where(blind_mask[:,:,None],median,y)
        options=[]
        elapsed=0.
        for j in range(args.restarts):
            t=time.perf_counter()
            sol=run_guided(y,args.rank,args.seed*100+j+17,args.alpha,args.eta,args.beta,
                args.mu,args.tau,args.lam,args.steps,args.warmup,args.delta_low,args.delta_high)
            elapsed+=time.perf_counter()-t
            options.append(sol)
        sol=min(options,key=lambda x:x['final_objective'])
        X,S,L=sol['X'],sol['S'],sol['L']
        support=np.linalg.norm(S,axis=2)>args.support_threshold
        filled=np.where(support[:,:,None],X,y)
        variants={'noisy':y, 'full_median3x3':median,
                  'blind_median_fill':blind_fill,'guided_X':X,
                  'guided_support_fill':filled, 'guided_YminusS':y-S,
                  'guided_lowrank_L':L}
        for m,pred in variants.items():
            met=image_metrics(clean,pred)
            qual=mask_scores(truth,support if m.startswith('guided') else blind_mask) if m.startswith('guided') or m=='blind_median_fill' else None
            rows.append(dict(case=case,mode=mode,rate=rho,method=m,rank=args.rank,
                      **met,precision='' if qual is None else qual['precision'],
                      recall='' if qual is None else qual['recall'],f1='' if qual is None else qual['f1'],
                      runtime_s=elapsed if m=='guided_X' else ''))
        if args.recompute_old:
            t=time.perf_counter()
            base_candidates=[run_solver(y,args.rank,args.seed*100+j+17,args.alpha,args.eta,[(.10,220),(.03,80)]) for j in range(args.restarts)]
            old=min(base_candidates,key=lambda d:d['final_objective'])
            old_L,old_S=old['L'],old['S']
            old_support=np.linalg.norm(old_S,axis=2)>args.support_threshold
            for label,pred in [('old_tritd_half_L',old_L),('old_tritd_support_fill',np.where(old_support[:,:,None],old_L,y))]:
                met=image_metrics(clean,pred);q=mask_scores(truth,old_support)
                rows.append(dict(case=case,mode=mode,rate=rho,method=label,rank=args.rank,
                      **met,precision=q['precision'],recall=q['recall'],f1=q['f1'],runtime_s=time.perf_counter()-t if label=='old_tritd_half_L' else ''))
        save_panel(out/f'{tag}_{case}_panel.png',clean,y,[(n,variants[n]) for n in
                   ('blind_median_fill','guided_X','guided_support_fill','guided_YminusS','guided_lowrank_L','full_median3x3')])
        csv_write(out/f'{tag}_{case}_objective.csv',sol['history'])
        np.savez_compressed(out/f'{tag}_{case}_arrays.npz',clean=clean,Y=y,corrupt_true=truth,
                     estimated_X=X,estimated_L=L,estimated_S=S,estimated_support=support,blind_median=blind_fill)
        csv_write(out/f'{tag}_per_case.csv',rows)
        print(f'{case} | noisy={image_metrics(clean,y)["psnr"]:.2f} '
              f'guidedX={image_metrics(clean,X)["psnr"]:.2f} '
              f'guidedFill={image_metrics(clean,filled)["psnr"]:.2f} '
              f'blindMedian={image_metrics(clean,blind_fill)["psnr"]:.2f}',flush=True)
    groups=defaultdict(list)
    for r in rows:groups[(r['mode'],r['rate'],r['method'])].append(r)
    summary=[]
    for (mode,rho,method),dat in sorted(groups.items()):
        fs=[float(x['f1']) for x in dat if x['f1']!='']
        summary.append(dict(mode=mode,rate=rho,method=method,n_cases=len(dat),
                            mean_psnr=float(np.mean([x['psnr'] for x in dat])),
                            std_psnr=float(np.std([x['psnr'] for x in dat],ddof=1)) if len(dat)>1 else 0.,
                            mean_ssim=float(np.mean([x['ssim'] for x in dat])),
                            mean_f1=float(np.mean(fs)) if fs else ''))
    csv_write(out/f'{tag}_summary.csv',summary)
    print('Saved results:',out)
    print('NOTE: median guide is a spatial heuristic; do not attribute any gain solely to triple rank or group Half.')

if __name__=='__main__':main()
