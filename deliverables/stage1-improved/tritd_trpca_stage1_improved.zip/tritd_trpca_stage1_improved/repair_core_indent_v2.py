#!/usr/bin/env python3
"""Repair the rank-guard indentation in tri_core.fit_trpca safely.

Run in the project root: python repair_core_indent_v2.py
Only edits tri_core.py. A new timestamped backup is made before writing.
"""
from pathlib import Path
import ast
import datetime
import shutil

p = Path('tri_core.py')
if not p.is_file():
    raise SystemExit('ERROR: tri_core.py not found. Run in tritd_trpca_stage1 directory.')
s = p.read_text(encoding='utf-8')
lines = s.splitlines(keepends=True)

# Restrict the replacement to the fit_trpca function and to its argument-checking portion.
fn_idx = next((i for i, line in enumerate(lines) if line.startswith('def fit_trpca(')), None)
if fn_idx is None:
    raise SystemExit('ERROR: cannot find def fit_trpca(...); file left unchanged.')
start = next((i for i in range(fn_idx + 1, min(fn_idx + 45, len(lines)))
              if 'if Y.ndim != 3' in lines[i]), None)
if start is None:
    raise SystemExit('ERROR: cannot find original ndim/rank validation; file left unchanged.')
stop = next((i for i in range(start + 1, min(start + 25, len(lines)))
             if lines[i].lstrip().startswith('if min(lam, alpha, eta)')
             or lines[i].lstrip().startswith('scale = max(')), None)
if stop is None:
    raise SystemExit('ERROR: cannot find the next validation statement; file left unchanged.')

# The guard must be at the indentation depth used elsewhere in this function.
indent = ' ' * 4
replacement = [
    f'{indent}if Y.ndim != 3:\n',
    f'{indent}    raise ValueError("Input must be a third-order tensor")\n',
    f'{indent}if rank < 1 or rank > sorted(Y.shape)[1]:\n',
    f'{indent}    raise ValueError("rank must be between 1 and the middle dimension")\n',
]
updated = ''.join(lines[:start] + replacement + lines[stop:])
try:
    ast.parse(updated, filename=str(p))
except SyntaxError as exc:
    raise SystemExit(f'ERROR: modified source still invalid at line {exc.lineno}: {exc.msg}. File left unchanged.')

stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
backup = p.with_name(f'tri_core.py.before_indent_fix_{stamp}.bak')
if backup.exists():
    raise SystemExit(f'ERROR: backup already exists: {backup}; file left unchanged.')
shutil.copy2(p, backup)
p.write_text(updated, encoding='utf-8')
print('FIXED:', p)
print('BACKUP:', backup)
print('CHECK: tri_core.py parsed successfully')
