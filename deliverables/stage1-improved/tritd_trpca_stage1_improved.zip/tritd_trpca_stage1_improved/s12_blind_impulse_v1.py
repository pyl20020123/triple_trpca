#!/usr/bin/env python3
"""S12: BLIND RGB sparse-impulse study on already saved DIV2K S10 DEV patches.

Adds random-valued or additive pixel impulses. Neither algorithm nor heuristic
is given the true corruption mask. True clean and injection mask are only used
for synthetic corruption creation and evaluation. No neural-network training.

Requirements: tri_core.py, s4_cont_v1.py in same project folder; numpy scipy,
matplotlib, scikit-image. Source: S10 output with *_arrays.npz.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path
from statistics import mean, stdev

import numpy as np
from scipy.ndimage import median_filter
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tri_core import init_factors, tritd, half_prox, mals_sweep


def run_solver(y, rank, init_seed, alpha, eta, plan):
    factors = init_factors(y.shape, rank, seed=init_seed, scale=max(float(np.std(y)),1e-3))
    sparse = np.zeros_like(y, dtype=np.float64)
    for lam, num_iter in plan:
        for _ in range(num_iter):
            factors = mals_sweep(y-sparse, factors, alpha=alpha, eta=eta)
            lowrank = tritd(*factors)
            sparse = half_prox(y-lowrank, lam)
    lowrank = tritd(*factors)
    final_lam = plan[-1][0]
    obj = .5*float(np.sum((y-lowrank-sparse)**2)) \
          + final_lam*float(np.sqrt(np.abs(sparse)).sum()) \
          + .5*alpha*sum(float(np.sum(f**2)) for f in factors)
    return dict(L=lowrank,S=sparse,final_objective=obj)


def csvwrite(path, rows):
    if not rows:
        return
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)


def metrics(x, pred):
    pred = np.clip(pred, 0., 1.)
    mse = float(np.mean((x-pred)**2))
    from skimage.metrics import structural_similarity
    return dict(psnr=float(-10*np.log10(max(mse, 1e-15))),
                ssim=float(structural_similarity(x, pred, data_range=1., channel_axis=2)),
                mae=float(np.mean(np.abs(x-pred))))


def mask_scores(truth, pred):
    tp = int(np.count_nonzero(truth & pred))
    fp = int(np.count_nonzero(~truth & pred))
    fn = int(np.count_nonzero(truth & ~pred))
    p = tp/(tp+fp) if tp+fp else 0.
    r = tp/(tp+fn) if tp+fn else 0.
    f1 = 2*p*r/(p+r) if p+r else 0.
    return dict(precision=p, recall=r, f1=f1,
                true_support=int(truth.sum()), detected_support=int(pred.sum()))


def stable_seed(name, salt=0):
    value = int.from_bytes(hashlib.sha256(name.encode('utf-8')).digest()[:4], 'little')
    return (value + salt) % (2**32)


def inject(clean, rho, mode, seed):
    rng = np.random.default_rng(seed)
    h,w,_=clean.shape
    count = int(round(rho*h*w))
    mask_flat = np.zeros(h*w, dtype=bool)
    mask_flat[rng.choice(h*w, size=count, replace=False)] = True
    locations = mask_flat.reshape(h,w)
    observed = clean.copy()
    if mode == 'random_rgb':
        # Each chosen RGB vector is replaced by a random [0,1]^3 vector.
        observed[locations, :] = rng.uniform(0., 1., size=(count,3))
    elif mode == 'additive_rgb':
        # A signed random impulse is added to each channel at selected pixels.
        offset = rng.choice([-1.,1.], size=(count,3))*rng.uniform(.2,.5,size=(count,3))
        observed[locations, :] = np.clip(clean[locations,:] + offset, 0.,1.)
    else:
        raise ValueError(mode)
    # Include all intentionally changed positions in the injection mask. Due to
    # continuous random values, zero-change coincidences have probability zero.
    return observed, locations


def plot_panel(outfile, items, heading):
    ncols=3
    nrows=(len(items)+ncols-1)//ncols
    fig,axs=plt.subplots(nrows,ncols,figsize=(13.5,4.3*nrows),constrained_layout=True)
    for ax,(label, rgb) in zip(np.ravel(axs),items):
        ax.imshow(np.clip(rgb,0,1),vmin=0,vmax=1)
        ax.set_title(label,fontsize=11)
        ax.axis('off')
    for ax in np.ravel(axs)[len(items):]:
        ax.axis('off')
    fig.suptitle(heading)
    fig.savefig(outfile,dpi=160)
    plt.close(fig)


def unique_clean_cases(files):
    by_case = {}
    for file in files:
        with np.load(file, allow_pickle=False) as z:
            if 'clean' not in z:
                raise KeyError(f'{file}: missing clean')
            clean = np.asarray(z['clean'],dtype=np.float64)
        if clean.ndim!=3 or clean.shape[-1]!=3:
            raise ValueError(f'Expected RGB HxWx3: {file}')
        # S10 records two different rho cases for each patch: deduplicate by folder.
        name=file.parent.name
        by_case.setdefault(name,clean)
        if not np.allclose(by_case[name],clean,atol=1e-12,rtol=0):
            raise ValueError(f'S10 original clean mismatch in {name}')
    return by_case


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source',required=True,help='S10 DEV outputs folder containing *_arrays.npz')
    ap.add_argument('--out',default='outputs/s12_blind_impulse_dev_v1')
    ap.add_argument('--rank',type=int,default=3)
    ap.add_argument('--rates',default='0.05,0.10')
    ap.add_argument('--modes',default='random_rgb,additive_rgb')
    ap.add_argument('--restarts',type=int,default=2)
    ap.add_argument('--seed',type=int,default=2026)
    ap.add_argument('--alpha',type=float,default=0.0001)
    ap.add_argument('--eta',type=float,default=0.001)
    ap.add_argument('--support-threshold',type=float,default=0.05,
                    help='RGB norm threshold on estimated S for TriTD-Half support')
    ap.add_argument('--median-threshold',type=float,default=0.20,
                    help='RGB norm discrepancy from 3x3 median for BLIND candidate mask')
    ap.add_argument('--lambda-plan',default='0.10:220,0.03:80')
    ap.add_argument('--max-patches',type=int,default=4,help='0 = all unique S10 patch folders')
    args=ap.parse_args()
    root=Path(args.source)
    paths=sorted(root.rglob('*_arrays.npz'))
    if not paths:ap.error(f'No S10 *_arrays.npz inside {root}')
    cases=unique_clean_cases(paths)
    if args.max_patches > 0:
        cases=dict(list(sorted(cases.items()))[:args.max_patches])
    if args.rank < 1 or args.restarts < 1 or args.support_threshold <= 0 or args.median_threshold<=0:
        ap.error('Invalid rank/restarts/support/median-threshold')
    modes=[p.strip() for p in args.modes.split(',')]
    if not modes or any(m not in ('random_rgb','additive_rgb') for m in modes):
        ap.error('--modes must be subset of random_rgb,additive_rgb')
    rates=[float(p.strip()) for p in args.rates.split(',')]
    if any(not 0<p<1 for p in rates) or not rates:ap.error('Bad --rates')
    plan=[]
    for pair in args.lambda_plan.split(','):
        lam,steps=pair.split(':')
        lam,steps=float(lam),int(steps)
        if lam<=0 or steps<1:ap.error('Invalid lambda plan')
        plan.append((lam,steps))
    out=Path(args.out)
    if out.exists() and any(out.iterdir()):ap.error(f'Will not overwrite existing: {out}')
    out.mkdir(parents=True,exist_ok=True)
    tag=out.name
    (out/(tag+'_config.json')).write_text(json.dumps({**vars(args),'lambda_parsed':plan},indent=2),encoding='utf-8')
    rows=[]
    for sample_id,clean in sorted(cases.items()):
        if args.rank>sorted(clean.shape)[1]:
            raise ValueError(f'rank {args.rank} exceeds median dims {clean.shape}')
        for mode in modes:
            for rho in rates:
                case=f'{sample_id}__{mode}_rho{str(rho).replace(".","p")}'
                # Same data across methods; independent of any image truth quality ranking.
                y, truth = inject(clean,rho,mode,stable_seed(case,args.seed))
                med=median_filter(y,size=(3,3,1),mode='reflect')
                median_diff=np.linalg.norm(y-med,axis=2)
                blind_mask=median_diff > args.median_threshold
                blind_repair=np.where(blind_mask[:,:,None],med,y)
                candidates=[]
                for j in range(args.restarts):
                    fit=run_solver(y,args.rank,args.seed*100+j+17,args.alpha,args.eta,plan)
                    candidates.append(fit)
                fit=min(candidates,key=lambda a:a['final_objective'])
                L, S=fit['L'],fit['S']
                support=np.linalg.norm(S,axis=2)>args.support_threshold
                support_repair=np.where(support[:,:,None],L,y)
                comparisons=[('noisy',y,None),
                             ('median_full3x3',med,None),
                             ('median_blind_mask',blind_repair,blind_mask),
                             ('tritd_half_L',L,support),
                             ('tritd_half_YminusS',y-S,support),
                             ('tritd_half_support_fill_L',support_repair,support)]
                for meth,img,mask in comparisons:
                    records=metrics(clean,img)
                    q=mask_scores(truth,mask) if mask is not None else {}
                    rows.append(dict(case=case, image=sample_id, mode=mode, rate=rho,
                                     method=meth, rank=args.rank, **records,
                                     precision=q.get('precision',''),recall=q.get('recall',''),
                                     f1=q.get('f1',''), true_support=int(truth.sum()),
                                     estimated_support=q.get('detected_support','')))
                plot_panel(out/f'{tag}_{case}_panel.png',
                           [('Original clean (evaluation only)',clean),('Random sparse corruption Y',y),
                            ('TriTD-Half recovered L',L),('TriTD-Half support fill',support_repair),
                            ('Blind median-mask repair',blind_repair),('Full 3x3 median',med)],
                           f'{case} | same RGB display scale [0,1]')
                print(f'{case}: noisy={metrics(clean,y)["psnr"]:.2f} '
                      f'TriTD-L={metrics(clean,L)["psnr"]:.2f} '
                      f'TriTD-support={metrics(clean,support_repair)["psnr"]:.2f} '
                      f'blind-median={metrics(clean,blind_repair)["psnr"]:.2f} '
                      f'full-median={metrics(clean,med)["psnr"]:.2f}', flush=True)
                csvwrite(out/f'{tag}_per_case.csv',rows)
    group=defaultdict(list)
    for r in rows:group[(r['mode'],r['rate'],r['method'])].append(r)
    summary=[]
    for (mode,rho,meth),data in sorted(group.items()):
        ps=[float(x['psnr']) for x in data]
        ss=[float(x['ssim']) for x in data]
        ff=[float(x['f1']) for x in data if x['f1']!='']
        summary.append(dict(mode=mode,rate=rho,method=meth,n_cases=len(data),
                            mean_psnr=mean(ps),sd_psnr=stdev(ps) if len(ps)>1 else 0.,
                            mean_ssim=mean(ss),mean_f1=mean(ff) if ff else ''))
    csvwrite(out/f'{tag}_summary.csv',summary)
    print('Saved:',out.resolve(),flush=True)
    print('No extreme-value mask or oracle support used for any operational prediction.',flush=True)


if __name__=='__main__':
    main()
