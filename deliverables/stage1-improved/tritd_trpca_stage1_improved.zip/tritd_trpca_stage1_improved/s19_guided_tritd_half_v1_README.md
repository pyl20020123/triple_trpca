# S19: Guided nonlocal TriTD–GroupHalf diagnostic

## Purpose
S18 decreased the joint objective yet often worsened recovery. In particular,
TriTD appears to fit or retain corrupted colors. In S18 the blind spatial guide
was used only to initialize factors; it was absent from the optimized objective.

This diagnostic changes exactly that component, keeping the DIV2K crop,
injected corruption, nonlocal grouping, rank, GroupHalf proximal, and factor
solver consistent with S18.

## Mathematical model
For each nonlocal RGB patch tensor `Y` `(p*p,3,K)`, let `G` be a **blind** spatial
reference assembled from the corrupted observation using the S17 mask. Test

`F_beta(A,B,C,S) = 0.5||Y-L-S||_F^2
                  + beta/2||L-G||_F^2
                  + lam sum_{u,k} sqrt(||S[u,:,k]||_2)
                  + alpha/2 (||A||_F^2 + ||B||_F^2 + ||C||_F^2),`

where `L = TriTD(A,B,C)`.

At fixed sparse component `S`, the two L-fidelity terms are equivalent, up to a
constant, to a least-squares target

`T_beta = (Y - S + beta*G)/(1+beta)`.

The factor update reuses `mals_sweep(T_beta, factors, alpha=alpha/(1+beta),
eta=eta/(1+beta))`. At fixed factors, S is updated with the exact RGB vector
GroupHalf proximal operator from S18. Model checkpoints minimize `F_beta`
without inspecting ground truth. Different beta models have different objective
functions; **compare them via held-out development recovery metrics, not raw
objective values across beta**.

## Controlled experimental groups
- `beta=0`: calls S18's original `fit_group` verbatim. If you provide S18's
  per-patch CSV, its support-fill PSNR is checked exactly (`1e-6` tolerance).
- `beta=1`: add explicit moderate blind-guide fidelity.
- `beta=4`: add stronger blind-guide fidelity.
- Same ranks `2,3`, mask methods `consensus,adaptive`, `lam=0.05`, warmup 12,
  steps 60, images/corruption/neighbors, plus **fixed** no-TriTD GroupHalf and
  local-median controls.

All beta settings are fixed *before* looking at clean-image results. Don't
choose the best beta on each evaluation patch using its true clean image.

## Install
Copy `s19_guided_tritd_half_v1.py` into `~/tritd_trpca_stage1` alongside
`tri_core.py`, S16, S17 and S18 Python files.

```
cd ~/tritd_trpca_stage1
python -m py_compile s19_guided_tritd_half_v1.py
```

## Small compatibility smoke test

```
python -u s19_guided_tritd_half_v1.py \
  --s16-config outputs/s16_nonlocal_dev_random_v1/s16_nonlocal_dev_random_v1_config.json \
  --s16-per-patch outputs/s16_nonlocal_dev_random_v1/s16_nonlocal_dev_random_v1_per_patch.csv \
  --ranks 2,3 --guide-betas 0,1,4 --mask-modes consensus,adaptive \
  --max-anchors 1 --steps 5 --warmup 12 --lam 0.05 \
  --out outputs/s19_guided_smoke_v1
```

WARNING: The S18 strict reproduction check requires the SAME `--steps` as
S18 (60), since the S18 result selects the minimum model objective. Thus for
this five-step smoke test, **omit `--s18-per-patch`**. It is retained in the
full experiment below.

## Full development experiment (18 anchors)

```
python -u s19_guided_tritd_half_v1.py \
  --s16-config outputs/s16_nonlocal_dev_random_v1/s16_nonlocal_dev_random_v1_config.json \
  --s16-per-patch outputs/s16_nonlocal_dev_random_v1/s16_nonlocal_dev_random_v1_per_patch.csv \
  --s18-per-patch outputs/s18_nonlocal_group_half_dev_v1/s18_nonlocal_group_half_dev_v1_per_patch.csv \
  --ranks 2,3 --guide-betas 0,1,4 --mask-modes consensus,adaptive \
  --max-anchors 9 --steps 60 --warmup 12 --lam 0.05 \
  --alpha 0.0001 --eta 0.001 \
  --out outputs/s19_guided_tritd_dev_v1
```

## Outputs
Results live in a newly named output folder. No existing experiment folder
will be overwritten.

- `s19_guided_tritd_dev_v1_config.json`
- `s19_guided_tritd_dev_v1_summary.csv`: grouped mean PSNR, pooled PSNR,
  average support F1, mean runtime
- `s19_guided_tritd_dev_v1_per_patch.csv`: paired per-anchor metrics for each
  beta/rank/mask; includes TP/FP/FN and error attribution
- `s19_guided_tritd_dev_v1_history.csv`: objective, residual, support count,
  guide penalty, guide MSE at each checkpoint
- `s19_guided_tritd_dev_v1_0722_a00_panel.png` etc: visual results

## Decision criteria
- Primary: fixed beta settings should be evaluated independently against the
  **same-mask local median and no-TriTD GroupHalf** baselines for **both**
  DIV2K scenes, *not just average across smooth and textured scenes*.
- Compare anchor PSNR, pooled MSE/PSNR, correct-detected pixel reconstruction
  errors, support F1 and failure cases. A larger F1 by itself does not imply a
  better recovered image.
- If all guided variants still underperform or need very large beta to imitate
  the median baseline, do not continue tuning r or beta. Reconsider the model:
  group construction/matching, protected clean-pixel fidelity, and genuine
  image reconstruction variable separate from the low-rank component.

## Validation status
Source code passes Python syntax check and ran end-to-end with a simulated
`tri_core` backend. In that backend `beta=0` output reproduced S18 exactly.
No claim of improved real DIV2K performance is made until you run the full
experiment using your actual `tri_core.py` implementation.
