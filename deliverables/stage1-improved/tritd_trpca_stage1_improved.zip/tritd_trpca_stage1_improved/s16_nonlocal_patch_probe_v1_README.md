# S16 Nonlocal Patch Tensor: feasibility probe

**Goal:** Check if third-order TriTD on a stack of *similar* 8x8 RGB patches contributes to recovering randomly corrupted pixels, before rebuilding TriTD–Half/TRPCA. This diagnostic is **not** a complete blind robust tensor PCA model.

## Tensor layout

Choose K=12 similar 8x8 RGB patches from a corrupted 128x128 DIV2K crop, by searching patches in an observation-only median-guided image. Stack as `64 x 3 x 12` (in-patch spatial position x RGB channel x patch index). A third-order triple-decomposition rank r=2/3 is permitted even though the RGB dimension is 3. `tri_core.py` provides the unchanged factorization, reconstruction and MALS sweep.

## Requires

`tri_core.py` and `s12_blind_impulse_v1.py` in the project root; Python packages numpy, scipy, pillow, matplotlib, scikit-image.

## Command

```bash
cd ~/tritd_trpca_stage1
python -m py_compile s16_nonlocal_patch_probe_v1.py
python -u s16_nonlocal_patch_probe_v1.py \
  --images data/DIV2K/DIV2K_train_HR/0722.png,data/DIV2K/DIV2K_train_HR/0724.png \
  --crop 128 --crop-policy center \
  --patch 8 --stride 4 --group-size 12 --anchors 9 \
  --ranks 2,3 --mode random_rgb --rate 0.10 \
  --steps 50 --warmup 15 --out outputs/s16_nonlocal_dev_random_v1
```

Repeat for additive corruption only if the first run is informative, using a **new** output directory, `--mode additive_rgb --out outputs/s16_nonlocal_dev_additive_v1`.

## Saved results

- `s16_nonlocal_dev_random_v1_per_patch.csv`: each anchor and method's PSNR, known true corrupted pixel count, estimated corrupted count, and selected checkpoint.
- `s16_nonlocal_dev_random_v1_summary.csv`: per-image mean anchor PSNR, for noisy, blind local repair, blind nonlocal median, oracle local repair, blind Group-TriTD for r=2/3, oracle Group-TriTD for r=2/3.
- `s16_nonlocal_dev_random_v1_*_a00_panel.png`, etc.: six matching 8x8 anchor patches (clean, corrupted, local median, nonlocal median, blind TriTD r2, blind TriTD r3) at a consistent RGB display scale.

Only the blind rows are plausible blind-recovery candidates; oracle support uses the artificially injected true mask for **diagnostic comparison only**. Matching is done on the observed guide. The holdout within the selected group is a **proxy validation**, not a statistically independent test: group patches may overlap in the original image and matching is performed beforehand. Selection never uses clean original pixel values. The image-level `center` crop is deterministic.

Do not interpret a high PSNR on 8x8 selected anchor patches as full-image performance; aggregation into a full 128x128 restored image and comparison across larger varied images will be needed if this pilot succeeds.

## Decision criteria

1. Group-TriTD blind PSNR > blind local median **and** blind nonlocal median on a meaningful fraction of anchors, without destroying edges or colors: nonlocal TriTD structure warrants further study.
2. Group-TriTD oracle improves but blind does not: prioritize accurate support estimation / group-Half before higher rank.
3. Both Group-TriTD blind and oracle are consistently inferior to median references: further rethink grouping/tensor model; do not add learnable stages prematurely.
