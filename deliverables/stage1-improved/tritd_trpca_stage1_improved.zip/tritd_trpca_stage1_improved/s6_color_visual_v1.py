#!/usr/bin/env python3
"""S6: Visualize TriTD-Half sparse-corruption recovery on a REAL RGB photograph.

Place next to tri_core.py and s4_cont_v1.py in tritd_trpca_stage1.
Requires numpy, matplotlib, Pillow; --input demo additionally requires scikit-image.
Never overwrites a nonempty output directory.
"""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tri_core import tritd, init_factors, mals_sweep
from s4_cont_v1 import run_solver


def parse_floats(v):
    return [float(z.strip()) for z in v.split(',') if z.strip()]


def load_photo(spec, patch, fx, fy):
    if spec == 'demo':
        try:
            from skimage.data import astronaut
        except ImportError as e:
            raise RuntimeError('Demo needs scikit-image: python -m pip install scikit-image') from e
        rgb = np.asarray(astronaut(), dtype=np.uint8)
        source = 'skimage.data.astronaut'
    else:
        f = Path(spec)
        if not f.exists():
            raise FileNotFoundError(f'Photo missing: {f}. Supply --input /path/to/photo.jpg, or --input demo.')
        with Image.open(f) as im:
            rgb = np.asarray(im.convert('RGB'), dtype=np.uint8)
        source = str(f)
    h,w = rgb.shape[:2]
    if patch < 8:
        raise ValueError('Patch must be at least 8')
    if min(h,w) < patch:
        raise ValueError(f'Photo {h}x{w} smaller than patch={patch}; choose smaller --patch')
    x = int(round(fx*(w-1))); y=int(round(fy*(h-1)))
    left = max(0,min(w-patch, x-patch//2))
    top = max(0,min(h-patch, y-patch//2))
    result = rgb[top:top+patch,left:left+patch,:].astype(np.float64)/255.
    return result, dict(source=source, original_size_hw=[h,w], crop_top_left=[top,left], crop_size=patch)


def add_saltpepper(x, fraction, seed, mode):
    if not 0 <= fraction <=1:
        raise ValueError('fraction outside [0,1]')
    rng = np.random.default_rng(seed)
    y = x.copy()
    if mode == 'pixel':
        n = int(round(fraction*x.shape[0]*x.shape[1]))
        ids = rng.choice(x.shape[0]*x.shape[1],size=n,replace=False)
        sel = np.zeros(x.shape[0]*x.shape[1],dtype=bool)
        sel[ids] = True
        mask = sel.reshape(x.shape[:2])
        vals = rng.choice([0.,1.],size=(n,1))
        y[mask,:] = vals
    elif mode == 'entry':
        n=int(round(fraction*x.size))
        ids=rng.choice(x.size,size=n,replace=False)
        yr=y.reshape(-1)
        yr[ids] = rng.choice([0.,1.],size=n)
    else:
        raise ValueError(f'unknown corruption mode={mode}')
    # S_true=Y-X EXACTLY. For a color photo, some altered pixels may already equal 0/1.
    return y, y-x


def clean_oracle(target, rank, alpha, eta, iters, starts, init_base):
    """Least squares TriTD on known clean or polluted tensor WITHOUT S."""
    best=None
    scale=max(float(np.std(target)),1e-3)
    for j in range(starts):
        factors=init_factors(target.shape,rank,seed=init_base+j,scale=scale)
        for _ in range(iters):
            factors=mals_sweep(target,factors,alpha=alpha,eta=eta)
        l=tritd(*factors)
        score=0.5*float(np.sum((target-l)**2))+alpha/2*sum(float(np.sum(f*f)) for f in factors)
        if best is None or score<best[0]:
            best=(score,l)
    return best[1]


def image_metrics(x,pred):
    raw_mse=float(np.mean((x-pred)**2))
    clipped=np.clip(pred,0,1)
    mse=float(np.mean((x-clipped)**2))
    rec=dict(psnr_display=float(-10*np.log10(max(mse,1e-15))),
             psnr_raw=float(-10*np.log10(max(raw_mse,1e-15))),
             mae_display=float(np.mean(np.abs(x-clipped))),
             value_clip_fraction=float(np.mean((pred<0)|(pred>1))))
    try:
        from skimage.metrics import structural_similarity
        rec['ssim_display']=float(structural_similarity(x,clipped,data_range=1.0,channel_axis=2))
    except ImportError:
        rec['ssim_display']=float('nan')
    return rec


def half_support_metrics(s_true,s_hat,threshold):
    gt=np.abs(s_true)>1e-10
    pred=np.abs(s_hat)>threshold
    tp=np.sum(gt&pred);fp=np.sum(~gt&pred);fn=np.sum(gt&~pred)
    prec=float(tp/max(tp+fp,1));recall=float(tp/max(tp+fn,1))
    f1=2*prec*recall/(prec+recall) if prec+recall else 0.
    return dict(precision=prec,recall=recall,f1=f1,
                true_support_count=int(gt.sum()),estimated_support_count=int(pred.sum()))


def write_csv(path,rows):
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def save_panel(out, tag, case, x, y, oracle, direct, recovered, sparse_est, true_sparse):
    # All displayed RGBs use the SAME physical [0,1] scaling (no per-panel contrast adjustment).
    panels=[('Original clean RGB',x),('Sparse-corrupted RGB',y),
            ('Clean TriTD fit (oracle reference)',oracle),
            ('Direct TriTD fit on corrupted Y',direct),('TriTD-Half recovered L',recovered),
            ('Recovered |L - clean| (enhanced)',None)]
    fig,axes=plt.subplots(2,3,figsize=(13.5,9.2),constrained_layout=True)
    for ax,(name,z) in zip(axes.flat,panels):
        if z is None:
            # Errors rescaled only in THIS panel; raw values are in CSV.
            m=np.mean(np.abs(recovered-x),axis=2)
            p99=np.percentile(m,99)
            img=ax.imshow(m,cmap='magma',vmin=0,vmax=max(float(p99),1e-6))
            fig.colorbar(img,ax=ax,fraction=.04)
        else:
            ax.imshow(np.clip(z,0,1))
        ax.set_title(name,fontsize=10);ax.axis('off')
    fig.suptitle(case+' | same RGB display scale for all photographs',fontsize=12)
    fig.savefig(out/f'{tag}_{case}_panel.png',dpi=180)
    plt.close(fig)
    fig,ax=plt.subplots(1,3,figsize=(12.6,4.0),constrained_layout=True)
    vmax=max(float(np.quantile(np.abs(true_sparse),.999)),.001)
    for a,(name,data) in zip(ax,[('True corruption S*',true_sparse),
                                  ('Estimated corruption S',sparse_est),
                                  ('Absolute S error',np.abs(true_sparse-sparse_est))]):
        if name.startswith('Absolute'):
            image=a.imshow(np.mean(data,axis=2),cmap='magma',vmin=0,vmax=max(vmax/2,.001))
        else:
            image=a.imshow(np.mean(data,axis=2),cmap='coolwarm',vmin=-vmax,vmax=vmax)
        fig.colorbar(image,ax=a,fraction=.045)
        a.set_title(name,fontsize=11);a.axis('off')
    fig.savefig(out/f'{tag}_{case}_sparse.png',dpi=180);plt.close(fig)
    for name,z in [('clean',x),('corrupted',y),('oracle',oracle),('direct',direct),('recovered',recovered)]:
        Image.fromarray(np.uint8(np.round(np.clip(z,0,1)*255))).save(out/f'{tag}_{case}_{name}.png')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',default='demo',help='demo (skimage astronaut), or photo filename')
    p.add_argument('--patch',type=int,default=48)
    p.add_argument('--center-x',type=float,default=.43,help='Crop center as horizontal fraction 0..1')
    p.add_argument('--center-y',type=float,default=.23,help='Crop center as vertical fraction 0..1')
    p.add_argument('--rank',type=int,default=3,help='Triple factor size; RGB third dimension does not force r<=3')
    p.add_argument('--rates',default='0.05,0.10')
    p.add_argument('--noise-mode',choices=['pixel','entry'],default='pixel')
    p.add_argument('--seed',type=int,default=2026)
    p.add_argument('--restarts',type=int,default=2)
    p.add_argument('--alpha',type=float,default=.0001)
    p.add_argument('--eta',type=float,default=.001)
    p.add_argument('--support-threshold',type=float,default=.05)
    p.add_argument('--out',default='outputs/s6_color_demo_v1')
    args=p.parse_args()
    if not (1 <= args.rank <= args.patch) or args.restarts<1 or not (0<=args.center_x<=1 and 0<=args.center_y<=1):
        p.error('Require 1 <= rank <= patch, restarts>=1 and crop center fractions in [0,1]')
    if args.alpha<0 or args.eta<0 or args.alpha+args.eta<=0:
        p.error('Require nonnegative alpha,eta, alpha+eta>0')
    rates=parse_floats(args.rates)
    if not rates or any(r<=0 or r>=1 for r in rates) or len(rates)!=len(set(rates)):
        p.error('Expected unique rates in (0,1)')
    out=Path(args.out); tag=out.name
    if out.exists() and any(out.iterdir()):
        raise SystemExit(f'Refusing overwrite of {out}. Use another --out directory.')
    out.mkdir(parents=True,exist_ok=True)
    clean,src=load_photo(args.input,args.patch,args.center_x,args.center_y)
    # S5 showed two-stage continuation was comparable to the full path on synthetic data.
    plan=[(.10,220),(.03,80)]
    (out/f'{tag}_config.json').write_text(json.dumps({**vars(args),**src,
        'denoised_image_definition':'TriTD L, not Y-S',
        'image_display':'RGB clipped to [0,1], raw array preserved in NPZ',
        'note':'A real RGB photograph is not guaranteed to be low triple rank. Oracle is fitted only as diagnostic.',
        'continuation_plan':plan},indent=2,ensure_ascii=False),encoding='utf-8')
    # The clean TriTD fit is a representation diagnostic ONLY. Its clean input is never used by corruption solvers.
    oracle=clean_oracle(clean,args.rank,args.alpha,args.eta,300,args.restarts,args.seed*10+9001)
    np.savez_compressed(out/f'{tag}_clean_reference.npz',clean=clean,oracle=oracle)
    records=[]
    for rate in rates:
        case=f'r{args.rank}_rho{str(rate).replace(".","p")}_{args.noise_mode}'
        y,s_true=add_saltpepper(clean,rate,args.seed+int(1000*rate),args.noise_mode)
        # Naive (no S) baseline fitted to corrupted input.
        direct=clean_oracle(y,args.rank,args.alpha,args.eta,300,args.restarts,args.seed*10+1001)
        contenders=[]
        for j in range(args.restarts):
            initseed=args.seed*100+j+17
            fit=run_solver(y,args.rank,initseed,args.alpha,args.eta,plan)
            contenders.append((fit['final_objective'],j,fit))
        _,best_restart,fit=min(contenders,key=lambda q:q[0])
        rec=fit['L']; est=fit['S']
        for method,pred in [('noisy',y),('clean_oracle',oracle),('direct_tritd',direct),('tritd_half',rec)]:
            records.append(dict(case=case,rate=rate,rank=args.rank,method=method,
                                selected_restart=best_restart if method=='tritd_half' else '',
                                **image_metrics(clean,pred),
                                **(half_support_metrics(s_true,est,args.support_threshold) if method=='tritd_half' else dict(precision='',recall='',f1='',true_support_count='',estimated_support_count='')),
                                objective_final=float(fit['final_objective']) if method=='tritd_half' else '',
                                residual_fit_rre=float(np.linalg.norm(y-rec-est)/max(np.linalg.norm(y),1e-12)) if method=='tritd_half' else ''))
        save_panel(out,tag,case,clean,y,oracle,direct,rec,est,s_true)
        np.savez_compressed(out/f'{tag}_{case}_arrays.npz',clean=clean,observed=y,
                            sparse_true=s_true, sparse_est=est,oracle=oracle,direct=direct,recovered=rec)
        write_csv(out/f'{tag}_metrics.csv',records)
        m={t['method']:t for t in records if t['case']==case}
        print(f'{case}: Noisy PSNR={m["noisy"]["psnr_display"]:.2f}, '
              f'clean fit={m["clean_oracle"]["psnr_display"]:.2f}, '
              f'direct={m["direct_tritd"]["psnr_display"]:.2f}, '
              f'TriTD-Half={m["tritd_half"]["psnr_display"]:.2f}, '
              f'F1={m["tritd_half"]["f1"]:.3f}',flush=True)
    print('Saved to',out.resolve(),flush=True)
    print('Important: clean-fit is ORACLE DIAGNOSTIC, not usable from polluted input.',flush=True)

if __name__=='__main__':main()
