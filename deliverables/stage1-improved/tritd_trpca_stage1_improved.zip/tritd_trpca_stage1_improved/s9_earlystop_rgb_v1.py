#!/usr/bin/env python3
"""S9: independent validation-based early stopping for S8 high-rank masked TriTD.

Read matched S6 color experiments and detect this experiment's exactly black/white
RGB salt-and-pepper pixels from the observation ONLY. Make distinct validation
and test holdouts from remaining observed pixels. Fit masked TriTD using EM/ALS.
Select iteration + restart by validation error (never test or clean truth).
Compare that checkpoint with the 300-sweep endpoint of the SAME restart.
The image's known clean original is used ONLY for final reporting and plotting.

Diagnostic only, NOT an improved generic TRPCA / unknown-support recovery method.
"""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
from tri_core import init_factors, mals_sweep, tritd
from s7_mask_probe_v1 import detect_saturated_rgb_pixels
from s8_mask_holdout_v1 import validate_inputs


def save_csv(path, rows):
    if not rows:
        return
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)


def psnr_mask(x, z, mask, clipped=False):
    a = np.clip(z,0,1) if clipped else z
    mse = float(np.mean((x[mask]-a[mask])**2))
    return float(-10*np.log10(max(mse,1e-15)))


def full_psnr(x,z,clipped=True):
    a=np.clip(z,0,1) if clipped else z
    return float(-10*np.log10(max(float(np.mean((x-a)**2)),1e-15)))


def fit_one(y,rank,train,val,test,mask_bad,alpha,eta,sweeps,check_every,seed):
    scale = max(float(np.std(y[train])), 1e-3)
    factors=init_factors(y.shape,rank,seed=seed,scale=scale)
    h=[]
    # Choose by RAW validation squared error, not by test or original clean.
    best_score=float('inf');best_state=None;best_it=None
    use_fill = (~train)[:,:,None]
    for it in range(sweeps+1):
        if it % check_every==0 or it==sweeps:
            L=tritd(*factors)
            ms_train=float(np.mean((L[train]-y[train])**2))
            ms_val=float(np.mean((L[val]-y[val])**2))
            h.append(dict(iteration=it, train_mse=ms_train, val_mse=ms_val,
                          psnr_train=-10*np.log10(max(ms_train,1e-15)),
                          psnr_val=-10*np.log10(max(ms_val,1e-15))))
            if ms_val < best_score:
                best_score=ms_val;best_state=L.copy();best_it=it
        if it==sweeps:
            break
        previous=tritd(*factors)
        target=np.where(use_fill,previous,y)
        factors=mals_sweep(target,factors,alpha=alpha,eta=eta)
    return dict(best_L=best_state,best_it=best_it,best_val_mse=best_score,
                final_L=tritd(*factors),history=h,seed=seed)


def figure(out, tag, case, clean, obs, bad, fit):
    early=fit['best_L']; last=fit['final_L']
    early_fill=np.where(bad[:,:,None],early,obs)
    last_fill=np.where(bad[:,:,None],last,obs)
    items=[('Original (evaluation only)',clean),('Salt/pepper observation',obs),
           ('Early-stop low-rank L',early),('300-sweep low-rank L',last),
           ('Early-stop masked fill',early_fill),('300-sweep masked fill',last_fill)]
    fig,axes=plt.subplots(2,3,figsize=(12,7.2),constrained_layout=True)
    for ax,(name,x) in zip(axes.flat,items):
        ax.imshow(np.clip(x,0,1));ax.set_title(name,fontsize=10);ax.axis('off')
    fig.suptitle(f'{case}, selected at iter {fit["best_it"]} (no clean image used to select)')
    fig.savefig(out/f'{tag}_{case}_panel.png',dpi=150);plt.close(fig)
    for name,mat in [('early_lowrank',early),('final_lowrank',last),
                     ('early_maskfill',early_fill),('final_maskfill',last_fill)]:
        Image.fromarray(np.uint8(np.round(255*np.clip(mat,0,1)))).save(out/f'{tag}_{case}_{name}.png')
    return early_fill,last_fill


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--runs',nargs='+',required=True,help='Existing S6 rank run folders with matched observations')
    p.add_argument('--out',required=True,help='New unique output directory')
    p.add_argument('--val-frac',type=float,default=.05,help='Fraction of noncorrupt pixels held for selection')
    p.add_argument('--test-frac',type=float,default=.05,help='Independent pixels withheld solely for evaluation')
    p.add_argument('--sweeps',type=int,default=300)
    p.add_argument('--check-every',type=int,default=5)
    p.add_argument('--restarts',type=int,default=2)
    p.add_argument('--alpha',type=float,default=.0001)
    p.add_argument('--eta',type=float,default=.001)
    p.add_argument('--seed',type=int,default=92026)
    a=p.parse_args()
    if min(a.val_frac,a.test_frac)<=0 or a.val_frac+a.test_frac>=.5:
        p.error('Require positive validation/test fractions totaling <0.5')
    if a.sweeps<1 or a.check_every<1 or a.restarts<1 or min(a.alpha,a.eta)<0 or a.alpha+a.eta<=0:
        p.error('Invalid sweeps, restarts or alpha/eta')
    runs=validate_inputs(a.runs)
    out=Path(a.out);tag=out.name
    if out.exists() and any(out.iterdir()):
        raise SystemExit(f'Refusing overwrite: {out}; select new --out')
    out.mkdir(parents=True,exist_ok=True)
    (out/f'{tag}_config.json').write_text(json.dumps({**vars(a),
        'important':'Val selects iteration/restart; independent test does NOT select; clean used only for final evaluation',
        'mask':'Exact black/white pixel detection on observed Y, specific to THIS synthetic salt/pepper protocol',
        'methods':'Masked TriTD ALS + validation early stop, NOT generic TriTD-Half'},indent=2),encoding='utf-8')
    rows=[];curves=[]
    for rate in runs[0]['rates']:
        rate_tag=str(rate).replace('.','p')
        ref=runs[0]
        case0=f'r{ref["rank"]}_rho{rate_tag}_pixel'
        with np.load(ref['folder']/f'{ref["tag"]}_{case0}_arrays.npz',allow_pickle=False) as z:
            ref_y=np.asarray(z['observed'],dtype=np.float64)
        bad=detect_saturated_rgb_pixels(ref_y)
        healthy=np.flatnonzero((~bad).ravel())
        rng=np.random.default_rng(a.seed+int(round(rate*10000)))
        shuffled=rng.permutation(healthy)
        nv=max(1,int(round(len(healthy)*a.val_frac)))
        nt=max(1,int(round(len(healthy)*a.test_frac)))
        if nv+nt>=len(healthy):raise ValueError('Too few observed pixels left')
        val=np.zeros(bad.size,dtype=bool);test=np.zeros(bad.size,dtype=bool)
        val[shuffled[:nv]]=True;test[shuffled[nv:nv+nt]]=True
        val=val.reshape(bad.shape);test=test.reshape(bad.shape)
        train=~(bad|val|test)
        for run in runs:
            rank=run['rank'];case=f'r{rank}_rho{rate_tag}_pixel'
            f=run['folder']/f'{run["tag"]}_{case}_arrays.npz'
            with np.load(f,allow_pickle=False) as z:
                clean=np.asarray(z['clean'],dtype=np.float64)
                y=np.asarray(z['observed'],dtype=np.float64)
                sparse=np.asarray(z['sparse_true'],dtype=np.float64)
            if y.shape!=ref_y.shape or not np.allclose(y,ref_y,rtol=0,atol=1e-12):
                raise ValueError('S6 observations differ between ranks; need matched cases')
            if not np.array_equal(bad,detect_saturated_rgb_pixels(y)):
                raise ValueError('Inconsistent masks')
            candidates=[]
            for restart in range(a.restarts):
                seed=a.seed*10+31+restart
                fit=fit_one(y,rank,train,val,test,bad,a.alpha,a.eta,a.sweeps,a.check_every,seed)
                candidates.append(fit)
                for q in fit['history']:
                    curves.append(dict(rank=rank,rate=rate,restart=restart,**q))
            # Validation selects BOTH restart and iteration. Test not touched in selection.
            winner=min(candidates,key=lambda z:z['best_val_mse'])
            early=winner['best_L'];last=winner['final_L']
            early_fill,last_fill=figure(out,tag,case,clean,y,bad,winner)
            for meth,lowrank,filled in [('val_early',early,early_fill),('final_same_restart',last,last_fill)]:
                row=dict(rank=rank,rate=rate,method=meth,selected_restart=winner['seed']-(a.seed*10+31),
                    selected_iteration=winner['best_it'] if meth=='val_early' else a.sweeps,
                    train_psnr_raw=psnr_mask(y,lowrank,train),
                    validation_psnr_raw=psnr_mask(y,lowrank,val),
                    test_psnr_raw=psnr_mask(y,lowrank,test),
                    corrupted_location_psnr_raw=psnr_mask(clean,lowrank,bad),
                    corrupted_location_psnr_clipped=psnr_mask(clean,lowrank,bad,clipped=True),
                    full_lowrank_psnr_clipped=full_psnr(clean,lowrank),
                    restored_maskfill_psnr_clipped=full_psnr(clean,filled),
                    train_pixels=int(train.sum()),val_pixels=int(val.sum()),test_pixels=int(test.sum()),
                    corrupted_pixels=int(bad.sum()),
                    detected_support_matches_truth=int(np.array_equal(bad,np.any(np.abs(sparse)>1e-10,axis=2))),
                    factor_parameter_count=rank*rank*sum(y.shape))
                rows.append(row)
                print(f'{case} {meth:18s}: it={row["selected_iteration"]:3d} '
                    f'train={row["train_psnr_raw"]:5.2f} val={row["validation_psnr_raw"]:5.2f} '
                    f'test={row["test_psnr_raw"]:5.2f} '
                    f'corrupt={row["corrupted_location_psnr_raw"]:5.2f} '
                    f'maskfill={row["restored_maskfill_psnr_clipped"]:5.2f}',flush=True)
            save_csv(out/f'{tag}_metrics.csv',rows)
            save_csv(out/f'{tag}_history.csv',curves)
    for rate in runs[0]['rates']:
        fig,ax=plt.subplots(figsize=(8,5),constrained_layout=True)
        for run in runs:
            sub=[x for x in curves if x['rank']==run['rank'] and x['rate']==rate]
            # Average across starting points; curves only diagnostic; actual selected model via min val.
            steps=sorted({x['iteration'] for x in sub})
            means=[np.mean([x['psnr_val'] for x in sub if x['iteration']==it]) for it in steps]
            ax.plot(steps,means,label=f'r={run["rank"]}')
        ax.set(xlabel='Masked ALS sweeps',ylabel='Mean validation PSNR (raw, dB)',
               title=f'S9: validation pixel prediction, {rate:.0%} salt/pepper')
        ax.grid(alpha=.2);ax.legend()
        fig.savefig(out/f'{tag}_rho{str(rate).replace(".","p")}_validation_curves.png',dpi=170)
        plt.close(fig)
    print('Saved to',out)
    print('Validation selected the winner; independent TEST pixel error should guide conclusions.')
    print('No reference to clean image was used in fitting, selecting iteration or selecting restart.')

if __name__=='__main__':main()
