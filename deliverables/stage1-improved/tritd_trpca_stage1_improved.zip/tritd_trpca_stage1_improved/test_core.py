import numpy as np
from scipy.optimize import minimize_scalar
from tri_core import (
    tritd, half_prox, init_factors, mals_sweep,
    objective, fit_trpca, generate_case, scores
)

def test_tritd_explicit():
    A,B,C=init_factors((4,5,6),2,seed=6)
    direct=np.zeros((4,5,6))
    for i in range(4):
        for j in range(5):
            for k in range(6):
                direct[i,j,k]=sum(A[i,p,q]*B[s,j,q]*C[s,p,k]
                    for p in range(2) for q in range(2) for s in range(2))
    assert np.allclose(direct,tritd(A,B,C),atol=1e-12)

def test_each_mals_sweep_descends_quadratic():
    L,S,Y=generate_case((8,9,6),2,0.05,3.,2026)
    factors=init_factors(Y.shape,2,seed=23)
    before=objective(L,factors,np.zeros_like(L),0.,1e-4)
    after_factors=mals_sweep(L,factors,alpha=1e-4,eta=1e-3)
    after=objective(L,after_factors,np.zeros_like(L),0.,1e-4)
    assert after <= before + 1e-9

def test_half_prox_scalar_global():
    for gamma in [0.001, 0.1, 1.0]:
        for v in [-3,-1,-0.5,-0.1,0,0.1,0.5,1,3]:
            p=float(half_prox(np.array(v),gamma))
            fun=lambda x:0.5*(x-v)**2+gamma*np.sqrt(abs(x))
            alt=minimize_scalar(fun,bounds=(0,max(10,2*abs(v)+3)),method='bounded')
            altneg=minimize_scalar(fun,bounds=(-max(10,2*abs(v)+3),0),method='bounded')
            assert fun(p) <= min(fun(0),fun(alt.x),fun(altneg.x)) + 1e-5

def test_exact_generated_rank_and_support():
    L,S,Y=generate_case((9,8,7),2,rate=0.1,seed=17)
    assert np.allclose(L+S,Y)
    assert np.count_nonzero(S)==int(round(0.1*L.size))
    assert np.isfinite(L).all()

def test_robust_objective_nonincreasing():
    L,S,Y=generate_case((12,12,10),2,rate=0.05,seed=2026)
    fit=fit_trpca(Y,2,lam=.1,max_iter=70,seed=4)
    diff=np.diff(fit['history'][:,1])
    assert np.max(diff)<=1e-8, np.max(diff)
    assert np.isfinite(fit['L']).all()
    met=scores(L,S,fit['L'],fit['S'])
    assert 0<=met['f1']<=1

if __name__=='__main__':
    for n,v in list(globals().items()):
        if n.startswith('test_') and callable(v):
            v(); print(n,'PASS')
