#!/usr/bin/env python3
"""Correct overly restrictive triple-rank checks in the TriTD-TRPCA project.

Run in project root: python fix_triple_rank_checks_v1.py
Creates versioned backup copies. Does not modify tensor contractions or optimizers.
"""
from __future__ import annotations
from pathlib import Path
import ast
import datetime
import shutil

REPLACEMENTS = {
    'tri_core.py': [
        ('min(Y.shape) < rank', 'rank > sorted(Y.shape)[1]'),
        ('rank > min(Y.shape)', 'rank > sorted(Y.shape)[1]'),
        ('rank>min(Y.shape)', 'rank>sorted(Y.shape)[1]'),
        ('rank <= minimum dimension', 'rank <= middle dimension'),
    ],
    'run_stage1.py': [
        ('max(ranks)>min(dims)', 'max(ranks)>sorted(dims)[1]'),
        ('max(ranks) > min(dims)', 'max(ranks) > sorted(dims)[1]'),
        ('rank <= min(dims)', 'rank <= middle(dims)'),
    ],
    's4_cont_v1.py': [
        ('args.rank <= min(dims)', 'args.rank <= sorted(dims)[1]'),
        ('rank <= min(dims)', 'rank <= middle(dims)'),
    ],
    's5_path_ablation_v1.py': [
        ('args.rank>min(dims)', 'args.rank>sorted(dims)[1]'),
        ('args.rank > min(dims)', 'args.rank > sorted(dims)[1]'),
        ('rank in 1..min(dims)', 'rank in 1..middle(dims)'),
    ],
}


def main():
    base = Path.cwd()
    prepared = {}
    for name, rules in REPLACEMENTS.items():
        path = base / name
        if not path.is_file():
            print(f'SKIP (file not present): {name}')
            continue
        old = path.read_text(encoding='utf-8')
        new = old
        applied = []
        for before, after in rules:
            if before in new:
                new = new.replace(before, after)
                applied.append(before)
        if new == old:
            if 'sorted(Y.shape)[1]' in old or 'sorted(dims)[1]' in old:
                print(f'ALREADY PATCHED: {name}')
            else:
                print(f'REVIEW MANUALLY: {name} (no expected expression found)')
            continue
        try:
            ast.parse(new, filename=name)
        except SyntaxError as exc:
            raise RuntimeError(f'Refusing update: changed {name} is invalid Python: {exc}') from exc
        prepared[path] = (old, new, applied)
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    for path, (old, new, applied) in prepared.items():
        backup = path.with_name(path.name + f'.bak_{stamp}')
        ix = 1
        while backup.exists():
            backup = path.with_name(path.name + f'.bak_{stamp}_{ix}')
            ix += 1
        shutil.copy2(path, backup)
        path.write_text(new, encoding='utf-8')
        print(f'PATCHED: {path.name} | rules={len(applied)} | backup={backup.name}')
    print(f'Done. Modified {len(prepared)} file(s); s6_color_visual_v1.py does not need changes.')


if __name__ == '__main__':
    main()
