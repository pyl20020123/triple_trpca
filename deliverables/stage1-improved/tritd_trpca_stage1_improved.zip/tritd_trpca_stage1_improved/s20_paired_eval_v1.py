#!/usr/bin/env python3
"""Pairwise S19-type anchor results versus no-TriTD baseline, image-by-image.

Evaluation-only script. Never uses ground-truth PSNR to select model parameters.
Does not run optimization. Works on the exact S19 per_patch.csv schema.
"""
import argparse
from pathlib import Path
import pandas as pd
import numpy as np


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--per-patch', required=True)
    p.add_argument('--out', required=True, help='new output CSV, refuse overwrite')
    a=p.parse_args()
    dest=Path(a.out)
    if dest.exists():p.error('Refusing to overwrite '+str(dest))
    d=pd.read_csv(a.per_patch)
    required={'image','anchor','mask_method','method','rank','guide_beta','psnr','mse'}
    if not required.issubset(set(d.columns)):p.error('Incorrect columns: '+str(required-set(d.columns)))
    keys=['image','anchor','mask_method']
    baseline=d[d.method=='no_tritd_group_half'][keys+['psnr','mse']].copy()
    if baseline.duplicated(keys).any():p.error('Duplicate baselines')
    baseline=baseline.rename(columns={'psnr':'base_psnr','mse':'base_mse'})
    cand=d[d.method.str.startswith('tritd_half_')].merge(baseline,on=keys,how='left',validate='many_to_one')
    if cand.base_psnr.isna().any():p.error('Missing baseline for candidate rows')
    cand['gain_db']=cand.psnr-cand.base_psnr
    cand['win']=(cand.gain_db>1e-8).astype(int)
    out=[]
    for label, frame in [('per_image',cand),('all_images',cand.assign(image='ALL'))]:
        for g, grp in frame.groupby(['image','mask_method','method','rank','guide_beta']):
            total=len(grp)
            out.append(dict(scope=label,image=g[0],mask_method=g[1],method=g[2],
                rank=int(g[3]),guide_beta=float(g[4]),n=total,
                mean_candidate_db=float(grp.psnr.mean()),mean_baseline_db=float(grp.base_psnr.mean()),
                mean_gain_db=float(grp.gain_db.mean()),median_gain_db=float(grp.gain_db.median()),
                min_gain_db=float(grp.gain_db.min()),max_gain_db=float(grp.gain_db.max()),
                wins=int(grp.win.sum()),
                pooled_candidate_db=float(-10*np.log10(max(grp.mse.mean(),1e-15))),
                pooled_baseline_db=float(-10*np.log10(max(grp.base_mse.mean(),1e-15)))))
    res=pd.DataFrame(out).sort_values(['scope','mask_method','method','rank','guide_beta','image'])
    dest.parent.mkdir(parents=True,exist_ok=True)
    res.to_csv(dest,index=False)
    shortlist=res[(res.scope=='all_images')&(res.method.isin(['tritd_half_support_fill','tritd_half_y_minus_s']))]
    shortlist=shortlist.sort_values('mean_gain_db',ascending=False)
    print('\nAll-image paired comparison (do NOT pick settings using these held-out results):')
    print(shortlist[['mask_method','method','rank','guide_beta','n','mean_gain_db','median_gain_db','wins','pooled_candidate_db','pooled_baseline_db']].round(3).to_string(index=False))
    print('\nSaved:',dest)


if __name__=='__main__':main()
