"""Triple tensor decomposition and exact scalar half-prox for a research baseline.

Factor convention:
  A[i,p,q], B[s,j,q], C[s,p,k]
  L[i,j,k] = sum_{p,q,s} A[i,p,q] B[s,j,q] C[s,p,k].
"""
import numpy as np


def tritd(A, B, C):
    return np.einsum('ipq,sjq,spk->ijk', A, B, C, optimize=True)


def half_prox(v, gamma):
    """Globally minimizing scalar prox of gamma*sqrt(abs(x)) + (x-v)^2/2.

    At the equality threshold, select zero (minimum-norm minimizer).
    """
    if gamma < 0:
        raise ValueError('gamma must be nonnegative')
    v = np.asarray(v, dtype=np.float64)
    if gamma == 0:
        return v.copy()
    a = np.abs(v)
    threshold = 1.5 * gamma ** (2.0 / 3.0)
    out = np.zeros_like(a)
    mask = a > threshold
    av = a[mask]
    if av.size:
        cosine_arg = -3.0 * np.sqrt(3.0) * gamma / (4.0 * av ** 1.5)
        theta = np.arccos(np.clip(cosine_arg, -1.0, 1.0)) / 3.0
        out[mask] = 4.0 * av / 3.0 * np.cos(theta) ** 2
    return np.sign(v) * out


def init_factors(shape, rank, seed=0, scale=1.0):
    rng = np.random.default_rng(seed)
    # Set typical std(L) ~ scale for independent Gaussian factors.
    st = scale ** (1.0 / 3.0) / np.sqrt(rank)
    n1, n2, n3 = shape
    return (
        rng.normal(0, st, (n1, rank, rank)),
        rng.normal(0, st, (rank, n2, rank)),
        rng.normal(0, st, (rank, rank, n3)),
    )


def _ridge_solve(x, design, prev, alpha, eta):
    """min 1/2 ||x - U@design||_F^2 + alpha/2||U||² + eta/2||U-prev||²."""
    m = design @ design.T
    m.flat[::m.shape[0]+1] += alpha + eta
    rhs = x @ design.T + eta * prev
    return np.linalg.solve(m, rhs.T).T


def mals_sweep(target, factors, alpha=1e-4, eta=1e-3):
    A, B, C = factors
    n1, n2, n3 = target.shape
    r = A.shape[1]
    F = np.einsum('sjq,spk->pqjk', B, C, optimize=True).reshape(r*r, n2*n3)
    A = _ridge_solve(target.reshape(n1, -1), F, A.reshape(n1, -1), alpha, eta).reshape(A.shape)
    G = np.einsum('ipq,spk->sqik', A, C, optimize=True).reshape(r*r, n1*n3)
    B2 = _ridge_solve(target.transpose(1,0,2).reshape(n2,-1), G,
                      B.transpose(1,0,2).reshape(n2,-1), alpha, eta)
    B = B2.reshape(n2, r, r).transpose(1,0,2)
    Q = np.einsum('ipq,sjq->spij', A, B, optimize=True).reshape(r*r, n1*n2)
    C3 = _ridge_solve(target.transpose(2,0,1).reshape(n3,-1), Q,
                      C.transpose(2,0,1).reshape(n3,-1), alpha, eta)
    C = C3.reshape(n3,r,r).transpose(1,2,0)
    return A, B, C


def objective(Y, factors, S, lam, alpha):
    A, B, C = factors
    residual = Y - tritd(A, B, C) - S
    return (0.5 * float(np.sum(residual ** 2))
            + lam * float(np.sqrt(np.abs(S)).sum())
            + 0.5 * alpha * sum(float(np.sum(x*x)) for x in factors))


def fit_trpca(Y, rank, lam=0.04, alpha=1e-4, eta=1e-3, max_iter=250,
              seed=0, initial_S=None, tol=1e-7, patience=10, verbose=False,
              freeze_sparse=False):
    Y = np.asarray(Y, dtype=np.float64)
    if Y.ndim != 3:
        raise ValueError("Input must be a third-order tensor")
    if rank < 1 or rank > sorted(Y.shape)[1]:
        raise ValueError("rank must be between 1 and the middle dimension")
    if min(lam, alpha, eta) < 0 or alpha + eta <= 0:
        raise ValueError('lam, alpha, eta must be nonnegative; alpha+eta > 0')
    scale = max(float(np.std(Y)), 1e-3)
    factors = init_factors(Y.shape, rank, seed=seed, scale=scale)
    S = np.zeros_like(Y) if initial_S is None else np.array(initial_S, copy=True)
    hist = []
    best = float('inf')
    stable = 0
    converged = False
    for it in range(max_iter+1):
        obj = objective(Y, factors, S, lam, alpha)
        hist.append((it, obj))
        if it >= max_iter:
            break
        if it > 0:
            prev = hist[-2][1]
            rel = max(prev-obj, 0.0) / max(abs(prev), 1e-12)
            stable = stable+1 if rel < tol else 0
            if stable >= patience:
                converged = True
                break
        factors = mals_sweep(Y-S, factors, alpha=alpha, eta=eta)
        L = tritd(*factors)
        if not freeze_sparse:
            S = half_prox(Y-L, lam)
        if verbose and (it+1) % 50 == 0:
            print(f'iter={it+1:4d} objective={objective(Y,factors,S,lam,alpha):.7g}', flush=True)
    L = tritd(*factors)
    return {'L':L, 'S':S, 'factors':factors, 'history':np.array(hist),
            'iterations':len(hist)-1, 'converged':converged,
            'final_objective':hist[-1][1]}


def generate_case(shape=(20,20,16), rank=2, rate=0.05, amplitude=3., seed=0):
    """Make an EXACT triple-rank-upper-bounded clean tensor and sparse impulses.

    Data generation factor randomness is separate from optimizer initialization.
    """
    if not 0 <= rate <= 1 or amplitude < 0:
        raise ValueError('Invalid corruption parameters')
    A,B,C = init_factors(shape, rank, seed=seed+900001, scale=1.0)
    L = tritd(A,B,C)
    L = L / max(np.std(L),1e-10)
    rng = np.random.default_rng(seed + 400003)
    S = np.zeros(shape, dtype=np.float64)
    n = int(round(rate*L.size))
    mask = np.zeros(L.size,dtype=bool)
    mask[rng.choice(L.size,size=n,replace=False)]=True
    magnitudes = rng.uniform(0.75*amplitude, 1.25*amplitude, size=n)
    signs = rng.choice([-1.0,1.0],size=n)
    S.reshape(-1)[mask] = magnitudes*signs
    return L, S, L+S


def scores(Lstar,Sstar,Lhat,Shat, support_threshold=0.05):
    norm = max(np.linalg.norm(Lstar), 1e-12)
    rel = float(np.linalg.norm(Lstar-Lhat)/norm)
    # Fixed threshold in normalized units: independent of ground-truth corruption.
    observed_support = np.abs(Sstar) > 0
    predicted_support = np.abs(Shat) > support_threshold
    tp=int(np.sum(observed_support & predicted_support))
    fp=int(np.sum(~observed_support & predicted_support))
    fn=int(np.sum(observed_support & ~predicted_support))
    prec=tp/(tp+fp) if tp+fp else 1.0 if not observed_support.any() else 0.0
    rec=tp/(tp+fn) if tp+fn else 1.0
    f1=2*prec*rec/(prec+rec) if prec+rec else 0.0
    return dict(rre_l=rel, precision=prec,recall=rec,f1=f1,
                rre_s=float(np.linalg.norm(Sstar-Shat)/max(np.linalg.norm(Sstar),1e-12)),
                residual_rre=float(np.linalg.norm((Lstar+Sstar)-(Lhat+Shat))/max(np.linalg.norm(Lstar+Sstar),1e-12)),
                support_threshold=support_threshold)
