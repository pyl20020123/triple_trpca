# S18 — Nonlocal TriTD–RGB GroupHalf pilot

This script checks whether *actual joint alternating optimization* of a triple decomposition and an RGB group-l1/2 sparse component gives better 8×8 anchor-patch recovery than the local median and a **no-triple-decomposition GroupHalf** control.

## Model
For each group tensor `G` of shape `(p*p, 3, K)`:

`min_{A,B,C,S} 0.5 ||G - TriTD(A,B,C) - S||_F^2 + lambda sum_{u,k} sqrt(||S[u,:,k]||_2) + 0.5 alpha sum ||factor||_F^2`.

A stage first runs the existing `mals_sweep(G-S,...)`, then performs the **exact** RGB group-half proximal update. For RGB residual vector `v` with norm `q`, the nonzero proximal output norm `t` solves `t + lambda/(2 sqrt(t)) = q` if `q > 1.5*lambda**(2/3)`, else the group is zero. The script uses bisection and checks model objective at fixed intervals, choosing the lowest objective without using ground-truth clean or support data.

Blind masks from S17 are used only to form a robust group/initialize MALS; subsequently `S` is updated from the actual model residual. Both `consensus` and `adaptive` methods are predeclared, NOT selected on test PSNR. Group members are matched using the observation-derived guide.

**Outputs are pilot results on 8×8 anchor patches, NOT full 128×128 image PSNR.** Clean images, oracle support, and true PSNR are evaluation-only. `oracle_local_eval` is clearly labeled as a diagnostic and must not be compared as a blind recovery method.

## Placement
Copy script beside `tri_core.py`, `s16_nonlocal_patch_probe_v1.py`, `s17_support_audit_v1.py`, `s12_blind_impulse_v1.py`. Existing S16 configuration and per-patch result files are required. Use the same environment/packages that worked for S16/S17.

## Syntax check
```
cd ~/tritd_trpca_stage1
python -m py_compile s18_nonlocal_group_half_v1.py
```

## Smoke test, 2 anchors per image
```
python -u s18_nonlocal_group_half_v1.py \
  --s16-config outputs/s16_nonlocal_dev_random_v1/s16_nonlocal_dev_random_v1_config.json \
  --s16-per-patch outputs/s16_nonlocal_dev_random_v1/s16_nonlocal_dev_random_v1_per_patch.csv \
  --ranks 2,3 --mask-modes consensus,adaptive \
  --max-anchors 2 --steps 10 --warmup 5 --lam 0.05 \
  --out outputs/s18_joint_smoke_v1
```

## Development experiment, matching all 18 S16 anchors
```
python -u s18_nonlocal_group_half_v1.py \
  --s16-config outputs/s16_nonlocal_dev_random_v1/s16_nonlocal_dev_random_v1_config.json \
  --s16-per-patch outputs/s16_nonlocal_dev_random_v1/s16_nonlocal_dev_random_v1_per_patch.csv \
  --ranks 2,3 --mask-modes consensus,adaptive \
  --max-anchors 9 --steps 60 --warmup 12 --lam 0.05 \
  --out outputs/s18_nonlocal_group_half_dev_v1
```

## Files
Inside the unique destination folder, outputs are named with the directory basename:
- `*_config.json`: all inputs, settings, notes.
- `*_summary.csv`: per-image and model aggregated mean PSNR, pooled PSNR, MSE, F1, timing.
- `*_per_patch.csv`: each anchor, method and output flavor.
- `*_history.csv`: objective and sparse support at fixed checkpoints.
- `*_0722_a00_panel.png`, etc.: comparisons of recovery images.

## Interpretation
- Compare `tritd_half_support_fill` against `no_tritd_group_half` under the **same mask method**, and against `local_median`.
- Compare recovery outputs `tritd_half_lowrank_L`, `tritd_half_y_minus_s`, `tritd_half_support_fill` without choosing based on the unseen clean reference during inference.
- GroupHalf support F1 is an evaluation metric and does NOT enter any optimization decisions.
- If joint TriTD fails against the no-TriTD control, it still has no demonstrated added value on these patches. If effective, next implement overlap-aggregated full-image recovery and split into development/test images.
