#!/usr/bin/env python3
"""Evaluate existing S6 TriTD-Half RGB script on prepared DIV2K patches.

Traditional TriTD-Half is solved PER IMAGE (no training). This driver does not
train a network; for learning a deep-unfolding network implement a trainer.
"""
import argparse
import csv
import json
import subprocess
import sys
from collections import defaultdict
from pathlib import Path
from statistics import mean,stdev


def rows_csv(path,records):
    if not records:
        return
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest',required=True)
    p.add_argument('--split',choices=['train','dev','test'],default='test')
    p.add_argument('--rank',type=int,default=3)
    p.add_argument('--rates',default='0.05,0.10')
    p.add_argument('--noise-mode',choices=['pixel','entry'],default='pixel')
    p.add_argument('--restarts',type=int,default=2)
    p.add_argument('--max-patches',type=int,default=6,help='0 for all available (expensive)')
    p.add_argument('--seed',type=int,default=2026)
    p.add_argument('--out',default='outputs/s10_div2k_test_r3_v1')
    a=p.parse_args()
    out=Path(a.out)
    if out.exists() and any(out.iterdir()):
        raise SystemExit(f'Refusing to overwrite {out}; change --out name')
    out.mkdir(parents=True,exist_ok=True)
    with Path(a.manifest).open(encoding='utf-8-sig',newline='') as f:
        selected=[r for r in csv.DictReader(f) if r['split']==a.split]
    if a.max_patches>0:
        selected=selected[:a.max_patches]
    if not selected:
        raise ValueError(f'No patches for split={a.split} in {a.manifest}')
    records=[]
    for idx,rec in enumerate(selected):
        patch=Path(rec['patch_path'])
        if not patch.is_file():
            raise FileNotFoundError(f'Missing patch {patch}; run s10_div2k_prepare_v1.py from original working directory')
        ident=int(rec['image_id'])
        patch_index=int(rec['crop_idx'])
        case=f'{a.split}_{ident:04d}_p{patch_index:02d}_r{a.rank}'
        case_out=out/case
        # Same base seed for matching noise placements across different ranks,
        # while different source images have different noise patterns.
        noise_seed=a.seed+ident*10007+patch_index*307
        command=[sys.executable,'s6_color_visual_v1.py',
                 '--input',str(patch),'--patch',rec['patch_size'],
                 '--center-x','0.5','--center-y','0.5',
                 '--rank',str(a.rank),'--rates',a.rates,
                 '--noise-mode',a.noise_mode,'--seed',str(noise_seed),
                 '--restarts',str(a.restarts),'--out',str(case_out)]
        print(f'[{idx+1}/{len(selected)}] {case}: running S6 RGB restoration',flush=True)
        subprocess.run(command,check=True)
        metrics=case_out/f'{case}_metrics.csv'
        with metrics.open(encoding='utf-8-sig',newline='') as f:
            for met in csv.DictReader(f):
                records.append(dict(split=a.split,image_id=rec['image_id'],
                                    crop_idx=patch_index,source_path=rec['source_path'],
                                    patch_path=str(patch),method=met['method'],rate=met['rate'],
                                    rank=a.rank,psnr_display=met['psnr_display'],
                                    psnr_raw=met['psnr_raw'],ssim_display=met['ssim_display'],
                                    f1=met['f1'],precision=met['precision'],recall=met['recall'],
                                    output_dir=str(case_out)))
        rows_csv(out/f'{out.name}_per_patch.csv',records)
    # Reduce across patches of a source image BEFORE averaging across images.
    by_image=defaultdict(list)
    for v in records:
        by_image[(v['image_id'],v['method'],v['rate'])].append(v)
    image_rows=[]
    for (image_id,method,rate),vals in sorted(by_image.items()):
        f1s=[float(q['f1']) for q in vals if q['f1']!='']
        image_rows.append(dict(image_id=image_id,method=method,rate=rate,rank=a.rank,
                               patches=len(vals),psnr_display=mean(float(q['psnr_display']) for q in vals),
                               psnr_raw=mean(float(q['psnr_raw']) for q in vals),
                               ssim_display=mean(float(q['ssim_display']) for q in vals),
                               f1=mean(f1s) if f1s else ''))
    rows_csv(out/f'{out.name}_per_image.csv',image_rows)
    grouped=defaultdict(list)
    for v in image_rows:
        grouped[(v['method'],v['rate'])].append(v)
    summary=[]
    for (method,rate),vals in sorted(grouped.items()):
        psnr=[v['psnr_display'] for v in vals]
        ssim=[v['ssim_display'] for v in vals]
        f1=[v['f1'] for v in vals if v['f1']!='']
        summary.append(dict(method=method,rate=rate,rank=a.rank,n_images=len(vals),
                            mean_psnr=mean(psnr),std_psnr=stdev(psnr) if len(psnr)>1 else 0.,
                            mean_ssim=mean(ssim),mean_f1=mean(f1) if f1 else ''))
    rows_csv(out/f'{out.name}_summary.csv',summary)
    (out/f'{out.name}_config.json').write_text(json.dumps(vars(a),indent=2),encoding='utf-8')
    print('Done. Summary:',out/f'{out.name}_summary.csv',flush=True)

if __name__=='__main__':main()
