#!/usr/bin/env python3
"""Create image-disjoint DIV2K RGB patches for TriTD-Half experiments.

Original DIV2K train HR 0001..0800 split by image ID into train (0001..0720)
and development (0721..0800). Original DIV2K validation HR 0801..0900
is held out as local final test. Official 0901..1000 test GT is not used.
Only clean image patches are saved; add artificial sparse corruption downstream.
"""
import argparse
import csv
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps


def files_in(folder, lower, upper):
    if not folder.is_dir():
        raise FileNotFoundError(f'Missing DIV2K HR folder: {folder}')
    found=[]
    for p in sorted(folder.iterdir()):
        if p.suffix.lower() != '.png' or not p.stem.isdigit():
            continue
        ident = int(p.stem)
        if lower <= ident <= upper:
            found.append((ident, p))
    return found


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--train-dir',default='data/DIV2K/DIV2K_train_HR')
    p.add_argument('--valid-dir',default='data/DIV2K/DIV2K_valid_HR')
    p.add_argument('--patch',type=int,default=48)
    p.add_argument('--train-images',type=int,default=0,help='0=all 0001..0720')
    p.add_argument('--dev-images',type=int,default=0,help='0=all 0721..0800')
    p.add_argument('--test-images',type=int,default=0,help='0=all 0801..0900')
    p.add_argument('--train-crops',type=int,default=4)
    p.add_argument('--eval-crops',type=int,default=1)
    p.add_argument('--seed',type=int,default=2026)
    p.add_argument('--out',default='data/div2k_patches_v1')
    a=p.parse_args()
    if min(a.patch,a.train_crops,a.eval_crops) < 1:
        p.error('patch and crop counts must be positive')
    out=Path(a.out)
    if out.exists() and any(out.iterdir()):
        raise SystemExit(f'Refusing to overwrite nonempty output directory {out}; choose a new --out')
    out.mkdir(parents=True,exist_ok=True)
    jobs=[('train',Path(a.train_dir),1,720,a.train_images,a.train_crops),
          ('dev',Path(a.train_dir),721,800,a.dev_images,a.eval_crops),
          ('test',Path(a.valid_dir),801,900,a.test_images,a.eval_crops)]
    rows=[]
    for split,base,lo,hi,limit,ncrop in jobs:
        imgs=files_in(base,lo,hi)
        if limit>0:
            imgs=imgs[:limit]
        dest=out/split
        dest.mkdir(parents=True,exist_ok=True)
        for ident,f in imgs:
            with Image.open(f) as img:
                # Preserve pixel values: no downscaling/resizing; HxWx3 clean HR patches only.
                rgb=np.asarray(ImageOps.exif_transpose(img).convert('RGB'),dtype=np.uint8)
            height,width=rgb.shape[:2]
            if min(height,width)<a.patch:
                print('SKIP (too small)',f)
                continue
            for crop_idx in range(ncrop):
                # Stable independent image-level deterministic crop positions.
                rng=np.random.default_rng(a.seed+ident*10007+crop_idx*307)
                y=int(rng.integers(0,height-a.patch+1))
                x=int(rng.integers(0,width-a.patch+1))
                name=f'{split}_{ident:04d}_p{crop_idx:02d}_s{a.patch}.png'
                Image.fromarray(rgb[y:y+a.patch,x:x+a.patch]).save(dest/name)
                rows.append(dict(split=split,image_id=f'{ident:04d}',crop_idx=crop_idx,
                                 source_path=str(f),patch_path=str(dest/name),
                                 row=y,col=x,patch_size=a.patch,image_h=height,image_w=width))
        print(f'{split}: source images {len(imgs)}, patches {sum(z["split"]==split for z in rows)}')
    manifest=out/f'{out.name}_manifest.csv'
    with manifest.open('w',newline='',encoding='utf-8-sig') as fd:
        writer=csv.DictWriter(fd,fieldnames=list(rows[0]) if rows else ['split','image_id','crop_idx','source_path','patch_path','row','col','patch_size','image_h','image_w'])
        writer.writeheader();writer.writerows(rows)
    conf=vars(a)
    (out/f'{out.name}_config.json').write_text(json.dumps(conf,indent=2),encoding='utf-8')
    print('Manifest:',manifest,'total patches:',len(rows))
    print('IMPORTANT: splits are disjoint by source image; do not put patches from a test image in training.')

if __name__=='__main__':main()
