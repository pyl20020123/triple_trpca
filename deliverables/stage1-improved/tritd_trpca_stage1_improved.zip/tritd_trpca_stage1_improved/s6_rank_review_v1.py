#!/usr/bin/env python3
"""Summarize S6 RGB rank runs and make matched visual comparisons.

Usage (from tritd_trpca_stage1):
  python s6_rank_review_v1.py \
    --runs outputs/s6_rank3_v4 outputs/s6_rank6_v4 outputs/s6_rank8_v4 \
    --out outputs/s6_rank_review_v1

Does not train or modify prior results. Output folder must be empty or nonexistent.
"""
from __future__ import annotations
import argparse, csv, json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

METHODS = ('noisy','clean_oracle','direct_tritd','tritd_half')

def read_rows(path):
    with path.open('r',encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))

def asfloat(x):
    return float(x) if x not in ('',None) else float('nan')

def unique(r):
    return (round(float(r['rate']),9), r['method'])

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--runs',nargs='+',required=True,help='S6 output folders to compare, ideally ranks 3,6,8')
    p.add_argument('--out',default='outputs/s6_rank_review_v1')
    args=p.parse_args()
    out=Path(args.out)
    if out.exists() and any(out.iterdir()):
        raise SystemExit(f'Refusing overwrite of {out}. Choose an unused --out folder.')
    runs=[]
    for path in map(Path,args.runs):
        tag=path.name
        config_path=path/f'{tag}_config.json'
        metrics_path=path/f'{tag}_metrics.csv'
        if not config_path.exists() or not metrics_path.exists():
            raise SystemExit(f'Missing S6 config or metrics: {path}')
        conf=json.loads(config_path.read_text(encoding='utf-8'))
        data=read_rows(metrics_path)
        keyed={unique(r):r for r in data}
        if len(keyed)!=len(data):
            raise SystemExit(f'Duplicate rate/method entries in {metrics_path}')
        if set(r['method'] for r in data)!=set(METHODS):
            raise SystemExit(f'Not all 4 expected methods in {metrics_path}')
        runs.append(dict(path=path,tag=tag,conf=conf,rows=keyed,rank=int(conf['rank'])))
    runs.sort(key=lambda d:d['rank'])
    ranks=[x['rank'] for x in runs]
    if len(set(ranks))!=len(ranks):
        raise SystemExit(f'Duplicate ranks: {ranks}')
    anchor=runs[0]['conf']
    must_match=('source','original_size_hw','crop_top_left','crop_size','rates','noise_mode','seed')
    for run in runs[1:]:
        bad=[k for k in must_match if run['conf'].get(k)!=anchor.get(k)]
        if bad:
            raise SystemExit(f'Mismatched experiment inputs {run["path"]}: {bad}. Do not compare different crops/noise in a rank experiment.')
    rates=sorted(set(k[0] for k in runs[0]['rows']))
    for run in runs[1:]:
        if sorted(set(k[0] for k in run['rows'])) != rates:
            raise SystemExit(f'Mismatched rates in {run["path"]}')
    out.mkdir(parents=True,exist_ok=True)
    summary=[]
    for run in runs:
        for rho in rates:
            rows={method:run['rows'][(rho,method)] for method in METHODS}
            psnr={method:asfloat(r['psnr_display']) for method,r in rows.items()}
            ssim={method:asfloat(r['ssim_display']) for method,r in rows.items()}
            half=rows['tritd_half']
            summary.append(dict(
                rank=run['rank'],rate=rho,case=half['case'],
                psnr_noisy=psnr['noisy'],psnr_clean_fit=psnr['clean_oracle'],
                psnr_direct=psnr['direct_tritd'],psnr_tritd_half=psnr['tritd_half'],
                gain_over_noisy=psnr['tritd_half']-psnr['noisy'],
                gain_over_direct=psnr['tritd_half']-psnr['direct_tritd'],
                psnr_gap_to_clean_fit=psnr['clean_oracle']-psnr['tritd_half'],
                ssim_noisy=ssim['noisy'],ssim_clean_fit=ssim['clean_oracle'],
                ssim_direct=ssim['direct_tritd'],ssim_tritd_half=ssim['tritd_half'],
                f1=asfloat(half['f1']),precision=asfloat(half['precision']),
                recall=asfloat(half['recall']),selected_restart=half['selected_restart'],
                value_clip_fraction=asfloat(half['value_clip_fraction']),
                residual_fit_rre=asfloat(half['residual_fit_rre'])
            ))
    csv_path=out/f'{out.name}_rank_metrics.csv'
    with csv_path.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(summary[0])); writer.writeheader();writer.writerows(summary)
    print('Rank review:')
    for row in summary:
        print(f"r={row['rank']:2d} rho={row['rate']:.2f} PSNR noisy={row['psnr_noisy']:.2f} "
              f"fit={row['psnr_clean_fit']:.2f} direct={row['psnr_direct']:.2f} "
              f"half={row['psnr_tritd_half']:.2f} F1={row['f1']:.3f} "
              f"half-direct={row['gain_over_direct']:+.2f}")
    columns=('Original','Sparse-corrupted','Clean TriTD fit','Direct TriTD','TriTD-Half recovered')
    keys=('clean','observed','oracle','direct','recovered')
    for rho in rates:
        fig,ax=plt.subplots(len(runs),len(keys),figsize=(14,3.2*len(runs)),squeeze=False,
                            constrained_layout=True)
        for i,run in enumerate(runs):
            case=run['rows'][(rho,'tritd_half')]['case']
            data_path=run['path']/f"{run['tag']}_{case}_arrays.npz"
            if not data_path.exists():
                raise SystemExit(f'Missing arrays: {data_path}')
            with np.load(data_path,allow_pickle=False) as z:
                for j,key in enumerate(keys):
                    a=ax[i,j]
                    a.imshow(np.clip(z[key],0.,1.),interpolation='nearest')
                    a.axis('off')
                    if i==0: a.set_title(columns[j],fontsize=10)
                    if j==0: a.set_ylabel(f'r={run["rank"]}',fontsize=12)
                    if key=='recovered':
                        metric=next(x for x in summary if x['rank']==run['rank'] and x['rate']==rho)
                        a.text(.5,-.04,f'PSNR {metric["psnr_tritd_half"]:.2f} dB  |  F1 {metric["f1"]:.3f}',
                               transform=a.transAxes,ha='center',va='top',fontsize=9)
        fig.suptitle(f'S6 RGB matched comparison  |  corruption={rho:.0%}  |  {anchor["noise_mode"]} mode',fontsize=13)
        name=out/f'{out.name}_rho{str(rho).replace(".","p")}_comparison.png'
        fig.savefig(name,dpi=170); plt.close(fig)
    fig,ax=plt.subplots(1,2,figsize=(12,4.5),constrained_layout=True)
    for rho in rates:
        rrows=sorted((q for q in summary if q['rate']==rho),key=lambda q:q['rank'])
        ax[0].plot([q['rank'] for q in rrows],[q['psnr_clean_fit'] for q in rrows],marker='o',ls='--',label=f'Clean fit, rho={rho:.0%}')
        ax[0].plot([q['rank'] for q in rrows],[q['psnr_tritd_half'] for q in rrows],marker='o',label=f'TriTD-Half, rho={rho:.0%}')
        ax[1].plot([q['rank'] for q in rrows],[q['f1'] for q in rrows],marker='o',label=f'rho={rho:.0%}')
    ax[0].set(xlabel='Triple factor size r',ylabel='PSNR (dB)',title='Clean fitting vs. corrupted recovery')
    ax[1].set(xlabel='Triple factor size r',ylabel='Sparse support F1',title='Sparse corruption identification')
    for a in ax: a.grid(alpha=.25);a.legend(fontsize=8)
    fig.savefig(out/f'{out.name}_trends.png',dpi=175);plt.close(fig)
    (out/f'{out.name}_metadata.json').write_text(json.dumps(dict(runs=[str(x['path']) for x in runs],
      compared_on=must_match,source=anchor.get('source'),note='Clean oracle is a finite-iteration reference, not a theoretical best or a restoration method'),ensure_ascii=False,indent=2),encoding='utf-8')
    print('Saved:',csv_path,'and matched comparison images in',out)

if __name__=='__main__':main()
