#!/usr/bin/env python3
"""S14: Test whether TriTD and Group-Half add value beyond a median image guide.

Paired, fixed synthetic inputs, no clean data or true support used in fitting.
Variants: full S13, no TriTD, no Group-Half, spatial-only, no spatial guide,
blind median replacement, and full 3x3 median.
"""
from __future__ import annotations
import argparse, csv, json, time
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import median_filter

from tri_core import init_factors, tritd, mals_sweep
from s12_blind_impulse_v1 import unique_clean_cases, inject, stable_seed, mask_scores
from s13_spatial_tritd_half_v1 import (run_guided, group_prox, guide_from_noisy,
                                        image_metrics)


def write_csv(path, rows):
    if not rows: return
    with path.open('w', newline='', encoding='utf-8-sig') as file:
        w=csv.DictWriter(file, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)


def without_component(Y, rank, seed, alpha, eta, beta, mu, tau, lam, steps,
                      warmup, delta_low, delta_high, *, tritd_on, half_on):
    """Block-coordinate minimization with components switched off entirely.

    Without TriTD: mu=0, no A/B/C variables.
    Without Half: S stays zero and its penalty is omitted.
    Without spatial prior: tau=0 and initialize without M(Y).
    """
    if not tritd_on: mu=0.0
    med,w,_=guide_from_noisy(Y,delta_low,delta_high)
    if tau==0:
        x=np.asarray(Y,dtype=np.float64).copy()
    else:
        x=Y*(1-w[:,:,None])+med*w[:,:,None]
    s=(Y-x) if half_on else np.zeros_like(Y)
    factors=None
    if tritd_on:
        assert mu>0
        factors=init_factors(Y.shape,rank,seed=seed,scale=max(float(np.std(x)),1e-3))
        for _ in range(warmup):
            factors=mals_sweep(x,factors,alpha=alpha/mu,eta=eta/mu)
    w2=w[:,:,None]**2 if tau>0 else np.zeros((*Y.shape[:2],1))
    for _ in range(steps):
        if tritd_on:
            factors=mals_sweep(x,factors,alpha=alpha/mu,eta=eta/mu)
            low=tritd(*factors)
        else:
            low=np.zeros_like(Y)
        x=(beta*(Y-s)+mu*low+tau*w2*med)/(beta+mu+tau*w2)
        if half_on:
            s=group_prox(Y-x,lam/beta)
        else:
            s=np.zeros_like(Y)
        if not (np.all(np.isfinite(x)) and np.all(np.isfinite(s))):
            raise FloatingPointError('Non-finite values during S14 ablation')
    # Compute each variant's own objective ONLY to select restarts within that method.
    obj=.5*beta*np.sum((Y-x-s)**2)+.5*tau*np.sum((w[:,:,None]*(x-med))**2)
    if tritd_on:
        obj+=.5*mu*np.sum((x-low)**2)+.5*alpha*sum(np.sum(f*f) for f in factors)
    if half_on:
        obj+=lam*np.sum(np.sqrt(np.linalg.norm(s,axis=2)))
    return dict(X=x,S=s,L=low,objective=float(obj))


def panel(path,clean,Y,images,headline):
    entries=[('Clean (evaluation only)',clean),('Corrupted Y',Y),
             ('Blind median support fill',images['blind_median_fill']),
             ('Full S13 (TriTD + GroupHalf + guide)',images['full_s13']),
             ('No TriTD (GroupHalf + guide)',images['no_tritd']),
             ('No GroupHalf (TriTD + guide)',images['no_group_half']),
             ('Spatial guide only (no TriTD/GroupHalf)',images['spatial_only']),
             ('No spatial guide (TriTD + GroupHalf)',images['no_spatial']),
             ('Full 3x3 median',images['full_median3x3'])]
    fig,axes=plt.subplots(3,3,figsize=(12,12),constrained_layout=True)
    for a,(name,img) in zip(axes.flat,entries):
        a.imshow(np.clip(img,0,1),vmin=0,vmax=1)
        a.set_title(name,fontsize=9)
        a.axis('off')
    fig.suptitle(headline,fontsize=11)
    fig.savefig(path,dpi=145);plt.close(fig)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source',required=True,help='S10 DEV folder, contains *_arrays.npz')
    ap.add_argument('--out',default='outputs/s14_dev_ablation_v1')
    ap.add_argument('--rank',type=int,default=3)
    ap.add_argument('--modes',default='random_rgb,additive_rgb')
    ap.add_argument('--rates',default='0.05,0.10')
    ap.add_argument('--max-patches',type=int,default=4)
    ap.add_argument('--seed',type=int,default=2026)
    ap.add_argument('--restarts',type=int,default=2)
    ap.add_argument('--steps',type=int,default=120)
    ap.add_argument('--warmup',type=int,default=25)
    ap.add_argument('--alpha',type=float,default=.0001)
    ap.add_argument('--eta',type=float,default=.001)
    ap.add_argument('--beta',type=float,default=1.)
    ap.add_argument('--mu',type=float,default=.08)
    ap.add_argument('--tau',type=float,default=16.)
    ap.add_argument('--lam',type=float,default=.01)
    ap.add_argument('--delta-low',type=float,default=.07)
    ap.add_argument('--delta-high',type=float,default=.20)
    ap.add_argument('--support-threshold',type=float,default=.05)
    args=ap.parse_args()
    if min(args.restarts,args.steps,args.rank)<1 or args.max_patches<0 or args.warmup<0:
        ap.error('Invalid counts')
    if min(args.alpha,args.eta,args.tau)<0 or min(args.beta,args.mu,args.lam)<=0:
        ap.error('Invalid objective weights')
    if not 0<=args.delta_low<args.delta_high:
        ap.error('Invalid guide thresholds')
    modes=[x.strip() for x in args.modes.split(',')]
    rates=[float(x) for x in args.rates.split(',')]
    if any(x not in ('random_rgb','additive_rgb') for x in modes) or any(x<=0 or x>=1 for x in rates):
        ap.error('Bad modes/rates')
    out=Path(args.out)
    if out.exists() and any(out.iterdir()):
        ap.error(f'Refusing to overwrite existing nonempty output: {out}')
    source=Path(args.source)
    files=sorted(source.rglob('*_arrays.npz'))
    if not files: ap.error(f'No S10 arrays found in {source}')
    clean_cases=unique_clean_cases(files)
    if args.max_patches: clean_cases=dict(sorted(clean_cases.items())[:args.max_patches])
    out.mkdir(parents=True,exist_ok=True)
    tag=out.name
    (out/f'{tag}_config.json').write_text(json.dumps(vars(args),indent=2),encoding='utf-8')
    rows=[]
    for image_id,clean in sorted(clean_cases.items()):
        if args.rank>sorted(clean.shape)[1]:ap.error(f'Rank invalid for {clean.shape}')
        for mode in modes:
            for rate in rates:
                case=f'{image_id}__{mode}_rho{str(rate).replace(".","p")}'
                Y,truth=inject(clean,rate,mode,stable_seed(case,args.seed))
                med,w,diff=guide_from_noisy(Y,args.delta_low,args.delta_high)
                median_mask=diff>.20
                blind=np.where(median_mask[:,:,None],med,Y)
                spatial_only=(args.beta*Y+args.tau*w[:,:,None]**2*med)/(args.beta+args.tau*w[:,:,None]**2)
                images={'blind_median_fill':blind,'full_median3x3':med,'spatial_only':spatial_only,'noisy':Y}
                support_masks={'blind_median_fill':median_mask}
                t=time.perf_counter()
                sols=[run_guided(Y,args.rank,args.seed*100+j+17,args.alpha,args.eta,args.beta,
                                 args.mu,args.tau,args.lam,args.steps,args.warmup,
                                 args.delta_low,args.delta_high)
                      for j in range(args.restarts)]
                full=min(sols,key=lambda x:x['final_objective'])
                runtimes={'full_s13':time.perf_counter()-t}
                images['full_s13']=full['X']
                support_masks['full_s13']=np.linalg.norm(full['S'],axis=2)>args.support_threshold
                # The same seed, alpha/eta, data, weights and update budget as S13.
                ablations=[('no_tritd',False,True,args.tau),
                           ('no_group_half',True,False,args.tau),
                           ('no_spatial',True,True,0.)]
                for name,use_tritd,use_half,tt in ablations:
                    start=time.perf_counter()
                    seeds=(range(args.restarts) if use_tritd else range(1))
                    cand=[without_component(Y,args.rank,args.seed*100+j+17,
                         args.alpha,args.eta,args.beta,args.mu,tt,args.lam,args.steps,
                         args.warmup,args.delta_low,args.delta_high,
                         tritd_on=use_tritd,half_on=use_half)
                         for j in seeds]
                    best=min(cand,key=lambda x:x['objective'])
                    runtimes[name]=time.perf_counter()-start
                    images[name]=best['X']
                    if use_half:
                        support_masks[name]=np.linalg.norm(best['S'],axis=2)>args.support_threshold
                for method,img in images.items():
                    metric=image_metrics(clean,img)
                    q=mask_scores(truth,support_masks[method]) if method in support_masks else None
                    rows.append(dict(case=case,image=image_id,mode=mode,rate=rate,method=method,
                                     rank=args.rank,psnr=metric['psnr'],ssim=metric['ssim'],
                                     mae=metric['mae'],
                                     precision='' if q is None else q['precision'],
                                     recall='' if q is None else q['recall'],
                                     f1='' if q is None else q['f1'],
                                     runtime_s=runtimes.get(method,'')))
                write_csv(out/f'{tag}_per_case.csv',rows)
                panel(out/f'{tag}_{case}_panel.png',clean,Y,images,case)
                print(f'{case}: full={image_metrics(clean,images["full_s13"])["psnr"]:.2f}, '
                      f'noTri={image_metrics(clean,images["no_tritd"])["psnr"]:.2f}, '
                      f'noHalf={image_metrics(clean,images["no_group_half"])["psnr"]:.2f}, '
                      f'noSpatial={image_metrics(clean,images["no_spatial"])["psnr"]:.2f}, '
                      f'blindMedian={image_metrics(clean,blind)["psnr"]:.2f}',flush=True)
    groups=defaultdict(list)
    for row in rows: groups[(row['mode'],row['rate'],row['method'])].append(row)
    summary=[]
    for (mode,rate,method),items in sorted(groups.items()):
        f1=[float(a['f1']) for a in items if a['f1']!='']
        summary.append(dict(mode=mode,rate=rate,method=method,n_cases=len(items),
                            mean_psnr=float(np.mean([a['psnr'] for a in items])),
                            mean_ssim=float(np.mean([a['ssim'] for a in items])),
                            mean_f1=float(np.mean(f1)) if f1 else '',
                            mean_runtime_s=(float(np.mean([a['runtime_s'] for a in items]))
                                            if items[0]['runtime_s']!='' else '')))
    write_csv(out/f'{tag}_summary.csv',summary)
    bycase=defaultdict(dict)
    for row in rows:bycase[row['case']][row['method']]=row
    paired=[]
    for case,methods in sorted(bycase.items()):
        full=methods['full_s13']['psnr']
        paired.append(dict(case=case,mode=methods['full_s13']['mode'],rate=methods['full_s13']['rate'],
                           full_psnr=full,
                           no_tritd_psnr=methods['no_tritd']['psnr'],
                           full_minus_no_tritd=full-methods['no_tritd']['psnr'],
                           no_group_half_psnr=methods['no_group_half']['psnr'],
                           full_minus_no_group_half=full-methods['no_group_half']['psnr'],
                           no_spatial_psnr=methods['no_spatial']['psnr'],
                           full_minus_no_spatial=full-methods['no_spatial']['psnr'],
                           blind_median_psnr=methods['blind_median_fill']['psnr'],
                           full_minus_blind_median=full-methods['blind_median_fill']['psnr']))
    write_csv(out/f'{tag}_paired.csv',paired)
    print('\nPaired comparison across',len(paired),'instances')
    for key in ['full_minus_no_tritd','full_minus_no_group_half','full_minus_no_spatial','full_minus_blind_median']:
        vals=np.asarray([row[key] for row in paired])
        print(f' {key}: mean {vals.mean():+.3f} dB, full better {np.count_nonzero(vals>0)}/{len(vals)}')
    print('Saved:',out.resolve())
    print('NOTE: Ablation results are diagnostic; not final DIV2K test scores.')

if __name__=='__main__':main()
