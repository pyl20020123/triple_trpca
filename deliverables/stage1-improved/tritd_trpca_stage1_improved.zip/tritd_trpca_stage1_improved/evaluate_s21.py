#!/usr/bin/env python3
"""Evaluate fixed S21 on saved observations; no clean-data parameter selection."""
import argparse,csv,json,time
from pathlib import Path
import numpy as np
from skimage.metrics import structural_similarity
from scipy.ndimage import median_filter
from s21_detail_preserving import repair

def evaluate(source,out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    rows=[]; examples=[]
    for p in sorted(Path(source).rglob('*arrays.npz')):
        with np.load(p,allow_pickle=False) as d:
            clean=d['clean']; y=d['Y'] if 'Y' in d else d['observed']
            old=d['estimated_X'] if 'estimated_X' in d else d['recovered']
            med=median_filter(y,size=(3,3,1),mode='reflect')
            baseline=np.where((np.linalg.norm(y-med,axis=2)>0.2)[:,:,None],med,y)
            t=time.perf_counter(); x,mask=repair(y);seconds=time.perf_counter()-t
            for method,z in [('noisy',y),('original',old),('median_t020',baseline),('s21',x)]:
                z=np.clip(z,0,1);mse=float(np.mean((clean-z)**2))
                rows.append(dict(case=p.stem,method=method,mse=mse,psnr=float(-10*np.log10(max(mse,1e-15))),
                    ssim=float(structural_similarity(clean,z,data_range=1,channel_axis=2)),
                    seconds=seconds if method=='s21' else '',detected_fraction=float(mask.mean()) if method=='s21' else ''))
            np.savez_compressed(out/(p.stem+'_s21.npz'),recovered=x,support=mask)
            examples.append((p.stem,clean,y,old,x,rows[-1]['psnr']-rows[-3]['psnr']))
    if not rows:raise ValueError('No saved arrays found')
    with (out/'per_case.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    summary={}
    for method in ('noisy','original','median_t020','s21'):
        r=[a for a in rows if a['method']==method]
        summary[method]={'n':len(r),'mean_psnr':float(np.mean([a['psnr'] for a in r])),
            'pooled_psnr':float(-10*np.log10(np.mean([a['mse'] for a in r]))),
            'mean_ssim':float(np.mean([a['ssim'] for a in r]))}
    gains=[a[-1] for a in examples];summary['comparison']={'wins':int(np.sum(np.array(gains)>0)),
        'n':len(gains),'min_gain_db':float(min(gains)),'max_gain_db':float(max(gains))}
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    # Show both largest improvement and largest regression, not only wins.
    chosen=[min(examples,key=lambda a:a[-1]),max(examples,key=lambda a:a[-1])]
    fig,axs=plt.subplots(2,4,figsize=(12,7),constrained_layout=True)
    for axes,(name,clean,y,old,x,gain) in zip(axs,chosen):
        for ax,z,title in zip(axes,[clean,y,old,x],['Clean','Noisy','Original',f'S21 (gain {gain:+.2f} dB)']):
            ax.imshow(np.clip(z,0,1),interpolation='nearest');ax.set_title(title);ax.axis('off')
        axes[0].set_title(name.replace('_arrays',''),fontsize=6)
    fig.savefig(out/'comparison.png',dpi=150);plt.close(fig)
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--out',required=True)
    a=p.parse_args();evaluate(a.source,a.out)
