#!/usr/bin/env python3
"""S8: Diagnose TriTD generalization by hiding *additional clean observed pixels*.

Read existing S6 outputs (S6's known clean is NEVER used to fit/choose rank).
For each salt/pepper fraction, detect black/white corrupt pixels based ONLY on
observed RGB. Hold out a reproducible 10% of remaining clean observations for
validation. Fit masked TriTD to the other observed pixels. Report training and
held-out errors. Matched validation pixels are identical across rank settings.

This is a diagnostic for why high-rank masked TriTD fails, NOT a new TRPCA method.
Requires s7_mask_probe_v1.py and tri_core.py in the project root.
"""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from s7_mask_probe_v1 import masked_als, detect_saturated_rgb_pixels, psnr, ssim


def read_csv(f):
    with f.open(encoding='utf-8-sig',newline='') as h:
        return list(csv.DictReader(h))


def validate_inputs(folders):
    runs=[]
    for folder in map(Path,folders):
        tag=folder.name
        cfgpath=folder/f'{tag}_config.json'
        metrics=folder/f'{tag}_metrics.csv'
        if not (cfgpath.exists() and metrics.exists()):
            raise FileNotFoundError(f'Missing S6 files in {folder}')
        cfg=json.loads(cfgpath.read_text(encoding='utf-8'))
        if cfg.get('noise_mode') != 'pixel':
            raise ValueError('S8 supports S6 pixel-mode salt-and-pepper only')
        rows=read_csv(metrics)
        rates=sorted({round(float(r['rate']),9) for r in rows if r['method']=='tritd_half'})
        runs.append(dict(folder=folder,tag=tag,cfg=cfg,rank=int(cfg['rank']),rates=rates))
    runs.sort(key=lambda p:p['rank'])
    if len({r['rank'] for r in runs})!=len(runs):
        raise ValueError('Duplicate ranks provided')
    first=runs[0]
    checks=('source','original_size_hw','crop_top_left','crop_size','rates','noise_mode','seed')
    for rr in runs[1:]:
        if rr['rates']!=first['rates'] or any(rr['cfg'].get(x)!=first['cfg'].get(x) for x in checks):
            raise ValueError('Run configs are not matched in image crop, noise mode, rates, seed')
    return runs


def p_error(x,z,mask):
    return float(np.mean((x[mask]-z[mask])**2))


def save_csv(path,rows):
    with path.open('w',newline='',encoding='utf-8-sig') as fh:
        writer=csv.DictWriter(fh,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--runs',nargs='+',required=True)
    p.add_argument('--out',default='outputs/s8_mask_holdout_v1')
    p.add_argument('--holdout',type=float,default=.10,help='Fraction of NONcorrupted spatial pixels held out')
    p.add_argument('--sweeps',type=int,default=300)
    p.add_argument('--restarts',type=int,default=2)
    p.add_argument('--alpha',type=float,default=.0001)
    p.add_argument('--eta',type=float,default=.001)
    p.add_argument('--seed',type=int,default=92026)
    a=p.parse_args()
    if not 0<a.holdout<1 or a.sweeps<1 or a.restarts<1 or min(a.alpha,a.eta)<0 or a.alpha+a.eta<=0:
        p.error('Invalid holdout/sweeps/restarts/regularization')
    out=Path(a.out)
    if out.exists() and any(out.iterdir()):
        raise SystemExit(f'Refusing to overwrite {out}; use new --out')
    runs=validate_inputs(a.runs)
    out.mkdir(parents=True,exist_ok=True)
    tag=out.name
    (out/f'{tag}_config.json').write_text(json.dumps(vars(a),indent=2,ensure_ascii=False),encoding='utf-8')
    rows=[]
    for rate in runs[0]['rates']:
        rate_tag=str(rate).replace('.','p')
        # Create one shared holdout mask from the first rank's exactly matched observation.
        reference=runs[0]
        case0=f'r{reference["rank"]}_rho{rate_tag}_pixel'
        with np.load(reference['folder']/f'{reference["tag"]}_{case0}_arrays.npz',allow_pickle=False) as f:
            y0=np.asarray(f['observed'],dtype=np.float64)
        mask0=detect_saturated_rgb_pixels(y0)
        good_locations=np.flatnonzero((~mask0).ravel())
        n_hold=max(1,int(round(a.holdout*len(good_locations))))
        rg=np.random.default_rng(a.seed+int(round(rate*10000)))
        chosen=rg.choice(good_locations,n_hold,replace=False)
        holdout=np.zeros(mask0.shape,dtype=bool)
        holdout.ravel()[chosen]=True
        for rr in runs:
            rank=rr['rank'];case=f'r{rank}_rho{rate_tag}_pixel'
            path=rr['folder']/f'{rr["tag"]}_{case}_arrays.npz'
            if not path.exists():
                raise FileNotFoundError(path)
            with np.load(path,allow_pickle=False) as f:
                clean=np.asarray(f['clean'],dtype=np.float64)
                y=np.asarray(f['observed'],dtype=np.float64)
                true_sparse=np.asarray(f['sparse_true'],dtype=np.float64)
            if y.shape!=y0.shape or not np.allclose(y,y0,atol=1e-12):
                raise ValueError('S6 corruptions do not match across ranks; cannot make paired comparison')
            bad=detect_saturated_rgb_pixels(y)
            if not np.array_equal(bad,mask0):
                raise ValueError('Detection mask changed across ranks')
            train=~(bad|holdout)
            train_mask=bad|holdout
            fit=masked_als(y,train_mask,rank,a.restarts,a.sweeps,a.alpha,a.eta,
                           seed=a.seed*10+31)
            pred=fit['L']
            mse_train=p_error(y,pred,train)
            mse_valid=p_error(y,pred,holdout)
            mse_corrupt=p_error(clean,pred,bad)
            record=dict(rank=rank,rate=rate,training_pixels=int(train.sum()),
                holdout_pixels=int(holdout.sum()),corruption_pixels=int(bad.sum()),
                psnr_training=float(-10*np.log10(max(mse_train,1e-15))),
                psnr_holdout=float(-10*np.log10(max(mse_valid,1e-15))),
                mse_training=mse_train,mse_holdout=mse_valid,
                mse_holdout_over_training=mse_valid/max(mse_train,1e-15),
                psnr_on_true_corrupted_pixels=float(-10*np.log10(max(mse_corrupt,1e-15))),
                psnr_full_image=psnr(clean,pred),ssim_full_image=ssim(clean,pred),
                selected_restart=fit['restart'],mask_matches_true_support=int(np.array_equal(bad,np.any(np.abs(true_sparse)>1e-10,axis=2))),
                nominal_factor_params=rank*rank*sum(y.shape),training_rgb_entries=int(train.sum()*3))
            rows.append(record)
            save_csv(out/f'{tag}_metrics.csv',rows)
            print(f'r={rank} rho={rate:.0%} train={record["psnr_training"]:.2f}dB '
                  f'holdout={record["psnr_holdout"]:.2f}dB '
                  f'oracle-pixel={record["psnr_on_true_corrupted_pixels"]:.2f}dB '
                  f'full={record["psnr_full_image"]:.2f}dB',flush=True)
            # Color array remains [0,1] for consistent display.
            Image.fromarray(np.uint8(np.round(np.clip(pred,0,1)*255))).save(out/f'{tag}_r{rank}_rho{rate_tag}_holdout_fit.png')
            np.savez_compressed(out/f'{tag}_r{rank}_rho{rate_tag}_arrays.npz',pred=pred,training_mask=train,
                    heldout_mask=holdout,known_bad_mask=bad)
        fig,ax=plt.subplots(1,2,figsize=(10,3.7),constrained_layout=True)
        sample=[r for r in rows if abs(r['rate']-rate)<1e-9]
        ranks=[r['rank'] for r in sample]
        ax[0].plot(ranks,[r['psnr_training'] for r in sample],marker='o',label='Training observed pixels')
        ax[0].plot(ranks,[r['psnr_holdout'] for r in sample],marker='o',label='Held-out clean pixels')
        ax[0].set_ylabel('PSNR (dB)')
        ax[0].set_title('Training vs unseen observed pixels')
        ax[0].legend(fontsize=8)
        ax[1].plot(ranks,[r['psnr_full_image'] for r in sample],marker='o',label='Full image')
        ax[1].plot(ranks,[r['psnr_on_true_corrupted_pixels'] for r in sample],marker='o',label='True corrupted locations (oracle eval)')
        ax[1].set_ylabel('PSNR (dB)')
        ax[1].set_title('Image recovery diagnostic')
        ax[1].legend(fontsize=8)
        for a0 in ax:
            a0.set_xticks(ranks)
            a0.set_xlabel('Factor size r')
            a0.grid(alpha=.2)
        fig.suptitle(f'S8: unseen-pixel validation, salt-and-pepper {rate:.0%}')
        fig.savefig(out/f'{tag}_rho{rate_tag}_curves.png',dpi=170)
        plt.close(fig)
    print('Saved to',out,flush=True)
    print('Heldout errors use original observations at uncorrupted locations, NOT the clean original to train/choose.',flush=True)

if __name__=='__main__':
    main()
