import unittest
import numpy as np
from s21_detail_preserving import repair

class RepairTests(unittest.TestCase):
    def test_constant_and_step_unchanged(self):
        y=np.full((24,24,3),.25);y[:,12:]=.8
        x,m=repair(y);np.testing.assert_array_equal(x,y);self.assertFalse(m.any())
    def test_isolated_impulse(self):
        y=np.full((24,24,3),.3);y[12,12]=[1,0,1]
        x,m=repair(y);self.assertTrue(m[12,12]);np.testing.assert_allclose(x,.3,atol=1e-12)
        np.testing.assert_array_equal(x[~m],y[~m])
    def test_tiling_matches(self):
        rng=np.random.default_rng(7);y=np.full((38,43,3),.4)
        mask=rng.random(y.shape[:2])<.1;y[mask]=rng.random((mask.sum(),3))
        x,m=repair(y,search_radius=4,tile_size=128)
        z,n=repair(y,search_radius=4,tile_size=13)
        np.testing.assert_array_equal(n,m);np.testing.assert_allclose(z,x,atol=1e-10)
    def test_invalid(self):
        for y in (np.zeros((4,4)),np.full((4,4,3),np.nan),np.full((4,4,3),2)):
            with self.assertRaises(ValueError):repair(y)

if __name__=='__main__':unittest.main()
